# HRV Owner Recertification Export (`hrv_owner_export.py`)

Builds the Excel file behind the HRV recertification Power BI report: for every App ID, its
owners by role and how many of the app's firewall rules are certified, decertified or still
pending. No rule-level detail. The file is written into the HRV Power BI folder on SharePoint
and overwritten on each run.

Read-only against Tufin. It changes nothing.

---

## How it works

| Source | Gives |
|---|---|
| Tufin SecureTrack (GraphQL) | The rules in scope, each rule's App ID, and its certification status |
| Owner sheets in `SharedData` | App ID → owners by role (IT SME, IT SME Backup, IT Lead, IT Lead Delegate, Client Owner, IT Director, IT Senior Leader) |

1. **Owner lookup.** Reads every sheet in the data folder and builds one App ID → owners table.
   Role-column sheets (SharePoint list exports, `report_` views) and AMPS owner text (the Tufin
   rule extract) are both understood. Rule rows in the sheets are **not** matched to Tufin —
   the sheets only answer "who owns this app".
2. **Rules from Tufin.** Pulls every rule matching `SCOPE_FILTER` — Palo Alto rules whose
   description carries `app_id: APP-xxxx` (written by the App-ID backfill).
3. **Status per rule** from `ruleUserData.certification`:
   - `CERTIFIED` / `DECERTIFIED` with `timeCertified` on or after `CAMPAIGN_START` → Certified / Decertified
   - anything older, or no certification → **Pending** (older certifications belong to earlier campaigns)
4. **Roll up per App ID** and write one row per App ID + role + owner.
5. **Writes a heartbeat** to `../heartbeats/hrv_owner_export.json` for the watchdog.

Fallbacks:
- App ID with no owner in any sheet → the SecureApp owner, only if a linked SecureApp
  application carries the same APP number; otherwise `Owner unknown`.
- Rule with no parsable App ID → `No App ID`.

### Why the owners come from sheets

Tufin has no role-based ownership. `technicalOwnerName` and `certification.owner` are empty
on these rules, and `saApplications.owner` is a single LAN ID for the SecureApp application
the rule touches — usually a different app from the rule's assigned App ID.

---

## Setup

```
py -m pip install openpyxl requests
py hrv_owner_export.py
```

Prompts for the SecureTrack user and password (ticketAPI), or reads `SECURETRACK_USER` /
`SECURETRACK_PASSWORD` for a scheduled run. Login is Keycloak, same as the other Tufin scripts.

### The SharePoint folder

The script writes to the HRV Power BI folder through OneDrive, so that folder has to be on
the PC that runs it:

1. In SharePoint open **Cybersecurity Network Protection Services → Shared Documents → HRV Power BI**.
2. Click **Add shortcut to My files** (or **Sync**).
3. It appears locally as
   `C:\Users\<you>\OneDrive - PGE\Cybersecurity Network Protection Services - HRV Power BI`.

`OUTPUT_DIR` points there. If that path doesn't exist, the script searches the OneDrive
folders for one ending in `HRV Power BI`, and stops with an error if none is found — it never
writes somewhere Power BI can't see. The first log line shows the folder used.

### Owner sheets

Put the sheets in a `SharedData` subfolder inside that HRV Power BI folder. If it isn't
there, the script falls back to the repository's `SharedData`. The log line
`Owner phone book from ...` shows which was read.

Skipped automatically: names containing `TEST`/`test`, `Rule-ID-Mapping*`, Excel lock files
(`~$*`), and the script's own output.

---

## Output

**`HRV_Owner_Recert_Status.xlsx`** — fixed name and columns; Power BI points at it once.

Tab **Owner Status**:

| Column | |
|---|---|
| App ID | `APP-1234`, or `No App ID` |
| Role | Owner role, `SecureApp Owner`, or `Owner unknown` |
| Owner Name / LAN ID / Email | From the owner sheets |
| Total Rules | Rules in scope with this App ID |
| Certified / Decertified / Pending | Counts for this campaign |
| % Complete | (Certified + Decertified) / Total |
| Status | `Complete`, `In Progress`, `Not Started` |
| Last Updated | Run date |

The rule counts repeat on every owner row of an app — sum per App ID, not per row. One person
can hold several roles on the same app (that's how AMPS lists them).

Tab **Run Info**: run time, scope filter, campaign start, totals, App IDs with no owner,
Palo Alto rules with no `app_id` (outside the export), and which sheets fed the owner lookup.

The file is written to a temp name and swapped in, so Power BI never reads a half-written
file. If the file is locked, a timestamped copy is written instead and the log says so.

---

## Key settings

| Setting | Purpose |
|---|---|
| `TUFIN_HOST` | Production SecureTrack host |
| `SCOPE_FILTER` | TQL for the rules in scope. Default: Palo Alto rules tagged with an App ID |
| `CAMPAIGN_START` | Certifications before this date count as Pending |
| `OUTPUT_DIR` | Local path of the synced HRV Power BI folder |
| `OUTPUT_NAME` / `SHEET_NAME` | Keep fixed — Power BI depends on them |
| `DATA_DIR_SHAREPOINT` | Owner sheets folder on SharePoint (falls back to repo `SharedData`) |
| `INPUT_EXCLUDE` | File patterns never read as owner sheets |
| `COL_APP_ID`, `ROLE_COLUMNS`, `COL_AMPS` | Header aliases — the lists don't use identical headers |

---

## Scheduling

Task Scheduler, daily: `py hrv_owner_export.py`, start in the script folder, with
`SECURETRACK_USER` / `SECURETRACK_PASSWORD` set for the task's account. The PC must be on and
OneDrive running for the file to upload. Add `"hrv_owner_export": 26` to `JOBS` in
`job_watchdog.py` so a missed or failed run raises an alert.

---

## Known gaps

- **Decertified shows 0.** Rules owners marked for cleanup went through the decommission
  workflow, which doesn't record a `DECERTIFIED` certification. How those should be counted
  is open.
- **Rules without an App ID are outside the export.** Run Info shows how many Palo Alto rules
  have no `app_id` in the description; they join once tagged.

## Confirmed Tufin fields

`rules(filter)` takes only `filter`; paging is `values(first, offset)` (`offset` is `Long`).

```
rule.ruleUserData.ruleDescription            "app_id: APP-1980"
rule.ruleUserData.certification              { status timeCertified timeExpiration owner ownerEmail comment ticket }
CertificationStatus                          CERTIFIED | DECERTIFIED   (null = never certified)
rule.ruleUserData.saApplications             [{ name owner id changed }]
rule.ruleUserData.securechangeTicketInProgressId
```

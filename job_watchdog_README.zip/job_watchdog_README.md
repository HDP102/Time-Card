# Job Watchdog (`job_watchdog.py`)

An hourly health check for the NPS automation. It emails the team when Tufin is unreachable,
when a scheduled job fails, or when a job stops running — so a broken nightly run is found
the same day instead of when someone notices missing emails or a stale report.

---

## What it checks

| Check | How | Catches |
|---|---|---|
| Tufin SecureTrack | Keycloak login + a trivial GraphQL query (`{__typename}`) | Outage, upgrade, expired ticketAPI password |
| Tufin SecureChange | Authenticated REST GET (`SC_HEALTH_PATH`) | The same on the workflow side |
| Job heartbeats | Reads `heartbeats/<job>.json` for each job in `JOBS` | Last run failed, or no run within the allowed hours (not scheduled, machine off) |

Every job writes its heartbeat at the end of each run — `status` `ok` or `failed`, with the
error message. Current jobs: `escalation_notify`, `hrv_owner_export`.

### Alerting

- **First failure** → alert email listing every failing check and its error.
- **Still failing** → re-alert every `REALERT_HOURS` (default 4), not every hour.
- **Back to healthy** → one `RECOVERED` email.

State is kept in `heartbeats/watchdog_state.json`. If the watchdog itself crashes, it sends
`ALERT: job_watchdog itself failed` with the traceback.

---

## Setup

```
py -m pip install requests
py job_watchdog.py
```

It looks for `heartbeats/` one level above its own folder, the same place the jobs write
to — so keep it in a subfolder of `NPS-Automation/` like the other scripts.

Credentials come from `SECURETRACK_USER` / `SECURETRACK_PASSWORD` (ticketAPI). There is no
prompt — it is meant to run unattended.

### Schedule (Windows Task Scheduler)

- Trigger: daily, repeat every 1 hour
- Action: `py` with argument `job_watchdog.py`, start in the script's folder
- Set the two environment variables for the account the task runs as

---

## Key settings

| Setting | Purpose |
|---|---|
| `TUFIN_HOST` | Production SecureTrack/SecureChange host |
| `CHECK_TUFIN` | `False` to check heartbeats only |
| `SC_HEALTH_PATH` | SecureChange endpoint used for the REST check |
| `JOBS` | Job name → hours allowed since its last run. A daily job uses `26` (2-hour cushion). |
| `ALERT_TO` | Alert recipients (engineer + team DL) |
| `SENDER_EMAIL` | Must be a valid `CorpID@pge.com` |
| `REALERT_HOURS` | How often a still-failing check re-alerts |
| `DRY_RUN` | `True` prints alerts instead of emailing |

### Adding a job

1. At the end of the job, write `heartbeats/<job>.json`:
   `{"time": "<ISO timestamp>", "status": "ok" | "failed", "message": "..."}`
   (copy `heartbeat()` from `escalation_notify.py` or `hrv_owner_export.py`).
2. Add it to `JOBS`, e.g. `"hrv_owner_export": 26`.

A job listed in `JOBS` that has never run alerts with "no heartbeat file" — expected until
its first run on that machine.

---

## Testing

| Test | How | Expect |
|---|---|---|
| Healthy | Run with valid creds after a successful job run | `0 failing`, no email |
| Tufin down | Bad `SECURETRACK_PASSWORD` | ALERT naming the Tufin checks |
| Recovered | Fix the password, run again | RECOVERED email |
| Stale job | Set a job's hours to `0` in `JOBS` | ALERT "older than 0h" |
| No re-alert spam | Run twice within `REALERT_HOURS` while failing | Second run sends nothing |

Delete `heartbeats/watchdog_state.json` to reset alert state after testing.

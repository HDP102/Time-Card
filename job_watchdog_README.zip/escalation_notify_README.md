# Escalation Notifications (`escalation_notify.py`)

Sends recertification reminders to rule owners that escalate up the owner chain the longer
a rule goes unanswered, and on the deadline produces the list of IT SME accounts to be
disabled. Built for the FER firewall rule recertification campaign; run once a day.

The script **sends email and writes files only**. It never changes a firewall rule and never
disables an account — the disable list is handed to the account-management team's process.

---

## How it works

Each run:

1. **Load scope.** Reads every file in `SharedData` matching `SCOPE_GLOB`. Two owner formats
   are detected per file:
   - **Role columns** — `IT SME`, `IT SME Backup`, `IT Lead`, `IT Lead Delegate`,
     `Client Owner`, `IT Director`, `IT Senior Leader`, each `Last, First (CORPID)`.
   - **AMPS owner text** — the Tufin extract's `Source AMPS owners list` /
     `Destination AMPS owners list` cells (`IP = {'APP-xxxx': {... 'IT SME': 'Last, First (ID)' ...}}`).
     A rule can carry several apps; each app's owners are handled separately.
     `Skip AMPS due to subnets` cells have no owners.
2. **Drop answered rules.** A rule is answered when its certification date is on or after
   `CAMPAIGN_START`, or its decision is in `ANSWERED_VALUES`. Rules already disabled in Tufin
   are skipped (`SKIP_DISABLED_RULES`).
3. **Group by owner set.** Rules with the same IT SME / Backup / Lead / ... go in one email.
4. **Work out today's stage** from `LADDER` and send it to every group that hasn't had it.
   A missed run doesn't stack mail — only the latest due stage goes out.
5. **Check the IT SME and Backup in AD** before every send (`AD_MODE`). Inactive accounts are
   dropped; if neither is active, the IT Lead is addressed and the group is listed in
   `no_active_sme_<date>.csv`.
6. **On/after `DEADLINE`**, writes `disable_list_<date>.csv` — IT SME and IT SME Backup of
   every group still outstanding (active accounts only; never the IT Lead or leaders) — and
   hands it off per `DISABLE_HANDOFF`. Produced once per campaign.
7. **Saves evidence** of every email: the `.eml` file plus a row in `evidence_log.csv`.
8. **Writes a heartbeat** to `../heartbeats/escalation_notify.json` for the watchdog
   (not on `DRY_RUN`, so dry runs don't mask a broken schedule).

### The ladders

| Key | Use | Stages |
|---|---|---|
| `megan` | Production | 60 / 45 / 30 / 15 / 7 days before `DEADLINE`. CC widens from IT Lead → + IT Director, Client Owner → + IT Senior Leader. Disable warning from the 15-day stage. |
| `swapnil` | Compressed leadership test | SME → + IT Lead → + Client Owner, IT Director, IT Senior Leader with the disable warning |

To is always the IT SME and IT SME Backup. Subjects are prefixed `REMINDER`, `ESCALATION`
or `FINAL NOTICE`.

With `COMPRESSED = True` the day offsets are ignored and one stage goes out every
`COMPRESS_DAYS` from `CAMPAIGN_START` — the whole ladder in a few days for a test.

---

## Setup

```
py -m pip install openpyxl
py -m pip install ldap3          # only for AD_MODE = "ldap"
py escalation_notify.py
```

Folder layout (relative to the repository root):

```
NPS-Automation/
├── Escalation/escalation_notify.py
├── Escalation/escalation_output/     created on first run
├── SharedData/                       scope files (untracked)
└── heartbeats/                       created on first run
```

Mail goes through the internal relay (`mailhost:25`, no auth). `SENDER_EMAIL` must be a
valid `CorpID@pge.com`.

For an unattended run with `AD_MODE = "ldap"`, set `TICKETAPI_PASSWORD`. Nothing prompts
when there is no terminal; a missing password fails the run and sends an alert.

---

## Run modes

| Setting | Effect |
|---|---|
| `DRY_RUN = True` | No mail, no state change. Email previews go to `evidence/dry_run/`. **Start here.** |
| `TEST_MODE = True` | Every email goes to `TEST_RECIPIENT` (+ `TEST_COPY_TO`) only, with a banner showing the real To/CC. Uses a separate state file, so test runs never affect production state. |
| `TEST_LIMIT` | Max groups emailed in a test run (`0` = no cap) |
| `FORCE_STAGE` | Send a named stage now regardless of dates (e.g. `"30"`) — for demos and evidence |
| `TODAY_OVERRIDE` | Pretend today is another date (`"2026-10-20"`) to step through a ladder |

**Going live:** `DRY_RUN = False`, `TEST_MODE = False`, `COMPRESSED = False`,
`LADDER = "megan"`, real `CAMPAIGN_START` / `DEADLINE`, and delete or rename
`escalation_output/` so test state isn't carried over.

---

## Key settings

| Setting | Purpose |
|---|---|
| `CAMPAIGN_START` | Certifications on/after this date count as answered. Also day 1 of a compressed run. |
| `DEADLINE` | Stage days count back from here; the disable list is produced on/after it |
| `LADDER` | `megan` (production) or `swapnil` (compressed test) |
| `SCOPE_GLOB` | Which `SharedData` files are in scope, e.g. `Sathish_Rule_report*.xlsx` |
| `OWNER_SIDES` | AMPS format: owners from `source`, `destination`, or both |
| `SCOPE_OWNER_FILTER` | Keep only apps where one of these CorpIDs holds a role (e.g. one director's org). Dropped rules → `scope_dropped_<date>.csv` |
| `RESPONSE_SOURCE` | `sheet` = certification date column in the scope file. Re-export the file before each run. |
| `ANSWERED_VALUES` | Decision values that count as answered without a certification date |
| `AD_MODE` | `off` (no check), `ldap` (query AD as ticketAPI), `file` (CSV `corpid,status[,manager]` in SharedData) |
| `COPY_MANAGER` | On stages marked `cc_manager`, also CC the IT SME / Backup's AD manager |
| `DISABLE_ROLES` | Who goes on the disable list. **IT SME and IT SME Backup only — never add leaders.** |
| `DISABLE_ONLY` | Test safety: limit the disable list to these CorpIDs |
| `DISABLE_HANDOFF` | `file` (write the CSV, email it if `DISABLE_LIST_TO` is set) or `command` (also run `DISABLE_COMMAND` on it; never on `DRY_RUN`) |
| `REPLY_TO` | Team DL — owner replies go here, not to the sender |
| `COPY_TO` | Bcc on every live email (team DL) |
| `ALERT_TO` | Who gets the failure alert if a run crashes |
| `ONLY_SME` / `EXCLUDE` | Limit to, or never email, specific CorpIDs |

---

## Output (`escalation_output/`)

| File | What |
|---|---|
| `evidence/*.eml` | Every email exactly as sent — open in Outlook |
| `evidence/evidence_log.csv` | One row per email: time, stage, group, To/CC, rules, result |
| `evidence/dry_run/` | Previews from dry runs |
| `outstanding_<date>.csv` | Every outstanding rule/owner pair that run |
| `no_active_sme_<date>.csv` | Groups with no active IT SME or Backup |
| `disable_list_<date>.csv` | Accounts for the disable process (deadline only) |
| `scope_dropped_<date>.csv` | Rules removed by `SCOPE_OWNER_FILTER` |
| `escalation_state.json` | Which stage each group has had. `_test` variant in test mode. Delete to start a campaign over. |

Re-running the same day is safe: a group never gets the same stage twice.

---

## Open items

Search the script for `TBD`.

- AD server and base DN for `AD_MODE = "ldap"`
- Disable handoff format and endpoint (API spec pending) — `DISABLE_HANDOFF`, `DISABLE_LIST_COLUMNS`
- Whether to CC managers (`COPY_MANAGER`)
- Whether "no longer needed" counts as answered (`ANSWERED_VALUES`)
- AMPS owner side: both or destination only (`OWNER_SIDES`)
- `RESPONSE_SOURCE = "tufin"` — read certification live from Tufin instead of the sheet.
  The fields are now confirmed (`ruleUserData.certification { status timeCertified }`,
  see `hrv_owner_export.py`) but not wired in here yet.

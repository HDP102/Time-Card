"""
recert_processor.py
===================
Workstream 2 — Rule Recertification Response Processing  (SCAFFOLD)
PG&E | NPS Automation

STATUS: structural scaffold. The decision logic, pagination, and batching are real
and tested. Every external call (SecureTrack GraphQL, AMPS, ticket creation) is a
STUB marked with TODO — wire these up when the following land:
  - The AMPS app-ID -> participants resolver (needs one->all-participants change)
  - The SecureTrack GraphQL endpoint + auth (Postman-verified in lab first)
  - Confirmation of which FUR step-1 field holds the app ID (varies by workflow version)
  - Tufin access (gated on PRA + NERC training)

WHAT THIS DOES (the pipeline the Tufin RE described, end to end):
  1. Pull rules from SecureTrack via GraphQL (paginated, 100/page, offset-based).
  2. For each rule, find its app ID(s) — from the description, or from related
     ticket step-1 fields.
  3. Resolve each app ID to the CURRENT full AMPS participant group (not one owner).
  4. Read the owner's recertification decision (from the returned spreadsheets).
  5. Branch on the decision and generate the right action:
        A) Recertify        -> recertify ticket
        B) Clean up/Remove  -> decommission-RULE ticket
        C) Review w/ team    -> hold, no ticket
        (owner disagreement) -> decommission-IP ticket for the dissenter only
        (DR-flagged)         -> keep, tag DR, no removal
  6. Batch ticket creation in chunks of <= 300 (Tufin's stated batch limit).
     HOW tickets are created is set by TICKET_METHOD (see CONFIG):
        "rest"    -> status writeback to an existing ticket (update_metadata REST call)
        "webform" -> new-request creation via Seam-form browser automation (Playwright)
        "prepare" -> write batch files for an RLM-licensed approver (safe default, runs now)
  7. Optionally write certification status back into rule metadata (WRITE_STATUS_BACK),
     the RLM-license workaround the RE suggested.

The GraphQL query/mutation and the ticket-create call are modelled on the shapes seen
in the RE walkthrough (values/ruleUserData for reads, createTicketDraft with
workflowType RECERTIFY_RULES for tickets). Confirm exact field names against a
known-good working example before enabling — they are marked TODO where they live.
"""

import csv
import json
import logging
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional

# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────

DRY_RUN              = True          # True = log intended actions, create/submit nothing

# SecureTrack GraphQL — verify these in Postman (lab environment) before trusting them
SECURETRACK_GRAPHQL  = "<SECURETRACK_GRAPHQL_URL>"   # TODO: lab VIP first, e.g. https://<tufin-lab-vip>/...
GRAPHQL_PAGE_SIZE    = 100                            # RE showed results paginate 100 at a time
GRAPHQL_MAX_PAGES    = 500                            # safety cap; count field tells real total

# AMPS resolution — provided by the AMPS/identity resolver (see team AMPS contact)
AMPS_MODE            = "script"      # "script" (call their code) or "csv" (daily dump)
AMPS_CSV_PATH        = "amps_appid_participants.csv"  # used if AMPS_MODE == "csv"

# Ticket batching — Tufin caps at 300 tickets per batch
TICKET_BATCH_SIZE    = 300

# TICKET_METHOD — HOW tickets get created. This is the big open design decision:
#   "rest"    — status writeback to an existing ticket/task via the clean REST call
#               (PUT .../rule_recertification/update_metadata). Use for updating
#               recertification status on rules that already have a ticket.
#   "webform" — create a brand-new request. New Request has NO clean REST API; it is
#               a JSF/Seam web form, so this path needs browser automation (Playwright)
#               driving the form. Use for generating new recert/decommission tickets.
#   "prepare" — don't submit anything; just write the batch to a file for an approver
#               to submit (recert submission is limited to RLM-licensed admins).
# Start with "prepare" until access + the submission mechanism are settled.
TICKET_METHOD        = "prepare"     # "rest" | "webform" | "prepare"

# WRITE_STATUS_BACK — whether to write certification status back to rule metadata
#   after a recertify (the update_metadata / GraphQL-mutation step). Independent of
#   TICKET_METHOD. Off by default: it needs Tufin write access and returns 403 without
#   the right permission, so leave it off until access is confirmed.
WRITE_STATUS_BACK    = False

# ── Webform settings (only used when TICKET_METHOD == "webform") ──────
# New Request creation is a JSF/Seam web form, not a REST call, so it is driven by
# browser automation. Everything here is captured from ONE real logged-in session —
# fill these in then, not now. The framework below reads them; nothing is hard-coded.
WEBFORM = {
    # Base SecureChange URL (lab first). The New Request page is under this.
    "base_url":        "<SECURECHANGE_BASE_URL>",         # e.g. https://<tufin-lab-vip>
    "new_request_path": "/securechangeworkflow/pages/myRequest/myRequestsMain.seam",

    # Identifies which workflow a new request opens against. From a real session's
    # form/URL (the sample capture showed workflowId=3267, domainId=1 — confirm yours).
    "workflow_id":     "<WORKFLOW_ID>",
    "domain_id":       "1",

    # How to log in. "interactive" opens a visible browser and waits for you to log in
    # once (simplest, good for lab). "storage_state" reuses a saved auth session file.
    "auth_mode":       "interactive",                     # "interactive" | "storage_state"
    "storage_state":   "webform_auth.json",               # used if auth_mode == storage_state

    # Map each batch column -> the form field selector on the New Request page.
    # Read these off the real form once; they vary by workflow version. Left empty
    # so the framework fails loudly with a clear message until they're filled in.
    "field_selectors": {
        # "app_id":       "#request_appId",
        # "source":       "#request_source",
        # "destination":  "#request_destination",
        # "justification":"#request_justification",
        # "submit_button":"#submitRequest",
    },

    "headless":        False,   # False = watch it drive the form (recommended while testing)
    "submit_delay_s":  2,       # pause between submissions so the app isn't hammered
}

# Anchor paths to THIS script's location, not the working directory, so they resolve
# the same no matter where the script is launched or where OneDrive mounts.
SCRIPT_DIR           = Path(__file__).resolve().parent          # .../NPS-Automation/RecertProcessor
SHARED_ROOT          = SCRIPT_DIR.parent                        # .../NPS-Automation

# Where owner responses come from — the SHARED folder the notify tool writes to.
# Same physical folder both tools use: .../NPS-Automation/responses.
# Files are named Firewall_Rules_Recertification_<CORPID>.xlsx.
RESPONSES_DIR        = str(SHARED_ROOT / "responses")

# Rule description convention (per the RE): app ID and owner live in the description,
# one field per line, e.g.  "app_id: APP-XXXX"  and  "owner: <group>"
DESC_APPID_PREFIX    = "app_id:"
DESC_OWNER_PREFIX    = "owner:"

# Output (plan CSVs) stays under this tool's own folder.
OUTPUT_DIR           = str(SCRIPT_DIR / "recert_output")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("recert_processor")


# ─────────────────────────────────────────────
# Data model
# ─────────────────────────────────────────────

class Decision(Enum):
    """The owner's choice from the recertification email."""
    RECERTIFY = "A"       # still needed
    REMOVE    = "B"       # clean up / remove
    REVIEW    = "C"       # review with team
    NONE      = ""        # no response yet


class Action(Enum):
    """What this tool decides to do with a rule."""
    RECERTIFY_TICKET       = "recertify_ticket"
    DECOMMISSION_RULE      = "decommission_rule_ticket"
    DECOMMISSION_IP        = "decommission_ip_ticket"   # owner disagreement, dissenter only
    KEEP_DR                = "keep_dr"                   # DR-flagged, keep + tag
    HOLD_REVIEW            = "hold_review"               # C, or unresolved
    MANUAL                 = "manual"                    # can't be automated (see reason)


@dataclass
class Rule:
    rule_id: str
    name: str = ""
    device: str = ""
    description: str = ""
    app_ids: list = field(default_factory=list)         # may be more than one
    related_tickets: list = field(default_factory=list)
    is_dr: bool = False
    cert_status: str = "uncertified"
    # resolved later:
    owner_group: list = field(default_factory=list)     # full AMPS participant set
    responses: dict = field(default_factory=dict)       # corpid -> Decision


@dataclass
class PlannedAction:
    rule_id: str
    action: Action
    reason: str
    target_corpid: Optional[str] = None                 # set for decommission-IP


# ─────────────────────────────────────────────
# STUBS — external integrations (wire up when the real pieces land)
# ─────────────────────────────────────────────

def graphql_query(query: str, variables: dict) -> dict:
    """
    STUB. Run a GraphQL query against SecureTrack and return the parsed JSON.

    TODO when SECURETRACK_GRAPHQL and auth are known:
      - POST {query, variables} to SECURETRACK_GRAPHQL with the token/session header
      - the RE showed: any Rule Viewer filter works here; results carry a `count`
        field for the total and paginate with offset (see fetch_rules)
      - verify the exact query in Postman against the LAB VIP first
    """
    raise NotImplementedError("graphql_query: connect to SecureTrack GraphQL (see TODO)")


def graphql_mutation(mutation: str, variables: dict) -> dict:
    """
    STUB. Write back to a rule's metadata (e.g. certification status) via GraphQL.

    This is the "clean API" half. Two known-good options for the writeback:
      - GraphQL mutation against SecureTrack (matches the fetch path), OR
      - the SecureChange REST endpoint:
          PUT .../securechange/tickets/{id}/steps/current/tasks/{taskId}/
              rule_recertification/update_metadata
        (per-ticket, per-task; returns 403 without the right task permission)

    TODO: this is the RLM-license workaround the RE described — instead of RLM
    setting cert status, we write it directly. Confirm the exact mutation/endpoint
    shape against a known-good working example before enabling.
    """
    raise NotImplementedError("graphql_mutation: write cert status to rule metadata (see TODO)")


def amps_participants_for_app(app_id: str) -> list:
    """
    STUB. Resolve an app ID to the CURRENT full list of AMPS participants.

    This is the AMPS/identity resolver. Two changes from the base version:
      - it returns ONE participant today; we need ALL of them (the whole group)
      - resolve by app ID directly (already on-token), not by host/IP

    TODO:
      - if AMPS_MODE == "script": import/call their module, return every participant
        (name + corpid + role) plus the director for escalation
      - if AMPS_MODE == "csv": look app_id up in the daily CSV dump instead
    Returning [] means "no owner found" -> falls through to the default group.
    """
    raise NotImplementedError("amps_participants_for_app: call AMPS resolver (see TODO)")


def fetch_ticket_fields(ticket_id: str) -> dict:
    """
    STUB. Pull a related ticket and return its step-1 fields.

    TODO: the app ID lives in a step-1 field whose NAME varies by FUR workflow
    version (sometimes 'ID', sometimes 'SCADA', sometimes another name).
    Return the field dict; caller scans it for anything app-ID-shaped.
    """
    raise NotImplementedError("fetch_ticket_fields: read ticket step-1 fields (see TODO)")


def create_tickets(action: Action, rules_batch: list) -> list:
    """
    Create tickets for one batch (<= TICKET_BATCH_SIZE), dispatching on TICKET_METHOD.

    The HOW is set by TICKET_METHOD in CONFIG, because there are three genuinely
    different mechanisms and the right one depends on access + what's being created:

      "rest"    -> _create_via_rest:    status writeback to an existing ticket/task,
                   the clean PUT .../rule_recertification/update_metadata call.
      "webform" -> _create_via_webform: NEW request creation, which is a JSF/Seam web
                   form (POST myRequestsMain.seam w/ ViewState/workflowId/domainId) and
                   needs browser automation (Playwright), NOT a REST loop.
      "prepare" -> _prepare_batch_file:  submit nothing; write the batch to a file for
                   an RLM-licensed approver to submit. Safe default until access lands.

    Returns a list of created ticket IDs (or prepared-record ids in "prepare"/dry run).
    """
    if TICKET_METHOD == "rest":
        return _create_via_rest(action, rules_batch)
    if TICKET_METHOD == "webform":
        return _create_via_webform(action, rules_batch)
    if TICKET_METHOD == "prepare":
        return _prepare_batch_file(action, rules_batch)
    raise ValueError(f'TICKET_METHOD must be "rest", "webform", or "prepare" — got "{TICKET_METHOD}"')


def _create_via_rest(action: Action, rules_batch: list) -> list:
    """
    STUB. Status writeback via the SecureChange REST endpoint:
      PUT .../securechange/tickets/{id}/steps/current/tasks/{taskId}/
          rule_recertification/update_metadata
    Per-ticket, per-task; returns 403 without the right task permission.
    TODO: confirm the exact payload against a known-good working example.
    """
    raise NotImplementedError('_create_via_rest: update_metadata PUT (TICKET_METHOD="rest")')


def _create_via_webform(action: Action, rules_batch: list) -> list:
    """
    New-request creation by driving the JSF/Seam form with Playwright.

    The FRAMEWORK is complete: it opens a browser, logs in, navigates to New Request,
    and submits one request per batch row, collecting results. The only pieces that
    need a real session to finalise are isolated in two helpers below and in the
    WEBFORM config:
      - WEBFORM["field_selectors"] — the form field IDs (read off the real page once)
      - _webform_login()           — how auth actually completes for your environment
      - _webform_fill_and_submit() — the exact per-row fill, using those selectors

    Until WEBFORM is filled in, this fails loudly with a clear message rather than
    doing anything unpredictable. Nothing about this touches production until you
    point base_url at prod and provide real selectors — keep it on the lab VIP first.
    """
    _webform_preflight()   # verify config is filled in; clear error if not

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        raise RuntimeError("Playwright not installed. Run: py -m pip install playwright "
                           "&& playwright install chromium")

    results = []
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=WEBFORM["headless"])
        context = _webform_context(browser)
        page = context.new_page()

        _webform_login(page)                       # complete auth (see helper)
        _webform_open_new_request(page)            # navigate + select workflow

        for p in rules_batch:
            try:
                ticket_id = _webform_fill_and_submit(page, p)   # one request per row
                results.append(ticket_id)
                log.info(f"  webform: submitted {p.rule_id} -> ticket {ticket_id}")
            except Exception as e:
                log.error(f"  webform: {p.rule_id} failed: {e}")
            page.wait_for_timeout(int(WEBFORM["submit_delay_s"] * 1000))

        context.close()
        browser.close()

    return results


def _webform_preflight():
    """Fail early with a readable message if the webform config isn't filled in yet."""
    missing = []
    if WEBFORM["base_url"].startswith("<"):
        missing.append("base_url")
    if WEBFORM["workflow_id"].startswith("<"):
        missing.append("workflow_id")
    if not WEBFORM["field_selectors"]:
        missing.append("field_selectors (map batch columns to form field IDs)")
    if missing:
        raise NotImplementedError(
            "webform is not configured yet. Fill in WEBFORM in CONFIG from a real "
            "logged-in session: " + ", ".join(missing))


def _webform_context(browser):
    """Build a browser context, reusing a saved auth session if configured."""
    if WEBFORM["auth_mode"] == "storage_state" and Path(WEBFORM["storage_state"]).exists():
        return browser.new_context(storage_state=WEBFORM["storage_state"])
    return browser.new_context()


def _webform_login(page):
    """
    Complete authentication. Two supported modes:
      - "storage_state": context already carries a saved session; just verify we're in.
      - "interactive":   open the login page and wait for you to sign in once, then
                         (optionally) save the session for reuse.
    TODO: fill in the login-page URL and the selector that confirms a successful login
    for your environment. Kept separate so the rest of the framework is stable.
    """
    if WEBFORM["auth_mode"] == "storage_state":
        return

    # interactive: navigate to the app and pause for manual login
    page.goto(WEBFORM["base_url"], wait_until="domcontentloaded")
    log.info("  webform: complete login in the opened browser window...")
    # TODO: replace this wait with a selector that appears only once logged in, e.g.
    #   page.wait_for_selector("#loggedInBanner", timeout=180000)
    page.wait_for_timeout(1000)
    # optionally persist the session so future runs can use storage_state:
    # page.context.storage_state(path=WEBFORM["storage_state"])


def _webform_open_new_request(page):
    """
    Navigate to the New Request page for the configured workflow.
    ViewState is read fresh from the loaded page by Playwright on submit, so it does
    not need to be captured or stored — this is exactly why the browser is required.
    """
    url = (WEBFORM["base_url"].rstrip("/") + WEBFORM["new_request_path"]
           + f"?workflowId={WEBFORM['workflow_id']}&domainId={WEBFORM['domain_id']}")
    page.goto(url, wait_until="domcontentloaded")


def _webform_fill_and_submit(page, planned) -> str:
    """
    Fill the New Request form for one planned action and submit it.
    Uses WEBFORM["field_selectors"] so the field mapping lives in config, not code.

    TODO: this maps a PlannedAction onto form fields. The values a request needs
    (source/destination/justification) come from the rule behind the PlannedAction —
    extend PlannedAction to carry them, or look them up here. Left as the one clearly
    marked spot to finish once the real form's fields are known.
    """
    sel = WEBFORM["field_selectors"]
    # Example shape (uncomment + adjust once selectors are real):
    # page.fill(sel["app_id"], planned.rule_id)
    # page.fill(sel["justification"], planned.reason)
    # page.click(sel["submit_button"])
    # page.wait_for_selector("#ticketCreatedId")
    # return page.inner_text("#ticketCreatedId")
    raise NotImplementedError(
        "_webform_fill_and_submit: map fields using WEBFORM['field_selectors'] "
        "(fill in from the real New Request form)")


def _prepare_batch_file(action: Action, rules_batch: list) -> list:
    """
    Write the batch to a file for an RLM-licensed approver to submit manually.
    Safe to run now — creates no tickets, just a hand-off artifact. Files are keyed
    by action and written fresh per run (the caller clears OUTPUT_DIR at the start).
    """
    Path(OUTPUT_DIR).mkdir(exist_ok=True)
    out = Path(OUTPUT_DIR) / f"batch_{action.value}.csv"
    new_file = not out.exists()
    with open(out, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if new_file:
            w.writerow(["rule_id", "action", "reason", "target_corpid"])
        for p in rules_batch:
            w.writerow([p.rule_id, p.action.value, p.reason, p.target_corpid or ""])
    log.info(f"  prepared {len(rules_batch)} record(s) for approver -> {out.name}")
    return [p.rule_id for p in rules_batch]


# ─────────────────────────────────────────────
# Pipeline — this logic is real
# ─────────────────────────────────────────────

def fetch_rules(rule_filter: str) -> list:
    """
    Page through a GraphQL rule query and return Rule objects.
    Real pagination logic; depends only on the graphql_query stub.
    """
    rules, offset, total = [], 0, None
    for page in range(GRAPHQL_MAX_PAGES):
        variables = {"filter": rule_filter, "first": GRAPHQL_PAGE_SIZE, "offset": offset}
        data = graphql_query(_RULE_QUERY, variables)

        block   = data["data"]["rules"]
        total   = block.get("count", total)
        batch   = block.get("values", [])       # real schema nests rows under `values`
        if not batch:
            break

        for item in batch:
            rules.append(_rule_from_graphql(item))

        offset += GRAPHQL_PAGE_SIZE
        log.info(f"Fetched {len(rules)}"
                 + (f" of {total}" if total is not None else "") + " rules")
        if total is not None and offset >= total:
            break

    return rules


_RULE_QUERY = """
query Rules($filter: String!, $first: Int!, $offset: Int!) {
  rules(filter: $filter) {
    count
    values(first: $first, offset: $offset) {
      id
      name
      idOnDevice
      description
      certificationStatus
      ruleUserData {
        tickets {
          secureChangeTicket
          originTicketId
        }
      }
    }
  }
}
"""  # Modelled on the RE walkthrough. Filter style e.g. "relatedTicket.text exists".
    # Confirm exact field names against a known-good query before enabling.


def _rule_from_graphql(item: dict) -> Rule:
    # related ticket IDs live under ruleUserData.tickets in the real schema
    tickets = []
    for t in (item.get("ruleUserData") or {}).get("tickets", []) or []:
        tid = t.get("secureChangeTicket") or t.get("originTicketId")
        if tid:
            tickets.append(str(tid))

    r = Rule(
        rule_id=str(item.get("id", "")),
        name=item.get("name", ""),
        device=item.get("idOnDevice", ""),          # schema field is idOnDevice
        description=item.get("description", "") or "",
        related_tickets=tickets,
        cert_status=item.get("certificationStatus", "uncertified"),
    )
    r.app_ids = extract_app_ids(r)
    r.is_dr   = "dr" in r.description.lower().split()   # placeholder; a real DR attribute is planned
    return r


def extract_app_ids(rule: Rule) -> list:
    """
    Find app IDs for a rule. First the description, then related tickets.
    Description parsing is real; the ticket path leans on a stub.
    """
    found = []

    for line in rule.description.splitlines():
        line = line.strip()
        if line.lower().startswith(DESC_APPID_PREFIX):
            val = line[len(DESC_APPID_PREFIX):].strip()
            if val:
                found.extend(v.strip() for v in val.split(",") if v.strip())

    if not found:
        for ticket_id in rule.related_tickets:
            try:
                fields = fetch_ticket_fields(ticket_id)
            except NotImplementedError:
                raise
            except Exception as e:
                log.warning(f"Rule {rule.rule_id}: ticket {ticket_id} lookup failed: {e}")
                continue
            found.extend(_scan_fields_for_app_id(fields))

    # legacy IDs (pre-2019) are 1-3 chars and unreliable — flag, don't guess (RE's point)
    return [a for a in dict.fromkeys(found) if _looks_like_modern_app_id(a)]


def _scan_fields_for_app_id(fields: dict) -> list:
    """The app-ID field name varies by workflow version; scan values heuristically."""
    hits = []
    for value in fields.values():
        text = str(value).strip()
        if _looks_like_modern_app_id(text):
            hits.append(text)
    return hits


def _looks_like_modern_app_id(value: str) -> bool:
    """
    Post-2019 app IDs are ~6 chars (often APP-####). Pre-2019 pulled-in IDs are
    1-3 chars and unreliable — those need manual handling, so we
    deliberately reject them here rather than resolve a wrong owner.
    """
    v = value.strip().upper().removeprefix("APP-")
    return len(v) >= 4 and any(c.isdigit() for c in v)


def resolve_owner_group(rule: Rule) -> list:
    """
    Turn a rule's app IDs into the merged, de-duplicated AMPS participant group.
    Merge logic is real; the per-app lookup is a stub.
    """
    group, seen = [], set()
    for app_id in rule.app_ids:
        for person in amps_participants_for_app(app_id):
            corpid = person.get("corpid", "").upper()
            if corpid and corpid not in seen:
                seen.add(corpid)
                group.append(person)
    return group


# ─────────────────────────────────────────────
# Decision logic — the core, fully real
# ─────────────────────────────────────────────

def decide_action(rule: Rule) -> PlannedAction:
    """
    Map a rule + its collected responses to a single planned action.
    Pure function, no I/O — this is the piece the meetings actually pinned down,
    and the piece that won't change when the stubs get wired up.
    """
    responses = {c: d for c, d in rule.responses.items() if d != Decision.NONE}

    # No response yet -> hold. (A real send is gated on owner acknowledgement.)
    if not responses:
        return PlannedAction(rule.rule_id, Action.HOLD_REVIEW, "no response yet")

    decisions = set(responses.values())

    # Anyone unsure -> the whole rule goes to review; don't act on a contested rule.
    if Decision.REVIEW in decisions:
        return PlannedAction(rule.rule_id, Action.HOLD_REVIEW,
                             "at least one owner chose 'review with team'")

    # Unanimous recertify -> recertify. DR just reinforces a keep.
    if decisions == {Decision.RECERTIFY}:
        return PlannedAction(rule.rule_id, Action.RECERTIFY_TICKET, "all owners recertified")

    # Unanimous remove -> but DR overrides removal (DR rules are kept + tagged).
    if decisions == {Decision.REMOVE}:
        if rule.is_dr:
            return PlannedAction(rule.rule_id, Action.KEEP_DR,
                                 "all chose remove, but rule is DR-flagged — keep + tag DR")
        return PlannedAction(rule.rule_id, Action.DECOMMISSION_RULE, "all owners chose remove")

    # Disagreement (some keep, some remove). Can't remove a rule someone still needs.
    # Owner-disagreement rule: dissenters who chose REMOVE get a decommission-IP ticket for
    # THEIR access only; the rule itself stays for the owners who recertified.
    removers = [c for c, d in responses.items() if d == Decision.REMOVE]
    if len(removers) == 1:
        return PlannedAction(rule.rule_id, Action.DECOMMISSION_IP,
                             "owners disagree — decommission IP for the sole remover",
                             target_corpid=removers[0])

    # More than one remover but not unanimous -> genuinely ambiguous, send to a human.
    return PlannedAction(rule.rule_id, Action.MANUAL,
                         f"owners disagree — {len(removers)} want removal, others recertify")


# ─────────────────────────────────────────────
# Response loading (interim: returned spreadsheets)
# ─────────────────────────────────────────────

def load_responses(rules_by_id: dict) -> None:
    """
    Read returned recertification spreadsheets from RESPONSES_DIR and attach each
    owner's per-rule decision to the matching Rule. Filename carries the CorpID:
    Firewall_Rules_Recertification_<CORPID>.xlsx. Real logic; needs openpyxl at runtime.
    """
    folder = Path(RESPONSES_DIR)
    if not folder.exists():
        log.info(f"No {RESPONSES_DIR}/ yet — no responses to load")
        return

    try:
        from openpyxl import load_workbook
    except ImportError:
        log.error("openpyxl not installed — run: py -m pip install openpyxl")
        return

    for path in folder.glob("Firewall_Rules_Recertification_*.xlsx"):
        corpid = path.stem.rsplit("_", 1)[-1].upper()
        wb = load_workbook(path, read_only=True, data_only=True)
        ws = wb.active
        headers = [str(c.value).strip().lower() if c.value else "" for c in next(ws.iter_rows())]
        try:
            id_col  = headers.index("rule id")
            dec_col = headers.index("decision")
        except ValueError:
            log.warning(f"{path.name}: missing 'Rule ID' or 'Decision' column, skipping")
            wb.close()
            continue

        applied = 0
        for row in ws.iter_rows(min_row=2, values_only=True):
            rid = str(row[id_col]).strip() if row[id_col] is not None else ""
            raw = str(row[dec_col]).strip().upper()[:1] if row[dec_col] else ""
            rule = rules_by_id.get(rid)
            if rule and raw in ("A", "B", "C"):
                rule.responses[corpid] = Decision(raw)
                applied += 1
        wb.close()
        log.info(f"{path.name}: applied {applied} decision(s) from {corpid}")


# ─────────────────────────────────────────────
# Batching + execution
# ─────────────────────────────────────────────

def chunked(items: list, size: int):
    for i in range(0, len(items), size):
        yield items[i:i + size]


def execute_plan(planned: list) -> None:
    """
    Group planned actions by type and create tickets in <= TICKET_BATCH_SIZE batches,
    via whatever TICKET_METHOD selects. Batching and the "prepare" method are real;
    "rest"/"webform" are stubbed. DRY_RUN suppresses anything that would submit — but
    "prepare" still runs under DRY_RUN, because it only writes hand-off files.
    """
    ticketable = {
        Action.RECERTIFY_TICKET,
        Action.DECOMMISSION_RULE,
        Action.DECOMMISSION_IP,
    }

    by_action = {}
    for p in planned:
        by_action.setdefault(p.action, []).append(p)

    for action, group in by_action.items():
        if action not in ticketable:
            log.info(f"{action.value}: {len(group)} rule(s) — no ticket (informational)")
            continue

        n_batches = -(-len(group) // TICKET_BATCH_SIZE)
        log.info(f"{action.value}: {len(group)} rule(s) -> {n_batches} batch(es) "
                 f"of <= {TICKET_BATCH_SIZE} via '{TICKET_METHOD}'")

        # "prepare" writes files only, so it runs even in dry run. The submitting
        # methods ("rest"/"webform") are held back while DRY_RUN is on.
        submitting = TICKET_METHOD in ("rest", "webform")
        for i, batch in enumerate(chunked(group, TICKET_BATCH_SIZE), 1):
            if DRY_RUN and submitting:
                log.info(f"  [DRY RUN] batch {i}: would create {len(batch)} {action.value}")
                continue
            ids = create_tickets(action, batch)
            log.info(f"  batch {i}: {len(ids)} record(s) via '{TICKET_METHOD}'")


def write_plan_csv(planned: list, path: str) -> None:
    Path(OUTPUT_DIR).mkdir(exist_ok=True)
    out = Path(OUTPUT_DIR) / path
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["rule_id", "action", "reason", "target_corpid"])
        for p in planned:
            w.writerow([p.rule_id, p.action.value, p.reason, p.target_corpid or ""])
    log.info(f"Wrote plan: {out}")


# ─────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────

def main(rule_filter: str = "certification_status:uncertified"):
    log.info("recert_processor — SCAFFOLD run")
    log.info(f"TICKET_METHOD = '{TICKET_METHOD}' | WRITE_STATUS_BACK = {WRITE_STATUS_BACK} "
             f"| DRY_RUN = {DRY_RUN}")
    if DRY_RUN:
        log.info("DRY RUN — submitting methods are held back; 'prepare' still writes files")

    # start each run with a clean output folder so batch/plan files reflect only this run
    out_dir = Path(OUTPUT_DIR)
    if out_dir.exists():
        for old in out_dir.glob("*.csv"):
            old.unlink()

    # 1. pull rules
    rules = fetch_rules(rule_filter)
    rules_by_id = {r.rule_id: r for r in rules}
    log.info(f"Fetched {len(rules)} rule(s)")

    # 2-3. resolve owner groups
    for r in rules:
        r.owner_group = resolve_owner_group(r)

    # 4. load owner responses
    load_responses(rules_by_id)

    # 5. decide
    planned = [decide_action(r) for r in rules]
    summary = {}
    for p in planned:
        summary[p.action.value] = summary.get(p.action.value, 0) + 1
    log.info("Planned actions: " + ", ".join(f"{k}={v}" for k, v in sorted(summary.items())))

    # 6. batch + execute (via TICKET_METHOD)
    execute_plan(planned)

    # 7. optional cert-status writeback — independent of TICKET_METHOD, opt-in, not in dry run
    if WRITE_STATUS_BACK and not DRY_RUN:
        recertified = [p for p in planned if p.action == Action.RECERTIFY_TICKET]
        log.info(f"Writing cert status back for {len(recertified)} recertified rule(s)")
        for p in recertified:
            graphql_mutation(_STATUS_MUTATION, {"ruleId": p.rule_id, "status": "certified"})
    elif WRITE_STATUS_BACK and DRY_RUN:
        log.info("WRITE_STATUS_BACK is on but DRY_RUN suppresses it — no metadata written")

    write_plan_csv(planned, "recert_plan.csv")
    log.info("Done (scaffold — external calls stubbed)")


# Status-writeback mutation for the WRITE_STATUS_BACK step. Shape modelled on the
# update_metadata concept; confirm against a working example before enabling.
_STATUS_MUTATION = """
mutation SetCert($ruleId: ID!, $status: String!) {
  updateRuleCertification(id: $ruleId, status: $status) { id certificationStatus }
}
"""  # TODO: reconcile with the real update_metadata / mutation shape.


# The real ticket-create mutation shape seen in the RE walkthrough. ruleUids takes an
# array (so a whole batch maps straight on), there's a native dryRun flag, and it
# returns invalidRules + per-error detail. workflowType/workflowName per environment.
_CREATE_TICKET_MUTATION = """
mutation CreateRecertTickets($ruleUids: [String!]!, $dryRun: Boolean!) {
  ruleOperations {
    createTicketDraft(input: {
      ruleUids: $ruleUids,
      workflowType: RECERTIFY_RULES,
      workflowName: "Rule Recert",
      subject: "Rule Recertification",
      dryRun: $dryRun
    }) {
      invalidRules { reason ruleUid }
      resultStatus { successful errors { errorCode errorMessage } }
    }
  }
}
"""  # Confirm workflowName/subject against the live workflow before enabling.


if __name__ == "__main__":
    main()

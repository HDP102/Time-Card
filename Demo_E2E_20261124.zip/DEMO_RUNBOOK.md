# End-to-End Recertification Demo – Runbook (11/24, 3:30 PM PST)

**Flow:** reminder email → escalation → final notice → not recertified → account disabled in prod by MEA
**Test account:** Dave King (**DHKG**). Swapnil (S9CH) is IT Lead, Nitin (N6B4) is Client Owner. Hardik is Bcc'd on every email.

---

## Setup (before the call)

1. Copy `Escalation\escalation_notify_demo.py` and `Escalation\mea_disable.py` into your `Escalation\` folder. They replace your `mea_disable.py`, which gains two flags: `--env` and `--live`.
2. Copy `SharedData\DEMO_Recert_Scope.xlsx` into your `SharedData\` folder, the one next to `Escalation\`.
3. Open PowerShell in the `Escalation\` folder.
4. Rehearse, which disables nothing:
   ```
   py escalation_notify_demo.py SME
   py escalation_notify_demo.py disable
   ```
   - Check that Dave's reminder arrives (you're Bcc'd).
   - The second command should end with `MEA handoff (command): command ran (exit 0)`. That was a dry run.
5. Have Outlook open and the Excel file ready to show.

**Do not run `--live-disable` before the call.**

---

## On the call

### Step 0: Show the input
**Show:** `DEMO_Recert_Scope.xlsx`

> "This is our input: three firewall rules for a demo app. Each one has its owners from AMPS: Dave as IT SME, Swapnil as IT Lead, Nitin as Client Owner. The certification date is blank, so none of these rules has been recertified. In the real campaign this list comes from the rule reports, and the certification status comes from Tufin."

### Step 1: First reminder (to the IT SME)
```
py escalation_notify_demo.py SME
```
**Show:** the email in Outlook. The output says `sent=1`.

> "The first stage is a reminder to the IT SME. The script groups all the outstanding rules by owner, so each owner gets one email with every rule listed and an Excel attachment, instead of one email per rule. Every email is also saved as evidence for audit."

### Step 2: Escalation (adds the IT Lead)
```
py escalation_notify_demo.py Lead
```
**Show:** the email, with Swapnil now on CC.

> "No response, so it escalates. Same email to the SME, and now the IT Lead is copied. In production these stages run on a schedule counting down to the deadline; today we're triggering each one by hand to compress it into a few minutes."

### Step 3: Final notice (leadership plus the disable warning)
```
py escalation_notify_demo.py Owner
```
**Show:** the email. Nitin is CC'd, and the body has the account-disable warning.

> "This is the final notice. Leadership is copied, and the email clearly says the SME accounts will be disabled if the rules aren't recertified by the deadline. Only the IT SME and IT SME Backup are ever disabled, never the IT Lead or leadership."

### Step 4: Deadline passes, so disable
```
py escalation_notify_demo.py disable --live-disable
```
**Show:**
- the output line `Disable list: 1 account(s)`
- `escalation_output_demo\disable_list_20261124.csv`
- the requestID in `Escalation\mea_output\mea_requests.csv`

> "The deadline has passed and the rules still aren't recertified. The script builds the disable list, which is just Dave's account here, and hands it to MEA. Our script doesn't disable anything itself: it calls the MEA API through MuleSoft with a certificate-based Entra token, and SailPoint does the disable. We get back a request ID right away. MEA's own email confirms the disable, and the account's manager is notified too."

> "Built-in guardrails: five accounts or fewer are processed directly. More than five creates an approval in MEA for each account, approved by Swapnil, Nitin, Megan or Rey. Every request and response is logged for audit."

### Step 5: Confirm
**Show:** the MEA confirmation email, or have someone check DHKG in SailPoint.

> "That's the closed loop: notify, escalate, and disable on non-response, with evidence at every step."

---

## After the call
- Ask Hareesh or Swapnil to **re-enable DHKG**.
- `mea_disable.py` still has `DRY_RUN = True` in the file. Only `--live` overrides it, so nothing else changed.
- The demo output is under `Escalation\escalation_output_demo\`, separate from the real runs.

## If something fails
| Symptom | Likely cause / what to say |
|---|---|
| Email send fails for DHKG | The test account has no mailbox. Say "the test account has no mailbox; in prod these go to real owners" and continue. |
| `No scope files matching` | The Excel file isn't in `SharedData\` next to `Escalation\`. |
| MEA step: `Entra token failed` | Check that the prod certificate files are in `C:\Users\H2PR\certs\mea-prod\`. |
| MEA step: HTTP error | Show the response in `mea_output\`, then explain that prod validation (token, JWT policy) already passed today. |

"""
sc_recert_submit.py - create RLM recertification tickets through the SecureChange REST
API and walk them to Closed, with each rule's owner and decision recorded in the ticket.

Why this exists
    recert_processor.py uses SecureTrack GraphQL `createTicketDraft`, which only makes
    Drafts; drafts cannot be submitted by API (the Requests API has search + cancel only).
    This script creates real tickets instead, one per ledger batch, so ticket N covers
    the same rules as draft N. Cancel the drafts once the tickets are confirmed.

How a ticket moves (RLM Rule Recertification Workflow, from ticket 139744)
    1 Open Recertification Request   devices -> bindings -> rules          (POST)
    2 Recertification Decision       + rule_recertification_info per rule  (PUT task, DONE)
    3 Update Recertification Data    update_metadata, then DONE            -> Closed

Identifiers SecureChange needs come from SecureTrack REST, by device name + rule name:
    device id (management_id), rule uid {GUID}, binding uid. Cached per device.

Owner per rule: first CorpID found in OWNER_ROLES order in the reporting views
("Last, First (CORPID)"), email CORPID@EMAIL_DOMAIN.

Run from RecertProcessor/:   py sc_recert_submit.py
Start with DRY_RUN = True, then one small live ticket, then the batches Swapnil asked for.
"""
import getpass
import json
import os
import re
import sys
import time
from datetime import date, datetime, timedelta
from pathlib import Path
from urllib.parse import urlparse

import requests
import urllib3
from openpyxl import load_workbook

import recert_processor as r

urllib3.disable_warnings()

# ═══════════════════════════ CONFIG ═══════════════════════════
DRY_RUN = True            # True: resolve everything, save the payload, change nothing
STOP_AFTER = "create"     # "create"   - make the ticket, stop (check it in SecureChange)
                          # "decision" - also fill + complete step 2
                          # "close"    - walk it all the way to Closed
BATCHES = [1]             # ledger batch numbers (= draft numbers), e.g. [1,2,3,4,5]
TEST_RULE_LIMIT = 5       # cap rules per ticket for the first test; 0 = full batch

WORKFLOW_NAME = "RLM Rule Recertification Workflow"
SUBJECT = "Recertify Firewall Rules - NPS - batch {batch}"
PRIORITY = "Normal"
EXPIRY_DAYS = 365                     # Megan's sample used ~1 year
EMAIL_DOMAIN = "pge.com"
DESCRIPTION = "Recertified per owner decision in {sheet} ({date}). NPS recertification automation."
OWNER_ROLES = ["Client Owner", "IT SME", "IT Lead", "IT SME Backup", "IT Lead Delegate"]
FALLBACK_OWNER = ""       # CorpID to use when a rule has no owner; "" = leave owner blank

STEP_OPEN = "Open Recertification Request"
STEP_DECISION = "Recertification Decision"
STEP_UPDATE = "Update Recertification Data"
# ══════════════════════════════════════════════════════════════

HOST = urlparse(r.SECURETRACK_GRAPHQL).netloc
SC = f"https://{HOST}/securechangeworkflow/api/securechange"
ST = f"https://{HOST}/securetrack/api"
OUT = Path(r.OUTPUT_DIR)
CACHE_DIR = OUT / "st_rules_cache"
SC_LEDGER = OUT / "sc_tickets.jsonl"
JSON_HDRS = {"Accept": "application/json", "Content-Type": "application/json"}
CORPID_RE = re.compile(r"\(([A-Za-z0-9]{3,8})\)\s*$")

AUTH = None


def L(x):
    return [] if x is None else (x if isinstance(x, list) else [x])


def log(msg):
    print(f"{datetime.now():%H:%M:%S} {msg}", flush=True)


def call(method, url, **kw):
    """HTTP with Tufin's error text surfaced. Returns the response; raises on non-2xx."""
    resp = requests.request(method, url, auth=AUTH, headers=JSON_HDRS, verify=False,
                            timeout=300, **kw)
    if not 200 <= resp.status_code < 300:
        text = resp.text
        m = re.search(r"<message>(.*?)</message>", text, re.S)
        raise RuntimeError(f"{method} {url} -> {resp.status_code}: {m.group(1) if m else text[:800]}")
    return resp


# ─────────────────────────── inputs ───────────────────────────

def ledger_batches():
    """Recertify batches from recert_processor's ledger, in order. Batch N = draft N."""
    out = []
    for line in open(r.LEDGER_PATH, encoding="utf-8"):
        if line.strip():
            rec = json.loads(line)
            if rec.get("workflow_type") == r.RECERTIFY_WORKFLOW_TYPE:
                out.append(rec["uids"])
    return out


def mapping_by_uid():
    """GraphQL uid -> (device name, rule name), from the Rule-ID mapping workbook."""
    wb = load_workbook(r.data_path(r.MAPPING_PATH), read_only=True, data_only=True)
    ws = next((wb[n] for n in wb.sheetnames
               if n.strip().lower() == r.MAPPING_SHEET.lower()), wb.active)
    rows = ws.iter_rows(values_only=True)
    h = [str(x).strip() if x is not None else "" for x in next(rows)]
    d, n, u = h.index(r.MAP_DEVICE_COLUMN), h.index(r.MAP_RULE_COLUMN), h.index(r.MAP_UID_COLUMN)
    out = {}
    for row in rows:
        if row[u]:
            out[str(row[u]).strip()] = (str(row[d] or "").strip(), str(row[n] or "").strip())
    wb.close()
    return out


def owners_by_rule():
    """(DEVICE||RULE) -> (corpid, role, sheet) from the reporting views."""
    out = {}
    for path in r.resolve_inputs(r.REPORT_PATH):
        wb = load_workbook(path, read_only=True, data_only=True)
        ws = wb[wb.sheetnames[0]]
        rows = ws.iter_rows(values_only=True)
        header = [str(x).strip() if x is not None else "" for x in next(rows, [])]
        di, _ = r.find_column(header, r.DEVICE_COLUMN)
        ri, _ = r.find_column(header, r.RULE_NAME_COLUMN)
        roles = [(role, header.index(role)) for role in OWNER_ROLES if role in header]
        if di is None or ri is None or not roles:
            log(f"  {path.name}: no device/rule/owner columns - skipped")
            wb.close()
            continue
        for row in rows:
            k = r._key(row[di], row[ri])
            if k in out:
                continue
            for role, i in roles:
                m = CORPID_RE.search(str(row[i] or ""))
                if m:
                    out[k] = (m.group(1).upper(), role, path.name)
                    break
        wb.close()
    return out


# ─────────────────────── SecureTrack lookups ───────────────────────

_dev_ids = {}


def st_device_id(name):
    if name not in _dev_ids:
        data = call("GET", f"{ST}/devices", params={"name": name}).json()
        devs = [d for d in L((data.get("devices") or {}).get("device"))
                if str(d.get("name", "")).strip().lower() == name.strip().lower()]
        _dev_ids[name] = devs[0]["id"] if len(devs) == 1 else None
        if len(devs) != 1:
            log(f"  device {name!r}: {len(devs)} exact matches in SecureTrack - rules skipped")
    return _dev_ids[name]


def _binding_uid(rule):
    b = rule.get("binding")
    for item in L(b):
        if isinstance(item, dict):
            if item.get("uid"):
                return item["uid"]
            inner = item.get("binding")
            if isinstance(inner, dict) and inner.get("uid"):
                return inner["uid"]
    return rule.get("binding_uid")


_rule_idx = {}


def st_rules(dev_id):
    """rule name (normalised) -> [(uid, binding_uid), ...] for one device. Cached to disk."""
    if dev_id in _rule_idx:
        return _rule_idx[dev_id]
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cf = CACHE_DIR / f"{dev_id}.json"
    if cf.exists() and time.time() - cf.stat().st_mtime < 24 * 3600:
        idx = json.loads(cf.read_text(encoding="utf-8"))
    else:
        log(f"  fetching rules for device {dev_id} from SecureTrack (can take a minute)...")
        data = call("GET", f"{ST}/devices/{dev_id}/rules").json()
        idx = {}
        for x in L((data.get("rules") or {}).get("rule")):
            idx.setdefault(r._norm(x.get("name")), []).append([x.get("uid"), _binding_uid(x)])
        cf.write_text(json.dumps(idx), encoding="utf-8")
    _rule_idx[dev_id] = idx
    return idx


# ─────────────────────────── payloads ───────────────────────────

def resolve_batch(uids, mapping, owners):
    """-> (resolved rules, problems). Each rule: dev_id, uid, binding, owner, sheet."""
    ok, problems = [], []
    for g in uids:
        if g not in mapping:
            problems.append((g, "not in mapping workbook"))
            continue
        dev, rule = mapping[g]
        dev_id = st_device_id(dev)
        if dev_id is None:
            problems.append((g, f"device {dev!r} not found in SecureTrack"))
            continue
        hits = st_rules(dev_id).get(r._norm(rule), [])
        if len(hits) != 1:
            problems.append((g, f"{dev} / {rule}: {len(hits)} matches on device {dev_id}"))
            continue
        uid, binding = hits[0]
        if not uid or not binding:
            problems.append((g, f"{dev} / {rule}: missing uid or binding"))
            continue
        owner = owners.get(r._key(dev, rule))
        ok.append({"graphql_id": g, "device": dev, "rule": rule, "dev_id": int(dev_id),
                   "uid": uid, "binding": binding,
                   "owner": owner[0] if owner else FALLBACK_OWNER,
                   "owner_role": owner[1] if owner else "",
                   "sheet": owner[2] if owner else ""})
    return ok, problems


def devices_block(rules):
    by_dev = {}
    for x in rules:
        by_dev.setdefault(x["dev_id"], {}).setdefault(x["binding"], []).append(x["uid"])
    return {"device": [
        {"management_id": dev_id,
         "bindings": {"binding": [
             {"binding_uid": b, "rules": {"rule": [{"uid": u} for u in uids]}}
             for b, uids in bindings.items()]}}
        for dev_id, bindings in by_dev.items()]}


def infos_block(rules):
    today = date.today().isoformat()
    expiry = (date.today() + timedelta(days=EXPIRY_DAYS)).isoformat()
    infos = []
    for x in rules:
        info = {"@xsi.type": "certify", "binding_uid": x["binding"], "rule_uid": x["uid"],
                "description": DESCRIPTION.format(sheet=x["sheet"] or "reporting view", date=today),
                "certification_expiration_date": expiry}
        if x["owner"]:
            info["business_owner"] = x["owner"]
            info["business_owner_email"] = f"{x['owner']}@{EMAIL_DOMAIN}"
        infos.append(info)
    return {"rule_recertification_info": infos}


def create_payload(batch_no, rules):
    return {"ticket": {
        "subject": SUBJECT.format(batch=batch_no),
        "priority": PRIORITY,
        "workflow": {"name": WORKFLOW_NAME},
        "steps": {"step": [{"name": STEP_OPEN, "tasks": {"task": [{"fields": {"field": [{
            "@xsi.type": "rule_recertification",
            "name": "Recertification Field",
            "devices": devices_block(rules),
        }]}}]}}]},
    }}


# ─────────────────────────── SecureChange ───────────────────────────

def sc_ledger(rec):
    rec["ts"] = datetime.now().isoformat(timespec="seconds")
    with open(SC_LEDGER, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec) + "\n")
        f.flush()
        os.fsync(f.fileno())


def sc_history():
    """Read the SC ledger. Returns (ticketed, open_tickets):
        ticketed      - every GraphQL rule id already in ANY ticket we created
        open_tickets  - {ticket_id: {"batch", "uids", "stage"}} for tickets not yet closed
    Tracking by rule (not by batch) means a small test ticket and the rest of the
    batch never overlap, and no rule is ever put in a second ticket."""
    tickets = {}
    if SC_LEDGER.exists():
        for line in open(SC_LEDGER, encoding="utf-8"):
            if line.strip():
                rec = json.loads(line)
                t = tickets.setdefault(rec["ticket_id"], {"batch": rec["batch"], "uids": []})
                if rec.get("uids"):
                    t["uids"] = rec["uids"]
                t["stage"] = rec["stage"]
    ticketed = {u for t in tickets.values() for u in t["uids"]}
    open_tickets = {tid: t for tid, t in tickets.items() if t["stage"] != "closed"}
    return ticketed, open_tickets


def get_ticket(tid):
    return call("GET", f"{SC}/tickets/{tid}").json()["ticket"]


def current(t):
    """(step name, task id, field dict) for the ticket's current step."""
    name = (t.get("current_step") or {}).get("name")
    for step in L((t.get("steps") or {}).get("step")):
        if step.get("name") == name:
            task = L((step.get("tasks") or {}).get("task"))[0]
            field = L((task.get("fields") or {}).get("field"))[0]
            return name, task["id"], field
    return name, None, None


def complete_task(tid, task_id, field):
    body = {"task": {"id": task_id, "status": "DONE", "fields": {"field": [field]}}}
    call("PUT", f"{SC}/tickets/{tid}/steps/current/tasks/{task_id}", data=json.dumps(body))


def advance(tid, batch_no, rules):
    """Walk the ticket forward until STOP_AFTER or Closed."""
    for _ in range(8):
        t = get_ticket(tid)
        status = t.get("status", "")
        step, task_id, field = current(t)
        log(f"  ticket {tid}: status={status!r} step={step!r}")
        if "closed" in status.lower() or step is None:
            sc_ledger({"batch": batch_no, "ticket_id": tid, "stage": "closed"})
            return True
        if step == STEP_OPEN:
            complete_task(tid, task_id, field)
        elif step == STEP_DECISION:
            field["rule_recertification_infos"] = infos_block(rules)
            complete_task(tid, task_id, field)
            sc_ledger({"batch": batch_no, "ticket_id": tid, "stage": "decision"})
            if STOP_AFTER == "decision":
                log("  STOP_AFTER='decision' - stopping here")
                return True
        elif step == STEP_UPDATE:
            call("PUT", f"{SC}/tickets/{tid}/steps/current/tasks/{task_id}"
                        f"/rule_recertification/update_metadata")
            time.sleep(3)
            _, task_id, field = current(get_ticket(tid))
            if task_id:
                complete_task(tid, task_id, field)
        else:
            log(f"  unexpected step {step!r} - stopping so a person can look")
            return False
        time.sleep(2)
    log("  ticket did not close within 8 steps - check it in SecureChange")
    return False


# ─────────────────────────── main ───────────────────────────

def main():
    global AUTH
    user = os.environ.get("SECURETRACK_USER") or input("Tufin username: ").strip()
    pwd = os.environ.get("SECURETRACK_PASSWORD") or getpass.getpass("Tufin password: ")
    AUTH = (user, pwd)

    log(f"Host {HOST} | DRY_RUN={DRY_RUN} | STOP_AFTER={STOP_AFTER} | "
        f"BATCHES={BATCHES} | TEST_RULE_LIMIT={TEST_RULE_LIMIT}")
    batches = ledger_batches()
    log(f"Ledger has {len(batches)} recertify batch(es)")
    log("Loading mapping workbook and reporting-view owners...")
    mapping, owners = mapping_by_uid(), owners_by_rule()
    log(f"  {len(mapping):,} mapped rules, {len(owners):,} rules with an owner")
    for n in BATCHES:
        if not 1 <= n <= len(batches):
            log(f"Batch {n}: out of range (1-{len(batches)}) - skipped")
            continue
        ticketed, open_tickets = sc_history()

        # 1. Finish any ticket from an earlier run of this batch before creating another.
        #    A run that resumes a ticket does not also create one for the same batch -
        #    run again for the rest, so each run does one clear thing per batch.
        mine = {tid: t for tid, t in open_tickets.items() if t["batch"] == n}
        if mine and not DRY_RUN:
            if STOP_AFTER == "create":
                log(f"\nBatch {n}: ticket(s) {', '.join(mine)} still open - set STOP_AFTER to "
                    f"'decision' or 'close' to finish them. Nothing new created.")
                continue
            for tid, t in mine.items():
                log(f"\nBatch {n}: resuming ticket {tid} (stage {t['stage']})")
                rules, _ = resolve_batch(t["uids"], mapping, owners)
                if not advance(tid, n, rules):
                    raise SystemExit("Stopped - fix the issue above before the next batch.")
            log(f"Batch {n}: resumed ticket(s) finished - run again to submit the rest of the batch")
            continue

        # 2. Only rules from this batch that are not already in one of our tickets.
        remaining = [u for u in batches[n - 1] if u not in ticketed]
        uids = remaining[:TEST_RULE_LIMIT or None]
        log(f"\nBatch {n}: {len(batches[n - 1])} rule(s) in batch, "
            f"{len(batches[n - 1]) - len(remaining)} already ticketed, submitting {len(uids)}")
        if not uids:
            continue

        rules, problems = resolve_batch(uids, mapping, owners)
        no_owner = sum(1 for x in rules if not x["owner"])
        log(f"  resolved {len(rules)}, problems {len(problems)}, without owner {no_owner}")
        for g, why in problems[:10]:
            log(f"    skip {g}: {why}")
        if not rules:
            log("  nothing to submit")
            continue

        payload = create_payload(n, rules)
        preview = OUT / f"sc_preview_batch{n}.json"
        preview.write_text(json.dumps({"create": payload,
                                       "decision": infos_block(rules),
                                       "rules": rules,
                                       "problems": problems}, indent=2), encoding="utf-8")
        log(f"  payload saved to {preview.name}")
        if DRY_RUN:
            continue

        resp = call("POST", f"{SC}/tickets/", data=json.dumps(payload))
        loc = resp.headers.get("Location", "")
        tid = loc.rstrip("/").split("/")[-1] if loc else None
        if not tid:
            raise SystemExit(f"Ticket created but no id returned (Location={loc!r}) - "
                             f"find it in SecureChange and add it to {SC_LEDGER.name} "
                             f"before re-running, or the rules will be submitted again.")
        sc_ledger({"batch": n, "ticket_id": tid, "stage": "created",
                   "count": len(rules), "uids": [x["graphql_id"] for x in rules]})
        log(f"  CREATED ticket {tid}")

        if STOP_AFTER == "create":
            log("  STOP_AFTER='create' - check the ticket in SecureChange")
            continue
        if not advance(tid, n, rules):
            raise SystemExit("Stopped - fix the issue above before the next batch.")

    log("\nDone.")


if __name__ == "__main__":
    try:
        main()
    except RuntimeError as e:
        log(f"ERROR {e}")
        sys.exit(1)

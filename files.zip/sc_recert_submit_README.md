# sc_recert_submit.py

Creates **RLM Rule Recertification** tickets through the SecureChange REST API and walks
them to **Closed**, recording each rule's owner and decision in the ticket.

It replaces the draft step. `recert_processor.py` creates Drafts through SecureTrack
GraphQL (`createTicketDraft`), and the API cannot submit a draft: the Requests API only
has `search` and `cancel`. This script creates real tickets for the same rules instead.
**Ticket batch N covers the same rules as draft N.** Cancel the drafts once the tickets
are confirmed.

After any live run, run **`reconcile_tickets.py`** to see which rules are in which
ticket and which were not ticketed, and why. See *Checking what was ticketed* below.

## Two sources of rules (`SOURCE`)

| `SOURCE` | Rules come from | Batches | Used for |
|---|---|---|---|
| `"ledger"` (default) | `recert_processor.py`'s batches in `submitted_rules.jsonl`, i.e. the owners' Recertify decisions | 1–123 (ticket N = draft N) | The main campaign |
| `"sweep"` | **Both** of the others: every ledger and rule-report rule not in a ticket yet | 2001 upward, continuing after earlier sweeps | Picking up leftovers (e.g. skips that now resolve) in a few full tickets instead of one tiny ticket per batch |
| `"reports"` | Tufin rule report exports in `SharedData/` matching `RULE_REPORT_GLOB` (`*Rule_report*.xlsx`), e.g. Megan's CORPSEC / AMI / ADMS / base / Shadowed / Crit-HighRule lists | 1001 upward, 300 rules each | "Recertify everything in these lists" – no decision column needed |

**Report files:** the header row is found automatically (CSV exports have metadata lines
on top). The script needs the **SecureTrack Rule ID**, **Device Name** and **Rule Name**
columns. The owner is the first CorpID in **Business Owner**, then **Application Owner**.
It's optional: the owner is only used if the script runs the decision step. A rule that
appears in more than one file is used once. App-IDs are not needed for recertification.

Both sources share the same ticket ledger. **A rule already in any of our tickets is never
submitted again, whichever source it comes from.** So running `"reports"` after the main
campaign only tickets what is genuinely left. `BATCHES` counts within the source: with
`SOURCE = "reports"`, `BATCHES = [1]` means batch 1001, and `"all"` means every report
batch.

## What it needs

| Input | Where | Used for |
|---|---|---|
| `submitted_rules.jsonl` | `recert_output/` (written by `recert_processor.py`) | The rules in each batch |
| `Rule-ID-Mapping.xlsx` | `SharedData/` | Rule ID → device name + rule name |
| `report_*.xlsx` | `SharedData/` | Rule owner (CorpID from the role columns) |
| Tufin account | Prompted, or `SECURETRACK_USER` / `SECURETRACK_PASSWORD` | SecureTrack + SecureChange REST (basic auth) |

The account must be a participant in the workflow's first step. `ticketAPI` is the
production account; its password is in PAPM.

## How a ticket is built

| Step | What the script does |
|---|---|
| Resolve | For each rule, SecureTrack REST gives the device ID, the rule `uid` `{GUID}` and the binding UID, looked up by device name + rule name. Cached per device for 24h in `recert_output/st_rules_cache/`. |
| 1. Open Recertification Request | `POST /tickets` with the rules grouped as device → binding → rules. |
| 2. Recertification Decision | Adds one `certify` entry per rule: owner CorpID, owner email, description, expiry date. Completes the step. |
| 3. Update Recertification Data | Runs `update_metadata` (writes the result to SecureTrack) and completes the step. The ticket closes. |

**Owner:** the first CorpID found in `OWNER_ROLES` order (Client Owner, IT SME, IT Lead,
IT SME Backup, IT Lead Delegate). Cells look like `Last, First (CORPID)`; `0` means
empty. The email is `CORPID@pge.com`.

## Settings (top of the script)

| Setting | Default | Meaning |
|---|---|---|
| `SOURCE` | `"ledger"` | `"ledger"` = recert_processor batches · `"reports"` = Tufin rule reports · `"sweep"` = leftovers from both (see above) |
| `DRY_RUN` | `True` | Resolve everything and save the payload; change nothing in Tufin |
| `STOP_AFTER` | `"create"` | `create` = make the ticket and stop · `decision` = also complete step 2 · `close` = walk to Closed |
| `BATCHES` | `[1]` | Ledger batch numbers to work on: `[1,2,3,4,5]`, a range `list(range(6, 124))` (6–123; the end number is excluded), or `"all"` |
| `TEST_RULE_LIMIT` | `5` | Cap on rules per ticket for testing; `0` = the whole batch |
| `EXPIRY_DAYS` | `365` | Certification expiry, from today |
| `DESCRIPTION` | see script | Per-rule justification; `{sheet}` and `{date}` are filled in |
| `OWNER_ROLES` | see above | Which role columns are used for the owner, in priority order |
| `FALLBACK_OWNER` | `""` | CorpID to use when a rule has no owner; blank leaves it empty |

## Running it

From `RecertProcessor/`:

```
py sc_recert_submit.py
```

Recommended order:

1. **Dry run** (defaults). Check the log shows `problems 0`, and review
   `recert_output/sc_preview_batch1.json`.
2. **One small live ticket:** set `DRY_RUN = False` and keep `STOP_AFTER = "create"`.
   Check the ticket in SecureChange.
3. **Finish it:** set `STOP_AFTER = "close"` and run again. It resumes the same ticket.
4. **Full batches:** set `TEST_RULE_LIMIT = 0` and `BATCHES = [1,2,3,4,5]`. Only rules
   not already in a ticket are submitted.
5. **The rest:** `BATCHES = list(range(6, 124))` or `BATCHES = "all"`. Use
   `STOP_AFTER = "create"` when people will process the tickets (the production rollout),
   or `"close"` to walk each ticket to Closed before the next one starts. The run stops at
   the first failure, and re-running the same range picks up where it stopped.
6. **Reconcile:** run `py reconcile_tickets.py` and hand the **Not ticketed** tab to the
   team.

## Checking what was ticketed (`reconcile_tickets.py`)

Run it after every live run, and any time someone asks "is rule X in a ticket?":

```
py reconcile_tickets.py
```

It is **offline and read-only**, with no Tufin login. It reads `submitted_rules.jsonl`
(the batches), `sc_tickets.jsonl` (the tickets created), the `sc_preview_batch<N>.json`
files (skip reasons) and the mapping workbook (device and rule names). It writes
`recert_output/ticket_reconciliation.xlsx`:

| Tab | Contents |
|---|---|
| **Summary** | Rules by status: Ticketed, Skipped, Not submitted |
| **Batches** | One row per batch and source: rules, ticketed, skipped, ready (dry run), not submitted, ticket IDs |
| **Tickets** | One row per ticket: batch, rule count, stage, created time |
| **Rules** | Every rule: device, rule name, batch, status, ticket, reason |
| **Not ticketed** | Only the rules that need handling by hand: skipped, or batch not run yet. **Give this tab to the team.** |
| **Ready (dry run)** | Rules that resolved in a dry run and will be ticketed on the live run |

What the statuses mean:

| Status | Meaning | Action |
|---|---|---|
| Ticketed | In exactly one ticket | None |
| Skipped | Resolution failed; the reason is in the row (rule renamed or deleted, duplicate rule name on the device, ambiguous same-name device) | Handle by hand, or fix the mapping and re-run the batch |
| Ready (dry run only) | Resolved in a dry run; no ticket yet | Expected after a dry run. The live run tickets them. |
| Not submitted | No ticket, and not in any dry run | That batch hasn't been run at all yet. Run it. |
| IN MORE THAN ONE TICKET | Should never happen | Stop and investigate before the team processes those tickets |

The terminal output lists any batch with rules that were not submitted, or rules that are
in more than one ticket. If a run printed "already ticketed" for a batch you didn't expect,
this report shows which ticket holds those rules.

The workbook contains production rule names. Keep it out of git and share it directly.

## Duplicate protection

Every ticket is recorded in `recert_output/sc_tickets.jsonl` as soon as it is created,
together with the rules in it.

- **Tracked by rule, not by batch.** A rule already in one of our tickets is never
  submitted again. A test ticket and the rest of its batch don't overlap.
- **Unfinished tickets are resumed, never recreated.** If a batch has an open ticket
  from an earlier run, that run finishes it and creates nothing new for that batch.
  Run again for the remainder.
- **With `STOP_AFTER = "create"`,** open tickets are left for the team to process, and the
  rules in the batch that aren't in any ticket yet are created. No rule is ever in two tickets.
- **Dry runs** write nothing to the ledger.

What it does **not** protect against:

- **Deleting or editing `sc_tickets.jsonl`.** Treat it like the other ledger.
- **Two people running it at the same time.**
- **A ticket that was created, but where SecureChange returned no ticket ID.** The
  script stops and says so. Find the ticket in SecureChange and add it to the ledger
  before running again.

## Outputs (`recert_output/`, git-ignored)

| File | Contents |
|---|---|
| `sc_tickets.jsonl` | Ledger: batch, ticket ID, stage (created / decision / closed), rules |
| `sc_preview_batch<N>.json` | The exact payload, the resolved rules, and any rules skipped with the reason |
| `st_rules_cache/<device>.v2.json` | SecureTrack rule index per device (uid, binding, rule order) |
| `unresolved_debug.json` | Rules that still couldn't be resolved, with the raw details (parent chains, match counts) |
| `ticket_reconciliation.xlsx` | Written by `reconcile_tickets.py`: every rule and which ticket it's in, or why not |

## Troubleshooting

| Message | Meaning |
|---|---|
| `... is open in Excel (or OneDrive is syncing it)` | A reporting view or the mapping workbook is open. Close it and run again. |
| `401 Unauthorized` on `/securetrack/api/devices` | Wrong username or password. The production account is `ticketAPI`. |
| `not a participant in the first step` | The account isn't in the workflow's first step. Ask Victor to add it. |
| `FIELD_VALIDATION_ERROR ...` | SecureChange rejected part of the payload. Send the message and the preview file. |
| `device '...' not found in SecureTrack` | The mapping's device name doesn't match SecureTrack exactly. The rule is skipped. |
| `N devices share this name ... resolving per rule` | Same device-group name under more than one Panorama (e.g. BishopRanch 8484 / 6894, Metcalf 6889 / 4650, Fresno Regional Office 9611 / 9543). Each rule goes to the device that has it; if both do, the script compares the rule's parent chain in GraphQL with each device's parent chain in SecureTrack (parent group → Panorama) and uses the closest ancestor that tells them apart. |
| `ambiguous - on N devices named ...` | The rule exists on both same-name devices and no ancestor told them apart. The rule is skipped; details are in `unresolved_debug.json`. |
| `N matches on device` | The rule name appears N times on the device (e.g. pre- and post-rulebase). The script picks by position: the rule's rank among same-name rules in GraphQL policy order, matched to SecureTrack's rule order, **only when both report the same count**. Otherwise skipped; details in `unresolved_debug.json`. Rules resolved this way show `resolved_by: position X of N` in the preview file. |
| `N matches on device` | The rule name is missing, or appears more than once on that device. The rule is skipped. |
| `did not close within 8 steps` | The workflow is waiting on something unexpected. Check the ticket in SecureChange. |

## Open decisions

- Certification expiry period (default 1 year, matching Megan's sample tickets).
- Which role counts as the owner (default: the same priority the Notify script used).
- The description wording.
- Cancelling the 123 drafts once the tickets are confirmed (Requests API `cancel`).

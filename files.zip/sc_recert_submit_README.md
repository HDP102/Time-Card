# sc_recert_submit.py

Creates **RLM Rule Recertification** tickets through the SecureChange REST API and walks
them to **Closed**, recording each rule's owner and decision in the ticket.

It replaces the draft step. `recert_processor.py` creates Drafts through SecureTrack
GraphQL (`createTicketDraft`), and the API cannot submit a draft: the Requests API only
has `search` and `cancel`. This script creates real tickets for the same rules instead.
**Ticket batch N covers the same rules as draft N.** Cancel the drafts once the tickets
are confirmed.

## What it needs

| Input | Where | Used for |
|---|---|---|
| `submitted_rules.jsonl` | `recert_output/` (written by `recert_processor.py`) | The rules in each batch |
| `Rule-ID-Mapping.xlsx` | `SharedData/` | Rule ID → device name + rule name |
| `report_*.xlsx` | `SharedData/` | Rule owner (CorpID from the role columns) |
| Tufin account | Prompted, or `SECURETRACK_USER` / `SECURETRACK_PASSWORD` | SecureTrack + SecureChange REST (basic auth) |

The account must be a participant in the workflow's first step. `ticketAPI` is the
production account; its password is in PAPM.

## How a ticket is built

| Step | What the script does |
|---|---|
| Resolve | For each rule, SecureTrack REST gives the device ID, the rule `uid` `{GUID}` and the binding UID, looked up by device name + rule name. Cached per device for 24h in `recert_output/st_rules_cache/`. |
| 1. Open Recertification Request | `POST /tickets` with the rules grouped as device → binding → rules. |
| 2. Recertification Decision | Adds one `certify` entry per rule: owner CorpID, owner email, description, expiry date. Completes the step. |
| 3. Update Recertification Data | Runs `update_metadata` (writes the result to SecureTrack) and completes the step. The ticket closes. |

**Owner:** the first CorpID found in `OWNER_ROLES` order (Client Owner, IT SME, IT Lead,
IT SME Backup, IT Lead Delegate). Cells look like `Last, First (CORPID)`; `0` means
empty. The email is `CORPID@pge.com`.

## Settings (top of the script)

| Setting | Default | Meaning |
|---|---|---|
| `DRY_RUN` | `True` | Resolve everything and save the payload; change nothing in Tufin |
| `STOP_AFTER` | `"create"` | `create` = make the ticket and stop · `decision` = also complete step 2 · `close` = walk to Closed |
| `BATCHES` | `[1]` | Ledger batch numbers to work on, e.g. `[1,2,3,4,5]` |
| `TEST_RULE_LIMIT` | `5` | Cap on rules per ticket for testing; `0` = the whole batch |
| `EXPIRY_DAYS` | `365` | Certification expiry, from today |
| `DESCRIPTION` | see script | Per-rule justification; `{sheet}` and `{date}` are filled in |
| `OWNER_ROLES` | see above | Which role columns are used for the owner, in priority order |
| `FALLBACK_OWNER` | `""` | CorpID to use when a rule has no owner; blank leaves it empty |

## Running it

From `RecertProcessor/`:

```
py sc_recert_submit.py
```

Recommended order:

1. **Dry run** (defaults). Check the log shows `problems 0`, and review
   `recert_output/sc_preview_batch1.json`.
2. **One small live ticket:** set `DRY_RUN = False` and keep `STOP_AFTER = "create"`.
   Check the ticket in SecureChange.
3. **Finish it:** set `STOP_AFTER = "close"` and run again. It resumes the same ticket.
4. **Full batches:** set `TEST_RULE_LIMIT = 0` and `BATCHES = [1,2,3,4,5]`. Only rules
   not already in a ticket are submitted.

## Duplicate protection

Every ticket is recorded in `recert_output/sc_tickets.jsonl` as soon as it is created,
together with the rules in it.

- **Tracked by rule, not by batch.** A rule already in one of our tickets is never
  submitted again. A test ticket and the rest of its batch don't overlap.
- **Unfinished tickets are resumed, never recreated.** If a batch has an open ticket
  from an earlier run, that run finishes it and creates nothing new for that batch.
  Run again for the remainder.
- **With `STOP_AFTER = "create"`,** a batch that already has an open ticket is left
  alone.
- **Dry runs** write nothing to the ledger.

What it does **not** protect against:

- **Deleting or editing `sc_tickets.jsonl`.** Treat it like the other ledger.
- **Two people running it at the same time.**
- **A ticket that was created, but where SecureChange returned no ticket ID.** The
  script stops and says so. Find the ticket in SecureChange and add it to the ledger
  before running again.

## Outputs (`recert_output/`, git-ignored)

| File | Contents |
|---|---|
| `sc_tickets.jsonl` | Ledger: batch, ticket ID, stage (created / decision / closed), rules |
| `sc_preview_batch<N>.json` | The exact payload, the resolved rules, and any rules skipped with the reason |
| `st_rules_cache/<device>.json` | SecureTrack rule index per device (uid + binding) |

## Troubleshooting

| Message | Meaning |
|---|---|
| `not a participant in the first step` | The account isn't in the workflow's first step. Ask Victor to add it. |
| `FIELD_VALIDATION_ERROR ...` | SecureChange rejected part of the payload. Send the message and the preview file. |
| `device '...' not found in SecureTrack` | The mapping's device name doesn't match SecureTrack exactly. The rule is skipped. |
| `N matches on device` | The rule name is missing, or appears more than once on that device. The rule is skipped. |
| `did not close within 8 steps` | The workflow is waiting on something unexpected. Check the ticket in SecureChange. |

## Open decisions

- Certification expiry period (default 1 year, matching Megan's sample tickets).
- Which role counts as the owner (default: the same priority the Notify script used).
- The description wording.
- Cancelling the 123 drafts once the tickets are confirmed (Requests API `cancel`).

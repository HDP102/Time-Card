"""
tag_app_ids.py
==============
Workstream 2, Task 1 — Tag App-IDs into the Tufin rule Description field
PG&E | NPS Automation

STATUS: working end to end against live Tufin (lab). Read query, write mutation,
auth, and the UID join are all confirmed.
  - Read      rules(filter){ values { id idOnDevice ruleUserData{ruleDescription} } }
  - Write     ruleUserData.updateRuleDescription(input:{description, ids})
              -> resultStatus{ successful errors }
  - Auth      Keycloak password grant. NOTE the API role sits on the ADMIN account;
              a standard CorpID authenticates but gets 403 from the GraphQL API.
  - Paging    values(offset:) is type Long, not Int. Int fails validation.

HOW RULES ARE ADDRESSED
  The reporting views carry decisions and App-IDs but no rule UID. The Rule-ID-Mapping
  workbook maps Device Name + ID on Device -> SecureTrack Rule ID for the whole estate,
  so a sheet row resolves to exactly one rule.

  This replaced an earlier join on rule name alone. Rule names repeat across devices:
  on 2026-09-15 a single sheet row matched 100 rules on different boxes, which would
  have written app ids onto rules nobody asked about. There is no name-only fallback.

  Reporting-view headers are NOT consistent across the eleven lists. The device column
  appears as Device Name, Device Group, Device group or Title, and the app column as
  App-ID or Application ID, so both are configured as alias lists.

WHAT THIS DOES
  1. Read every reporting view matching EXCEL_PATH (a glob processes all eleven in one
     run; the Tufin fetch and mapping load are identical each time, so repeating them
     per sheet is wasted work). Rows without an App-ID are skipped.
  2. Resolve each row to a rule UID through the mapping workbook. Rows that do not
     resolve are reported, per sheet, with the device names that failed — never
     dropped silently.
  3. Fetch rules from Tufin (paginated): UID, idOnDevice, current description.
  4. Match on UID, build the new description, and write it back per rule.
  5. Batch, dry-run by default, and write tag_plan.xlsx so every intended change is
     reviewable before anything is written.

WHAT IT DELIBERATELY WILL NOT DO
  Rules whose description already contains ##RLM## are SKIPPED, not appended to.
  Another team writes app ids into that field in a different format (##RLM## header,
  FER<number>: APP-<id>, Owner:AMPS ...). Appending an app_id line would state the same
  app id twice in two competing conventions. Until that format is agreed, those rules
  are listed in the plan with the reason and left alone. Do not "fix" this by guessing
  at the RLM layout.
"""

import csv
import getpass
import logging
import requests
from dataclasses import dataclass, field
from pathlib import Path

# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────

DRY_RUN              = True          # True = log intended writes + plan CSV, change nothing

# The rule spreadsheet to read App-IDs from (the full sheet, not the report_ view).
# One file, a list, or a glob. A glob processes every reporting view in one run
# rather than refetching ~78k Tufin rules once per sheet.
EXCEL_PATH           = "report_*.xlsx"

# Column headers in the spreadsheet (confirmed from the ODN/GDN sheets).
# JOIN COLUMN. Prefer the UID: it is exact, unique, and immune to duplicate rule
# names across devices. Matching on name caused one spreadsheet row to fan out to
# 100 Tufin rules on 2026-09-15, because rule names repeat on different devices.
# Column headers are NOT consistent across the eleven reporting views. Observed
# 2026-09-16: Device Name / Device Group / Device group / Title all mean the device,
# and the app id is App-ID on most sheets but Application ID on ODN_MPLS Part 1.
DEVICE_COLUMN        = ["Device Name", "Device Group", "Device group", "Title"]
RULE_NAME_COLUMN     = ["Rule Name"]
APPID_COLUMN         = ["App-ID", "Application ID", "AppID", "App ID"]
UID_COLUMN           = ["SecureTrack Rule ID"]

# Which tab of the input workbook to read. Reporting views have one sheet; a
# decisions workbook may have several (Cleanup / Recertified / Recertified-DR).
INPUT_SHEET          = None          # None = first tab

# If the sheet has no UID column the script STOPS rather than falling back to the
# name join. The fallback is what produced the wrong-device writes; making it
# unavailable is the point.
# A sheet row is only ever written to the ONE rule it names, resolved through the
# mapping workbook. There is no name-only fallback: that is what wrote to 100 rules
# across different devices on 2026-09-15.
REQUIRE_UID = True

# SecureTrack GraphQL endpoint (lab first; prod only once proven).
SECURETRACK_GRAPHQL  = "https://keeppgelabsecure.utility.pge.com/v2/api/sync/graphql"
GRAPHQL_PAGE_SIZE   = 500        # ~78k rules; 100 means 780 round trips
GRAPHQL_MAX_PAGES    = 2000          # safety cap; count tells the real total
VERIFY_TLS           = False        # lab cert; set True in prod if the CA is trusted

# Only pull the rules you're tagging. The filter syntax matches the Rule Viewer.
# Every Palo Alto rule. The spreadsheet decides what gets acted on, so the filter
# only needs to be wide enough to contain the rules the sheet names. Narrowing it by
# device or severity is what made earlier runs match almost nothing.
#
# Once the match rate looks right, adding "and securechangeTicketInProgressId not
# exists" back is reasonable — it skips rules that already have a ticket open.
RULE_FILTER = "vendor='PALO_ALTO'"

# Keycloak auth. Credentials are prompted at runtime (getpass) — leave these BLANK so
# nothing sensitive is ever committed. If you must pre-set them for an automated run, do
# it via environment variables, NOT by typing them here (this file goes to the repo).
KEYCLOAK_TOKEN_URL   = "https://keeppgelabsecure.utility.pge.com/auth/realms/tufin-realm/protocol/openid-connect/token"
KEYCLOAK_CLIENT_ID   = "admin-cli"
KEYCLOAK_USERNAME    = ""            # blank -> prompted at runtime (or set env SECURETRACK_USER)
KEYCLOAK_PASSWORD    = ""            # blank -> prompted at runtime (never hardcode / commit)

# The line written into the Description, kept labelled so it's easy to find and parse back.
DESC_APPID_PREFIX    = "app_id:"

# Rules already carrying a description in the other team's format:
#     ##RLM##
#     FER119358: APP-1596
#     Owner:AMPS APP-1596
# Appending an "app_id:" line to those states the app id twice in two competing
# formats. Until the RLM format is documented and agreed, such rules are SKIPPED
# and listed in the plan CSV rather than written to. Do not "fix" this by
# guessing at the RLM layout.
RLM_MARKER           = "##RLM##"
SKIP_RLM_DESCRIPTIONS = True
# Combine with any existing Description text: "append" keeps it, "replace" overwrites.
DESC_WRITE_MODE      = "append"

WRITE_BATCH_SIZE     = 100           # rules per updateRuleDescription call (ids is an array)
OUTPUT_DIR           = "tag_output"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("tag_app_ids")


# ─────────────────────────────────────────────
# Data model
# ─────────────────────────────────────────────

@dataclass
class Rule:
    uid: str
    id_on_device: str = ""
    description: str = ""
    app_ids: list = field(default_factory=list)


@dataclass
class PlannedWrite:
    uid: str
    rule_name: str
    old_description: str
    new_description: str
    app_ids: list
    reason: str = ""
    skip: bool = False


# ─────────────────────────────────────────────
# Auth  (the one remaining fill-in)
# ─────────────────────────────────────────────

_TOKEN_CACHE = {"token": None, "username": None, "password": None}

def get_access_token() -> str:
    """
    Get a bearer token for the GraphQL endpoint via Keycloak.

    Credentials are resolved in this order, so nothing sensitive lives in the file:
      1. the KEYCLOAK_USERNAME / KEYCLOAK_PASSWORD config values (leave blank),
      2. environment variables SECURETRACK_USER / SECURETRACK_PASSWORD,
      3. an interactive prompt (getpass — hidden, and never written to disk).

    Credentials are cached in memory for the life of the process so a mid-run token
    refresh is silent. Without that, a long production fetch would stop and re-prompt
    partway through, which is worse than the expiry it is surviving.

    Confirmed working 2026-09-15. Note the API role sits on the admin account, not the
    standard CorpID - a non-admin login authenticates but gets 403 from the GraphQL API.
    """
    import os
    if _TOKEN_CACHE["token"]:
        return _TOKEN_CACHE["token"]

    username = _TOKEN_CACHE.get("username") or KEYCLOAK_USERNAME \
        or os.environ.get("SECURETRACK_USER", "")
    password = _TOKEN_CACHE.get("password") or KEYCLOAK_PASSWORD \
        or os.environ.get("SECURETRACK_PASSWORD", "")

    if not username:
        username = input("SecureTrack username (CorpID): ").strip()
    if not password:
        password = getpass.getpass("SecureTrack password: ")   # hidden, not stored
    _TOKEN_CACHE["username"] = username
    _TOKEN_CACHE["password"] = password

    resp = requests.post(
        KEYCLOAK_TOKEN_URL,
        data={"grant_type": "password", "client_id": KEYCLOAK_CLIENT_ID,
              "username": username, "password": password},
        verify=VERIFY_TLS, timeout=30,
    )
    resp.raise_for_status()
    token = resp.json()["access_token"]
    _TOKEN_CACHE["token"] = token
    return token


# ─────────────────────────────────────────────
# GraphQL calls  (read + write — confirmed shapes)
# ─────────────────────────────────────────────

def _graphql(query: str, variables: dict, _retry: bool = True) -> dict:
    """
    Post one GraphQL request, refreshing the token once if it has expired.

    The token is cached for the life of the run, and a full production fetch takes
    long enough to outlive it: on 2026-09-18 a run died with 401 after 67,000 of
    69,471 rules, roughly ten minutes in. Losing a fetch that far along because a
    token aged out is not a real failure, so a 401 clears the cache, gets a fresh
    token and retries the same request once.

    Only 401 is retried. A 403 is a permissions problem and retrying it would just
    hide the cause behind a second identical error.
    """
    token = get_access_token()
    resp = requests.post(
        SECURETRACK_GRAPHQL,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        json={"query": query, "variables": variables},
        verify=VERIFY_TLS, timeout=60,
    )

    if resp.status_code == 401 and _retry:
        log.info("Token expired mid-run — refreshing and retrying")
        _TOKEN_CACHE["token"] = None
        return _graphql(query, variables, _retry=False)

    resp.raise_for_status()
    data = resp.json()
    if data.get("errors"):
        raise RuntimeError(f"GraphQL errors: {data['errors']}")
    return data


# Confirmed read query — `id` is the UID used for writes; idOnDevice is the join key.
_RULE_QUERY = """
query Rules($filter: String!, $first: Int!, $offset: Long!) {
  rules(filter: $filter) {
    count
    values(first: $first, offset: $offset) {
      id
      idOnDevice
      ruleUserData { ruleDescription }
    }
  }
}
"""

# Confirmed write mutation — ids is an ARRAY, so multiple rules per call works.
_UPDATE_DESC_MUTATION = """
mutation UpdateDescription($description: FreeText!, $ids: [IdString!]!) {
  ruleUserData {
    updateRuleDescription(input: {description: $description, ids: $ids}) {
      ids
      resultStatus { successful errors { errorCode errorMessage } }
    }
  }
}
"""


def fetch_rules(rule_filter: str) -> list:
    """Pull rules (paginated) with their UID, idOnDevice, and current description."""
    rules, offset, total = [], 0, None
    for _ in range(GRAPHQL_MAX_PAGES):
        data = _graphql(_RULE_QUERY,
                        {"filter": rule_filter, "first": GRAPHQL_PAGE_SIZE, "offset": offset})
        block = data["data"]["rules"]
        total = block.get("count", total)
        batch = block.get("values", [])
        if not batch:
            break
        for item in batch:
            rud = item.get("ruleUserData") or {}
            rules.append(Rule(
                uid=str(item.get("id", "")),
                id_on_device=item.get("idOnDevice") or "",
                description=(rud.get("ruleDescription") or ""),
            ))
        offset += GRAPHQL_PAGE_SIZE
        log.info(f"Fetched {len(rules)}" + (f" of {total}" if total is not None else "") + " rules")
        if total is not None and offset >= total:
            break
    return rules


def write_descriptions(uids: list, description: str) -> dict:
    """Write one description to a batch of rule UIDs. Returns the resultStatus dict."""
    data = _graphql(_UPDATE_DESC_MUTATION, {"description": description, "ids": uids})
    return data["data"]["ruleUserData"]["updateRuleDescription"]["resultStatus"]



def resolve_inputs(spec):
    """
    Accept one filename, a list of them, or a glob like "report_*.xlsx".
    Returns a sorted list of existing Paths.

    One run over every sheet beats eleven runs: the Tufin fetch is ~78k rules and
    the mapping workbook ~69k rows, and both are identical each time.
    """
    from pathlib import Path
    import glob as _glob

    patterns = [spec] if isinstance(spec, str) else list(spec)
    found, seen = [], set()
    for pat in patterns:
        hits = [Path(p) for p in _glob.glob(pat)] if any(c in pat for c in "*?[") \
               else ([Path(pat)] if Path(pat).exists() else [])
        if not hits:
            log.warning(f"No file matched {pat!r}")
        for h in sorted(hits):
            if h.resolve() not in seen and h.suffix.lower() in (".xlsx", ".xlsm"):
                seen.add(h.resolve())
                found.append(h)

    # never treat the mapping workbook as an input sheet
    found = [p for p in found if p.name.lower() != str(MAPPING_PATH).lower()]
    return found



def find_column(header, candidates):
    """
    Locate a column by any of its known aliases. Returns (index, name_used) or
    (None, None). Exact match first, then a prefix match for Excel-truncated headers.
    """
    names = [candidates] if isinstance(candidates, str) else list(candidates)
    low = [h.strip().lower() for h in header]
    for want in names:
        w = want.strip().lower()
        for i, h in enumerate(low):
            if h == w:
                return i, header[i]
    for want in names:
        w = want.strip().lower()
        for i, h in enumerate(low):
            if h.startswith(w[:12]) or w.startswith(h[:12]):
                return i, header[i]
    return None, None


# ─────────────────────────────────────────────
# Rule-ID mapping workbook  ->  UID lookup
# ─────────────────────────────────────────────
#
# The reporting views carry decisions and App-IDs but no rule UID. The
# Rule-ID-Mapping workbook carries Device Name + ID on Device -> SecureTrack Rule ID
# for the whole estate. Joining through it keeps the reporting views as the input
# (which is the point) while still addressing rules by UID (which is exact).
#
# The key is built from the Device Name and ID on Device COLUMNS, not by parsing the
# pre-joined "DeviceName+RuleName" column. Rule names contain hyphens of their own
# ("Citrix to GE Relays-svc"), so splitting that column on "-" is not safe.

MAPPING_PATH        = "Rule-ID-Mapping.xlsx"
MAPPING_SHEET       = "Rule-ID-Mapping"   # tab name; also matched case-insensitively
MAP_DEVICE_COLUMN   = "Device Name"
MAP_RULE_COLUMN     = "ID on Device"      # same value as the reporting view's Rule Name
MAP_UID_COLUMN      = "SecureTrack Rule ID"


def _norm(value) -> str:
    """Trim, collapse inner whitespace, uppercase. Device names drift on spacing."""
    if value is None:
        return ""
    return " ".join(str(value).split()).upper()


def _key(device, rule) -> str:
    return f"{_norm(device)}||{_norm(rule)}"


def load_uid_map(path=None, sheet=None):
    """
    Returns (uid_by_key, devices) where uid_by_key is { 'DEVICE||RULE': uid } and
    devices is the set of device names seen — useful for diagnosing a join that
    matches nothing because the two files name devices differently.
    """
    from openpyxl import load_workbook
    from pathlib import Path

    p = Path(path or MAPPING_PATH)
    want = sheet or MAPPING_SHEET
    if not p.exists():
        log.error(f"Rule-ID mapping workbook not found: {p}")
        return {}, set()

    try:
        wb = load_workbook(p, read_only=True, data_only=True)
    except PermissionError:
        log.error(f"{p.name} is locked. Close it in Excel and run again.")
        return {}, set()

    names = wb.sheetnames
    target = next((n for n in names if n.strip().lower() == want.strip().lower()), None)
    if target is None:
        log.error(f"No '{want}' tab in {p.name}. Tabs present: {names}")
        wb.close()
        return {}, set()

    ws = wb[target]
    rows = ws.iter_rows(values_only=True)
    try:
        header = [str(h).strip() if h is not None else "" for h in next(rows)]
    except StopIteration:
        wb.close()
        return {}, set()

    def find(label):
        t = label.lower()
        for i, h in enumerate(header):
            if h.lower() == t:
                return i
        for i, h in enumerate(header):
            if h.lower().startswith(t[:14]):
                return i
        return None

    d_i, r_i, u_i = find(MAP_DEVICE_COLUMN), find(MAP_RULE_COLUMN), find(MAP_UID_COLUMN)
    if None in (d_i, r_i, u_i):
        log.error(f"'{target}' needs '{MAP_DEVICE_COLUMN}', '{MAP_RULE_COLUMN}' and "
                  f"'{MAP_UID_COLUMN}'. Found: {header}")
        wb.close()
        return {}, set()

    uid_by_key, devices, dupes, blanks = {}, set(), 0, 0
    for row in rows:
        if not any(row):
            continue
        dev = row[d_i] if d_i < len(row) else None
        rul = row[r_i] if r_i < len(row) else None
        uid = row[u_i] if u_i < len(row) else None
        if not dev or not rul or not uid:
            blanks += 1
            continue
        k = _key(dev, rul)
        if k in uid_by_key and uid_by_key[k] != str(uid).strip():
            dupes += 1          # same device+rule twice with different UIDs
            continue
        uid_by_key[k] = str(uid).strip()
        devices.add(_norm(dev))

    wb.close()
    log.info(f"Loaded {len(uid_by_key):,} UID mapping(s) from {p.name} [{target}], "
             f"{len(devices)} device(s)")
    if blanks:
        log.info(f"  {blanks:,} mapping row(s) skipped — incomplete")
    if dupes:
        log.warning(f"  {dupes:,} device+rule pair(s) appeared twice with different UIDs "
                    f"and were skipped — those rules cannot be addressed unambiguously")
    return uid_by_key, devices


def resolve_uids(records, uid_by_key, map_devices, label="row"):
    """
    records: list of dicts with 'device' and 'rule' keys. Sets 'uid' on each.
    Returns (resolved, unresolved). Unresolved rows are REPORTED, never silently
    dropped — a silent drop is how a run can look successful having done nothing.
    """
    resolved, unresolved = [], []
    for rec in records:
        uid = uid_by_key.get(_key(rec.get("device"), rec.get("rule")))
        if uid:
            rec["uid"] = uid
            resolved.append(rec)
        else:
            unresolved.append(rec)

    log.info(f"Resolved {len(resolved):,} of {len(records):,} {label}(s) to a rule UID")

    by_file = {}
    for r in records:
        f = r.get("source_file", "(unknown)")
        ok, tot = by_file.get(f, (0, 0))
        by_file[f] = (ok + (1 if r.get("uid") else 0), tot + 1)
    if len(by_file) > 1:
        log.info("  per sheet:")
        for f, (ok, tot) in sorted(by_file.items()):
            rate = 100.0 * ok / tot if tot else 0
            flag = "   <-- CHECK: device values may not match the mapping" if rate < 50 else ""
            log.info(f"    {f:<48} {ok:>6,}/{tot:<6,} {rate:5.1f}%{flag}")
    if unresolved:
        log.warning(f"{len(unresolved):,} {label}(s) did not resolve and will be skipped")
        sheet_devices = {_norm(r.get("device")) for r in unresolved if r.get("device")}
        never = sorted(d for d in sheet_devices if d not in map_devices)
        if never:
            log.warning(f"  {len(never)} device name(s) appear in the sheet but NOT in the "
                        f"mapping at all — likely a naming mismatch between the two files:")
            for d in never[:5]:
                log.warning(f"    {d}")
        else:
            log.warning("  all device names matched, so these are rule-name differences "
                        "(renamed, deleted, or not in the mapping's scope)")
        for r in unresolved[:3]:
            log.warning(f"  e.g. {r.get('device')} / {r.get('rule')}")
    return resolved, unresolved


# ─────────────────────────────────────────────
# Spreadsheet: Rule Name -> App-ID   (real)
# ─────────────────────────────────────────────

def _clean_appid(value) -> str:
    if value is None:
        return ""
    s = str(value).strip().upper()
    if not s or s in ("NONE", "NO APPID", "NAN"):
        return ""
    if s.startswith("APP-"):
        return s
    if s.replace("-", "").isdigit():
        return f"APP-{s}"
    return s


def load_sheet(excel_path):
    """
    Read a reporting view: Device Name + Rule Name + App-ID.
    Returns a list of {device, rule, app_ids} — UIDs are resolved separately.
    """
    from openpyxl import load_workbook
    path = Path(excel_path)
    if not path.exists():
        log.error(f"Spreadsheet not found: {excel_path}")
        return []

    try:
        wb = load_workbook(path, read_only=True, data_only=True)
    except PermissionError:
        log.error(f"{path.name} is locked. Close it in Excel and run again.")
        return []

    if INPUT_SHEET:
        tab = next((n for n in wb.sheetnames
                    if n.strip().lower() == INPUT_SHEET.strip().lower()), None)
        if tab is None:
            log.error(f"No '{INPUT_SHEET}' tab in {path.name}. Tabs: {wb.sheetnames}")
            wb.close()
            return []
    else:
        tab = wb.sheetnames[0]

    ws = wb[tab]
    rows = ws.iter_rows(values_only=True)
    try:
        header = [str(h).strip() if h is not None else "" for h in next(rows)]
    except StopIteration:
        wb.close()
        return []

    dev_i,  dev_name = find_column(header, DEVICE_COLUMN)
    rule_i, _        = find_column(header, RULE_NAME_COLUMN)
    app_i,  app_name = find_column(header, APPID_COLUMN)
    uid_i,  _        = find_column(header, UID_COLUMN)

    missing = [n for n, i in (("device", dev_i), ("rule name", rule_i),
                              ("app id", app_i)) if i is None]
    if missing:
        log.error(f"{path.name} [{tab}] has no {missing} column.")
        log.error(f"  tried: device={DEVICE_COLUMN} app={APPID_COLUMN}")
        log.error(f"  found: {header[:10]}")
        wb.close()
        return []

    if dev_name != DEVICE_COLUMN[0] or app_name != APPID_COLUMN[0]:
        log.info(f"  {path.name}: device='{dev_name}' app='{app_name}'")

    out, no_app = [], 0
    for row in rows:
        if not any(row):
            continue
        app = _clean_appid(row[app_i] if app_i < len(row) else None)
        if not app:
            no_app += 1
            continue
        dev  = row[dev_i] if dev_i < len(row) else None
        rule = row[rule_i] if rule_i < len(row) else None
        if not dev or not rule:
            continue
        rec = {"device": str(dev).strip(), "rule": str(rule).strip(), "app_ids": [app]}
        if uid_i is not None and uid_i < len(row) and row[uid_i]:
            rec["uid"] = str(row[uid_i]).strip()   # sheet already had one
        out.append(rec)

    wb.close()
    log.info(f"Read {len(out):,} row(s) with an App-ID from {path.name} [{tab}]")
    if no_app:
        log.info(f"  {no_app:,} row(s) skipped — no App-ID")
    return out


# ─────────────────────────────────────────────
# Build the new Description  (real, pure logic)
# ─────────────────────────────────────────────

def _existing_app_ids(description: str) -> list:
    out = []
    for line in description.splitlines():
        line = line.strip()
        if line.lower().startswith(DESC_APPID_PREFIX):
            val = line[len(DESC_APPID_PREFIX):].strip()
            out.extend(_clean_appid(v) for v in val.split(",") if _clean_appid(v))
    return out


def build_new_description(rule: Rule) -> PlannedWrite:
    app_ids = rule.app_ids
    if not app_ids:
        return PlannedWrite(rule.uid, rule.id_on_device, rule.description, rule.description,
                            [], reason="no app id for this rule", skip=True)

    # Another team already writes app ids into this field in a different format:
    #   ##RLM##
    #   FER119358: APP-1596
    #   Owner:AMPS APP-1596
    # Appending our app_id: line would state the same app id twice in two formats.
    # Skip and surface it instead of guessing at a layout nobody has documented.
    if SKIP_RLM_DESCRIPTIONS and RLM_MARKER in (rule.description or ""):
        return PlannedWrite(rule.uid, rule.id_on_device, rule.description, rule.description,
                            app_ids,
                            reason=f"already has a {RLM_MARKER} description - format not agreed",
                            skip=True)

    already = _existing_app_ids(rule.description)
    to_add = [a for a in app_ids if a not in already]

    if DESC_WRITE_MODE == "replace":
        new_desc = f"{DESC_APPID_PREFIX} {', '.join(app_ids)}"
        if new_desc.strip() == rule.description.strip():
            return PlannedWrite(rule.uid, rule.id_on_device, rule.description, rule.description,
                                app_ids, reason="already correct", skip=True)
        return PlannedWrite(rule.uid, rule.id_on_device, rule.description, new_desc,
                            app_ids, reason="replace description with app id line")

    if not to_add:
        return PlannedWrite(rule.uid, rule.id_on_device, rule.description, rule.description,
                            app_ids, reason="app id already present", skip=True)

    app_line = f"{DESC_APPID_PREFIX} {', '.join(already + to_add)}"
    if already:
        kept = [ln for ln in rule.description.splitlines()
                if not ln.strip().lower().startswith(DESC_APPID_PREFIX)]
        new_desc = "\n".join(kept + [app_line]).strip()
    elif rule.description.strip():
        new_desc = f"{rule.description.rstrip()}\n{app_line}"
    else:
        new_desc = app_line

    return PlannedWrite(rule.uid, rule.id_on_device, rule.description, new_desc,
                        app_ids, reason=f"add {', '.join(to_add)}")


# ─────────────────────────────────────────────
# Execute  (batching real; write is confirmed)
# ─────────────────────────────────────────────

def chunked(items, size):
    for i in range(0, len(items), size):
        yield items[i:i + size]


def execute_writes(planned: list) -> None:
    writes = [p for p in planned if not p.skip]
    skips = [p for p in planned if p.skip]
    log.info(f"{len(writes)} rule(s) to write, {len(skips)} skipped")
    if not writes:
        return

    # Group rules that get the SAME description text into one call (ids is an array),
    # capped at WRITE_BATCH_SIZE. Correct whether descriptions are shared or all unique.
    by_desc = {}
    for p in writes:
        by_desc.setdefault(p.new_description, []).append(p)

    done = 0
    for desc, group in by_desc.items():
        for batch in chunked(group, WRITE_BATCH_SIZE):
            uids = [p.uid for p in batch]
            if DRY_RUN:
                log.info(f"  [DRY RUN] would set {len(uids)} rule(s) -> "
                         f"'{desc[:60]}' (e.g. {batch[0].rule_name})")
                done += len(uids)
                continue
            status = write_descriptions(uids, desc)
            if status.get("successful"):
                done += len(uids)
                log.info(f"  wrote {len(uids)} rule(s) | {done}/{len(writes)}")
            else:
                log.error(f"  write failed for {len(uids)} rule(s): {status.get('errors')}")


def write_table(name, header, rows):
    """
    Write one review file as .xlsx with a filterable, frozen header row and column
    widths sized to the content. These files exist to be read in Excel, so they get
    a filter rather than leaving you to add one on every run.
    """
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter

    path = Path(OUTPUT_DIR) / (name[:-4] + ".xlsx" if name.endswith(".csv") else name + ".xlsx")
    wb = Workbook()
    ws = wb.active
    ws.title = (name[:-4] if name.endswith(".csv") else name)[:31]

    ws.append(list(header))
    for c in range(1, len(header) + 1):
        cell = ws.cell(row=1, column=c)
        cell.fill = PatternFill("solid", fgColor="1F3864")
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(vertical="center")

    for row in rows:
        ws.append(["" if v is None else v for v in row])

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(header))}{max(len(rows) + 1, 1)}"

    # width from the widest value in each column, capped so a long description
    # does not push everything else off screen
    for i, name_ in enumerate(header, start=1):
        widest = len(str(name_))
        for row in rows[:400]:
            if i - 1 < len(row) and row[i - 1] is not None:
                first_line = str(row[i - 1]).split("\n")[0]
                widest = max(widest, len(first_line))
        ws.column_dimensions[get_column_letter(i)].width = min(max(widest + 3, 10), 60)

    wb.save(path)
    return path



def write_plan_csv(planned: list, path: str) -> None:
    Path(OUTPUT_DIR).mkdir(exist_ok=True)
    out = write_table(path,
        ["rule_uid", "rule_name (idOnDevice)", "app_ids", "action", "skip",
         "old_description", "new_description"],
        [[p.uid, p.rule_name, "; ".join(p.app_ids), p.reason, p.skip,
          p.old_description, p.new_description] for p in planned])
    log.info(f"Wrote plan: {out}")


# ─────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────

def main():
    log.info("tag_app_ids — App-IDs into Tufin rule descriptions")
    log.info(f"DESC_WRITE_MODE={DESC_WRITE_MODE} | DRY_RUN={DRY_RUN}")
    if DRY_RUN:
        log.info("DRY RUN — no descriptions will be changed (plan CSV only)")

    out_dir = Path(OUTPUT_DIR)
    if out_dir.exists():
        for old in out_dir.glob("*.csv"):
            old.unlink()

    # 1. every reporting view -> device + rule + app ids
    inputs = resolve_inputs(EXCEL_PATH)
    if not inputs:
        log.error(f"No spreadsheet matched {EXCEL_PATH!r} — nothing to tag.")
        return
    log.info(f"{len(inputs)} spreadsheet(s) to read: "
             + ", ".join(p.name for p in inputs))

    sheet_rows, merged = [], {}
    for path in inputs:
        for rec in load_sheet(path):
            rec["source_file"] = path.name
            key = (rec["device"].strip().upper(), rec["rule"].strip().upper())
            prior = merged.get(key)
            if prior is None:
                merged[key] = rec
                sheet_rows.append(rec)
            else:
                # same rule in two sheets — union the app ids rather than dropping one
                for a in rec["app_ids"]:
                    if a not in prior["app_ids"]:
                        prior["app_ids"].append(a)
                if path.name not in prior["source_file"]:
                    prior["source_file"] += f"; {path.name}"

    log.info(f"Merged {len(sheet_rows):,} rule(s) with an App-ID across "
             f"{len(inputs)} sheet(s)")
    if not sheet_rows:
        log.error("Nothing usable in the spreadsheets — nothing to tag.")
        return

    # 2. resolve each row to a rule UID via the mapping workbook
    need_lookup = [r for r in sheet_rows if not r.get("uid")]
    if need_lookup:
        uid_by_key, map_devices = load_uid_map()
        if not uid_by_key:
            log.error("No UID mapping loaded. Without it a sheet row cannot be tied to "
                      "one specific rule, and tagging by name alone writes to every "
                      "device sharing that rule name. Stopping.")
            return
        resolved, unresolved = resolve_uids(need_lookup, uid_by_key, map_devices, "sheet row")
    else:
        log.info("Sheet already carries UIDs — no mapping lookup needed")
        resolved = sheet_rows

    have_uid = [r for r in sheet_rows if r.get("uid")]
    if not have_uid:
        log.error("No sheet row resolved to a rule UID — nothing to tag.")
        return

    by_uid = {}
    for r in have_uid:
        by_uid.setdefault(r["uid"], [])
        for a in r["app_ids"]:
            if a not in by_uid[r["uid"]]:
                by_uid[r["uid"]].append(a)

    # 3. Tufin: UID + idOnDevice + current description
    rules = fetch_rules(RULE_FILTER)
    log.info(f"Fetched {len(rules):,} rule(s) from Tufin")

    matched = 0
    for r in rules:
        r.app_ids = by_uid.get(r.uid, [])
        if r.app_ids:
            matched += 1
    log.info(f"Matched {matched:,} rule(s) on SecureTrack Rule ID (exact)")

    not_fetched = set(by_uid) - {r.uid for r in rules}
    if not_fetched:
        log.warning(f"{len(not_fetched):,} resolved UID(s) were not in the fetched set — "
                    f"widen RULE_FILTER to include them.")

    # 4. plan + write
    planned = [build_new_description(r) for r in rules]
    writes = sum(1 for p in planned if not p.skip)
    skips = sum(1 for p in planned if p.skip)
    rlm = sum(1 for p in planned if RLM_MARKER in (p.old_description or ""))
    log.info(f"Planned: {writes} write(s), {skips} skip(s)")
    if rlm:
        log.warning(f"{rlm} rule(s) already carry a {RLM_MARKER} description and were "
                    f"skipped. Agree that format before tagging them.")

    execute_writes(planned)
    write_plan_csv(planned, "tag_plan.csv")
    log.info("Done" + (" (dry run)" if DRY_RUN else ""))


if __name__ == "__main__":
    main()

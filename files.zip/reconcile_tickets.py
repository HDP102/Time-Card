"""
reconcile_tickets.py - offline, read-only. Shows what happened to every recertify rule:
which ticket it is in, or why it is not in one. For handing to the team.

Reads (all in recert_output/, no Tufin login):
    submitted_rules.jsonl      every recertify batch (= draft) and its rules
    *Rule_report*.xlsx         the Tufin rule reports (SOURCE="reports"), batches 1001+
    sweep tickets (SOURCE="sweep", 2001+) show against each rule's original batch
    sc_tickets.jsonl           every ticket sc_recert_submit.py created, and its rules
    sc_preview_batch<N>.json   why rules were skipped in the last run of each batch
plus the Rule-ID mapping workbook for device + rule names.

Writes recert_output/ticket_reconciliation.xlsx:
    Summary   totals by status
    Batches   one row per batch: rules, ticketed, skipped, not submitted, ticket ids
    Tickets   one row per ticket: batch, rules, stage, created
    Rules     one row per rule: device, rule, batch, status, ticket, reason
    Not ticketed   rules the team needs to handle by hand (skipped, or batch not run yet)
    Ready (dry run)  rules that resolved in a dry run and will be ticketed on the live run

Run from RecertProcessor/:   py reconcile_tickets.py
"""
import json
import re
from collections import Counter, defaultdict

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

import sc_recert_submit as s

OUT_FILE = s.OUT / "ticket_reconciliation.xlsx"
HEAD = Font(bold=True, color="FFFFFF")
FILL = PatternFill("solid", fgColor="1F4E78")


def sheet(wb, title, header, rows, widths):
    ws = wb.create_sheet(title)
    ws.append(header)
    for c in ws[1]:
        c.font, c.fill = HEAD, FILL
    for row in rows:
        ws.append(row)
    for i, w in enumerate(widths):
        ws.column_dimensions[chr(65 + i)].width = w
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    return ws


def main():
    batches = [(n, "ledger", uids) for n, uids in enumerate(s.ledger_batches(), 1)]
    mapping = s.mapping_by_uid()
    if list(s.r.DATA_DIR.glob(s.RULE_REPORT_GLOB)):
        print("Reading rule reports...")
        rb, rmap, _ = s.report_batches()
        batches += [(s.REPORT_BATCH_BASE + i, "reports", u) for i, u in enumerate(rb, 1)]
        for k, v in rmap.items():
            mapping.setdefault(k, v)

    # Tickets from our ledger. A rule in more than one ticket would be a bug - flagged.
    tickets, rule_tickets = {}, defaultdict(list)
    if s.SC_LEDGER.exists():
        for line in open(s.SC_LEDGER, encoding="utf-8"):
            if not line.strip():
                continue
            rec = json.loads(line)
            t = tickets.setdefault(rec["ticket_id"], {"batch": rec["batch"], "uids": [],
                                                      "created": rec.get("ts", "")})
            if rec.get("uids"):
                t["uids"] = rec["uids"]
            t["stage"] = rec["stage"]
    for tid, t in tickets.items():
        for u in t["uids"]:
            rule_tickets[u].append(tid)

    # Skip reasons from the most recent run of each batch.
    # Skip reasons, and rules that resolved in the last (possibly dry) run of each batch.
    reasons, ready = {}, set()
    for n, _, _ in batches:
        f = s.OUT / f"sc_preview_batch{n}.json"
        if f.exists():
            d = json.load(open(f, encoding="utf-8"))
            for g, why in d.get("problems", []):
                reasons[g] = why
            ready.update(x.get("graphql_id") for x in d.get("rules", []))
    # Sweep previews (2001+) are the most recent attempt for the rules in them: their
    # resolved rules clear older skip reasons, and their skips replace older ones.
    sweeps = sorted((int(re.findall(r"\d+", f.name)[-1]), f)
                    for f in s.OUT.glob("sc_preview_batch*.json")
                    if int(re.findall(r"\d+", f.name)[-1]) > s.SWEEP_BATCH_BASE)
    for _, f in sweeps:
        d = json.load(open(f, encoding="utf-8"))
        for x in d.get("rules", []):
            reasons.pop(x.get("graphql_id"), None)
            ready.add(x.get("graphql_id"))
        for g, why in d.get("problems", []):
            reasons[g] = why
            ready.discard(g)

    rules, per_batch, listed = [], [], set()
    for n, source, uids in batches:
        c = Counter()
        tids = sorted({tid for u in uids for tid in rule_tickets.get(u, [])}, key=int)
        for u in uids:
            dev, name = mapping.get(u, ("", ""))
            if rule_tickets.get(u):
                status = "Ticketed" if len(rule_tickets[u]) == 1 else "IN MORE THAN ONE TICKET"
                why = ""
            elif u in reasons:
                status, why = "Skipped", reasons[u]
            elif u in ready:
                status, why = "Ready (dry run only)", "Resolved in a dry run - becomes Ticketed on the live run"
            else:
                status, why = "Not submitted", "Batch not run yet (no dry run, no ticket)"
            c[status] += 1
            if u not in listed:          # a rule in both sources is listed once
                listed.add(u)
                rules.append([u, dev, name, n, source, status,
                              ", ".join(rule_tickets.get(u, [])), why])
        per_batch.append([n, source, len(uids), c["Ticketed"], c["Skipped"],
                          c["Ready (dry run only)"], c["Not submitted"],
                          c["IN MORE THAN ONE TICKET"], ", ".join(tids)])

    totals = Counter(r[5] for r in rules)
    wb = Workbook()
    wb.remove(wb.active)
    sheet(wb, "Summary", ["Status", "Rules"],
          [[k, v] for k, v in totals.most_common()] +
          [["Total", len(rules)], [], ["Tickets created", len(tickets)],
           ["Batches", len(batches)]], [28, 12])
    sheet(wb, "Batches", ["Batch", "Source", "Rules", "Ticketed", "Skipped", "Ready (dry run)",
                          "Not submitted", "In >1 ticket", "Ticket IDs"], per_batch,
          [8, 9, 8, 10, 9, 15, 14, 12, 30])
    sheet(wb, "Tickets", ["Ticket", "Batch", "Rules", "Stage", "Created"],
          [[int(tid), t["batch"], len(t["uids"]), t["stage"], t["created"]]
           for tid, t in sorted(tickets.items(), key=lambda x: int(x[0]))],
          [10, 8, 8, 10, 20])
    cols = ["Rule ID", "Device", "Rule Name", "Batch", "Source", "Status", "Ticket", "Reason"]
    widths = [28, 30, 40, 8, 9, 14, 10, 70]
    sheet(wb, "Rules", cols, rules, widths)
    sheet(wb, "Not ticketed", cols, [r for r in rules if r[5] in ("Skipped", "Not submitted",
                                                                   "IN MORE THAN ONE TICKET")], widths)
    sheet(wb, "Ready (dry run)", cols, [r for r in rules if r[5] == "Ready (dry run only)"], widths)

    try:
        wb.save(OUT_FILE)
    except PermissionError:
        raise SystemExit(f"{OUT_FILE.name} is open in Excel - close it and run again.")

    print(f"Wrote {OUT_FILE}")
    for k, v in totals.most_common():
        print(f"  {k:<26}{v:>8,}")
    print(f"  {'Total':<26}{len(rules):>8,}   in {len(tickets)} ticket(s)")
    dry = [b for b in per_batch if b[5]]
    if dry:
        print(f"\n{sum(b[5] for b in dry):,} rule(s) resolved in a dry run only, in batches "
              f"{dry[0][0]}-{dry[-1][0]} - run those live to ticket them.")
    odd = [b for b in per_batch if b[6] or b[7]]
    if odd:
        print("\nBatches needing a look (not run yet / in >1 ticket):")
        for b in odd:
            print(f"  batch {b[0]} ({b[1]}): {b[6]} not run yet, {b[7]} in >1 ticket, "
                  f"tickets {b[8] or '-'}")


if __name__ == "__main__":
    main()

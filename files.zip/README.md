# NPS Automation — Firewall Rule Recertification

Automation supporting the firewall rule recertification campaign: notifying rule owners,
recording their decisions back into Tufin, and acting on those decisions.

| | |
|---|---|
| **Author** | Hardik Patel |
| **Created** | September 2026 |
| **Last modified by** | |
| **Date modified** | |
| **Language** | Python 3.9+ |
| **Dependencies** | `openpyxl`, `requests` |

---

## Layout

```
NPS-Automation/
├── .gitignore
├── SharedData/                     <- all spreadsheets live here (NOT in the repo)
│   ├── Rule-ID-Mapping.xlsx
│   ├── report_GDN Rule Recertification.xlsx
│   ├── report_MediumRule_report_with_APPID.xlsx
│   └── ...                             the other reporting views
├── Notify/
│   ├── notify_rule_owners.py
│   ├── notify_special.py
│   └── Notify_README.md
└── RecertProcessor/
    ├── tag_app_ids.py
    ├── tag_app_ids_README.md
    ├── recert_processor.py
    ├── recert_processor_README.md
    ├── verify_run.py
    └── audit_outputs.py
```

**All four scripts read spreadsheets from `SharedData/`.** They previously each kept their
own copy of the same eleven reporting views, which meant downloading twice and the two
folders drifting out of step.

Each script resolves a bare filename against `DATA_DIR`, which points at `SharedData/`. An
absolute path still works if you need to point somewhere else for a one-off.

**`SharedData/` is deliberately excluded from the repository.** The reporting views and the
Rule-ID-Mapping workbook contain production firewall data — rule names, device names,
owners and app ids — which does not belong in source control. A fresh clone gets an empty
`SharedData/`; populate it with the current exports before running anything.

Script output (`recert_output/`, `tag_output/`, `audit_report.xlsx`) is excluded for the
same reason, and is regenerated on every run.

---

## Scripts

| Script | Purpose | Docs |
|---|---|---|
| `notify_rule_owners.py` | Email rule owners their rules and collect decisions | `Notify/Notify_README.md` |
| `notify_special.py` | Same, driven by a per-list batch table | `Notify/Notify_README.md` |
| `tag_app_ids.py` | Write App-IDs into the Tufin rule description field | `RecertProcessor/tag_app_ids_README.md` |
| `recert_processor.py` | Create recertification and decommission tickets | `RecertProcessor/recert_processor_README.md` |
| `verify_run.py` | Check a run's output is internally consistent | — |
| `audit_outputs.py` | Detailed audit of the output files, as a workbook | — |

**None of these run on a schedule.** All are run deliberately by an operator, and the two
that write to Tufin default to dry run.

---

## Setup

```
py -m pip install openpyxl requests
```

Then populate `SharedData/` with the current reporting views and `Rule-ID-Mapping.xlsx`.
Nothing runs without them, and they are not in the repository.

Credentials are prompted at runtime and never written to disk. `SECURETRACK_USER` and
`SECURETRACK_PASSWORD` work for an unattended run, but must never be typed into the files
— these go to the repository.

Two things about Tufin accounts:

- The SecureTrack **API role is granted separately from UI access**. An account can sign
  in to the Tufin web interface and still get 403 from the GraphQL API.
- `ticketAPI` has the broad rights these scripts need, but every Tufin workflow also runs
  on it, so a mistake with that account has wider reach than a personal one.

**Environments**

| | Host |
|---|---|
| Lab | `keeppgelabsecure.utility.pge.com` |
| Production | `keeppgesecure.utility.pge.com` |

Both use the `tufin-realm` Keycloak realm. Change `SECURETRACK_GRAPHQL` and
`KEYCLOAK_TOKEN_URL` together — pointing one at production and leaving the other on lab
fails in a confusing way.

---

## Typical run

```
cd RecertProcessor

py tag_app_ids.py          # dry run -> tag_output/tag_plan.xlsx
py recert_processor.py     # dry run -> recert_output/*.xlsx
py verify_run.py           # pass/fail verdict on both
```

Review the plan files, then set `DRY_RUN = False` for a live run.

---

## Verifying a run

`verify_run.py` reads the plan files and runs twenty checks — arithmetic that must
reconcile, plus integrity rules such as "a rule cannot be both scheduled for disable and
held back". Exit code 0 on pass, 1 on failure. Its output is counts and pass/fail only, so
it is safe to paste into a ticket.

`audit_outputs.py` is the deeper version, for when something fails and you need examples.
It writes `audit_report.xlsx` with five filterable tabs — Summary, Columns, Integrity,
Anomalies and Samples. Its output **does** contain rule names and UIDs, so treat it as
production data.

---

## Open items

| Item | Status |
|---|---|
| `SKIP_RLM_DESCRIPTIONS` — skip or append below the `##RLM##` block | Confirm before the first production write |
| Last-hit threshold — 90 days flat, or 90 for delete / 65 for disable | Open; defaults to 90 |
| Policy for rules with no hit data | Open; defaults to skip. Re-evaluate against production hit data |
| Device+rule pairs with conflicting UIDs in the mapping workbook | Open; those rules are skipped |
| DR rules require a tag added to the Panoramas | Open; firewall team |
| Recertification ticket volume and batching | Open; one ticket per rule is a large volume |
| Credentials via Safeguard Core API rather than prompt | In progress |

# recert_processor

Turns firewall rule recertification decisions into Tufin tickets.

Owners record a decision against each rule in a SharePoint list. This reads the exported
reporting view, matches each rule to Tufin, and creates the corresponding ticket —
recertification tickets for rules being kept, disable tickets for rules being cleaned up.

Rules marked for cleanup pass through a traffic check first. A rule still carrying
traffic is not disabled, whatever the spreadsheet says.

---

## Status

| Path | State |
|---|---|
| Recertify | Wired |
| Decommission — disable | Wired |
| Decommission — remove | Not built. See [The remove pass](#the-remove-pass) |

Every API value is confirmed against live Tufin by introspection and dry run, not
inferred. Nothing here is a guess about the schema.

---

## Requirements

```
py -m pip install openpyxl requests
```

Python 3.9+. You need SecureTrack credentials with permission to create tickets, and the
reporting-view export for the batch you are processing.

---

## Running it

```
py recert_processor.py
```

You will be prompted for your SecureTrack username and password. Nothing is stored.
Alternatively set `SECURETRACK_USER` and `SECURETRACK_PASSWORD` in the environment.

**`DRY_RUN = True` is the default and should stay that way until you have read the
output of a full run.** In dry run every ticket is validated by Tufin through
`createTicketDraft`'s `dryRun` flag — the same validation a real submission gets — but
nothing is created. All CSVs are written exactly as they would be on a live run, so a
dry run tells you precisely what a live run would do.

Before a live run:

1. Set `RUN_TAG` to something unique for this run.
2. Confirm `LAST_HIT_THRESHOLD_DAYS` and `NEVER_HIT_POLICY` (see below).
3. Do a dry run and read `held_back_from_disable.csv`.
4. Set `DRY_RUN = False`.

---

## Configuration

Everything is at the top of the file. The ones that matter:

### `RUN_TAG`

Goes into the subject line of every disable ticket. It is how you find this run's
tickets later, when it is time to remove the rules you disabled.

**Change it every run.** Reusing a tag makes two runs indistinguishable, which defeats
the point. Something like `cleanup ODN 2026-08` — scope plus date.

### `LAST_HIT_THRESHOLD_DAYS` — currently `90`

A rule hit within this many days is never disabled, regardless of the owner's decision.
This is the control standing between the automation and a production outage.

> **Unconfirmed.** Guidance has been given both as a flat 90 days and as "90 for delete,
> 65 for disable". 90 is the more conservative reading — a longer protection window — so
> it is the default. Confirm before running against production.

### `NEVER_HIT_POLICY` — currently `"skip"`

What to do with rules where Tufin has no hit data at all (`timeLastHit` is null).

- `"skip"` — hold back, write to CSV, let a human decide
- `"disable"` — treat as unused

A null is **not** the same as "not hit recently". It means there is no evidence either
way. In lab these were overwhelmingly OT and SCADA paths — exactly the traffic that is
real but intermittent, like a backup route that only carries traffic during a failover,
and exactly where being wrong is worst.

> **Unconfirmed.** Confirm with the process owner before changing.

### `CAMPAIGN_END_DATE` and `REPORT_MAX_AGE_DAYS`

The script refuses to run past the campaign end date, or against a reporting view older
than `REPORT_MAX_AGE_DAYS`.

This exists because the script acts on decisions it did not make. Months after a campaign
closes, someone can still open the old SharePoint list and change a decision. Without
these guards a stale export would be acted on as if it were current. If a campaign is
genuinely still open, move the date forward deliberately rather than deleting the check.

### `RULE_FILTER`

TQL, not GraphQL. Controls which rules are considered at all. Note that decommission
eligibility is narrower than recertification eligibility — some rules that pass this
filter will still be rejected for decom. That is handled (see `RUD_7` below) rather than
prevented.

---

## The safety model

Rules marked Cleanup/Remove are sorted into three buckets by `timeLastHit`:

| Bucket | Meaning | Action |
|---|---|---|
| `recent` | Hit inside the threshold | **Never disabled.** Held back with the hit date. |
| `stale` | Hit, but longer ago than the threshold | Disabled. Evidence it is unused. |
| `never` | `timeLastHit` is null | Governed by `NEVER_HIT_POLICY`. Skipped by default. |

Bucketing happens in Python rather than in the TQL filter, deliberately. A null
`timeLastHit` matches neither `after N days ago` nor `before N days ago`, so filtering
server-side would let never-hit rules fall into or out of the disable set silently,
depending on parser semantics. Doing it in code makes it a decision you can see.

Only the middle bucket is automated. The first is protected. The third needs a human.

---

## Output

Written to `recert_output/`, cleared at the start of each run.

| File | What it is |
|---|---|
| `recertify_plan.csv` | Rules submitted for recertification |
| `disable_plan.csv` | Rules submitted for disable, with hit date and run tag |
| `held_back_from_disable.csv` | **Read this one.** Cleanup rules the guard refused, with the reason |
| `need_assistance.csv` | Owner asked for help. No ticket created. |
| `rejected_by_tufin.csv` | UIDs Tufin refused as ineligible (only written if any) |

`held_back_from_disable.csv` is the one worth actual attention. A rule showing recent
traffic while its owner believes it is dead is a conversation to have before you widen
the guard — the owner may be wrong about what the rule does, or the rule may be serving
something nobody has documented.

---

## Things that will bite you

**`createTicketDraft` is all-or-nothing.** One ineligible rule fails the entire draft
with error code `RUD_7`. This was proven on a two-rule dry run where a single bad rule
failed both. At batch sizes of hundreds it will fire on most runs, so `submit_ticket()`
catches `RUD_7`, drops the UIDs named in `invalidRules`, and retries once with the
remainder. Dropped UIDs land in `rejected_by_tufin.csv`. Without this, one bad rule
costs you 300.

**The enum type is `WorkFlowType`, with a capital F mid-word.** Not `WorkflowType`. It
does not match the casing convention used elsewhere in the schema, and a mutation
declaring the wrong one fails validation before it is ever sent. Note that writing an
enum inline in GraphiQL bypasses the variable declaration entirely, so a query can appear
to work there and still fail from a script.

**`ResultStatus` has no `message` field.** It has `successful` and `errors`, where
`errors` is a list of `{ errorCode, errorMessage }`.

**`invalidRules` only has `ruleUid` confirmed.** Do not add fields to it without
introspecting first.

**Introspection is capped at one `__type` per request.** The server runs graphql-java's
`GoodFaithIntrospection` guard. Aliasing two `__type` calls into one query is rejected
with `BadFaithIntrospection`. If you ever have this script introspect the schema, one
`__type` per request.

**Lab and production do not have matching workflow inventories.** Confirm the workflow
name exists in production, spelled identically, before pointing this at it.

**The decommission workflow auto-confirms after 2 days.** Tickets advance without anyone
acting on them. That is a different clock from the wait period between disable and
remove, and the interaction is worth settling before creating decom tickets in volume.

---

## The remove pass

Disable is reversible. Remove is not. They are deliberately separate runs with a soak
period between them, so that anything broken by the disable surfaces while it can still
be undone. Creating both tickets up front would turn that soak period into a formality.

The API side is already confirmed — same mutation, same workflow, with
`decommissionRulesAction: REMOVE_RULES`. Two things need settling before it is built:

1. **How to identify what a given run disabled.** `RUN_TAG` is in the subject of every
   disable ticket, so the correlation exists, but reading it back means querying
   SecureChange tickets — something this script has never done. The alternative is
   checking current rule state in Tufin, which is simpler but cannot distinguish a rule
   this script disabled from one disabled by hand a year ago.

2. **Whether elapsed time alone authorises removal**, or a human signs off first.

Either way, one requirement holds: re-validate that the rule is **still disabled**
immediately before removing it. Someone may have re-enabled it during the wait, and that
is precisely the signal the soak period exists to surface.

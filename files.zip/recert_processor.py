"""
recert_processor.py
===================
Workstream 2, Task 2 — Create recertification and decommission tickets from owner decisions
PG&E | NPS Automation

STATUS
  RECERTIFY path  — wired.
  DECOM DISABLE   — wired. Every value confirmed by introspection + dry run 2026-08-28.
  DECOM REMOVE    — deliberately NOT wired. See the REMOVE PASS note near the bottom.

CONFIRMED AGAINST LIVE TUFIN (lab, keeppgelabsecure)
  Read      rules(filter){ count values(first,offset){ id idOnDevice timeLastHit } }
  Ticket    ruleOperations { createTicketDraft(input:{ ruleUids, workflowType,
            workflowName, decommissionRulesAction, subject, dryRun }) {
              invalidRules { ruleUid }
              resultStatus { successful errors { errorCode errorMessage } } } }
  Enums     WorkFlowType             RECERTIFY_RULES | DECOMMISSION_RULES | MODIFY_RULES
            DecommissionRulesAction  DISABLE_RULES | REMOVE_RULES
  Workflows "RLM Rule Recertification Workflow"   (recertify)
            "MP RLM Rule Decommission/Disable"    (decommission, handles both actions)
  Join key  reporting-view "Rule Name" == Tufin idOnDevice
  Hit data  timeLastHit is a DateTime on Rule and IS populated

TWO FIXES TO THE PREVIOUS VERSION, BOTH WOULD HAVE FAILED AT RUNTIME
  1. The enum type is WorkFlowType, with a capital F mid-word. The old mutation declared
     $workflowType: WorkflowType! which does not exist, so the mutation could never have
     validated. The earlier recertify confirmation was done in GraphiQL with the enum
     written inline, which bypasses the variable declaration entirely.
  2. invalidRules { reason ruleUid } used a 'reason' field that was never confirmed. Only
     ruleUid is confirmed, so only ruleUid is requested.

createTicketDraft IS ALL-OR-NOTHING
  One ineligible UID fails the whole draft with errorCode RUD_7 — proven on the dry run,
  where a single bad rule in a pair of two failed both. At batch sizes of hundreds this
  will fire on most runs, so submit_ticket() drops the flagged UIDs and retries rather
  than losing the batch.

WHAT THIS DOES
  1. Refuse to run at all if the campaign has closed or the reporting view is stale.
  2. Read the reporting view: Rule Name -> decision.
  3. Query Tufin for candidate rules, carrying timeLastHit.
  4. Join on Rule Name == idOnDevice.
  5. Recertify decisions -> recertification tickets.
  6. Cleanup/Remove decisions -> LAST-HIT GUARD -> disable tickets for what passes.
  7. Everything held back gets written to CSV with the reason.
"""

import csv
import getpass
import logging
import requests
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import Enum
from pathlib import Path

# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────

DRY_RUN = True   # True = validate via createTicketDraft dryRun, create nothing.
                 # Leave True until a full run has been reviewed.

# ── Run identity ──────────────────────────────────────────────────────────────
# Pattern borrowed from the existing Panorama cleanup tooling: every run carries a
# unique tag so the disable pass and the later remove pass can be correlated without
# tracking state locally. It goes in the ticket subject, which is the only free-text
# field on the mutation. CHANGE THIS EVERY RUN — reusing a tag makes two runs
# indistinguishable.
RUN_TAG = "cleanup ODN 2026-08"

# ── Stale-list protection ─────────────────────────────────────────────────────
# The risk: months from now the campaign is closed, someone opens an old SharePoint
# list, changes a decision, and this script acts on it. Two guards against that.
CAMPAIGN_END_DATE   = "2026-09-30"  # YYYY-MM-DD. Script refuses to run after this.
REPORT_MAX_AGE_DAYS = 3             # Refuse if the reporting view file is older.

# ── Last-hit guard ────────────────────────────────────────────────────────────
# The single most important control here. A rule that is still passing traffic does not
# get disabled, whatever the spreadsheet says. A rule hit inside the threshold is held
# back regardless of the owner's decision, to avoid production outages.
#
# UNCONFIRMED: guidance has been given both as a flat 90 days and as "90 for delete,
# 65 for disable". 90 is the more conservative reading (longer protection window) so it
# is the default. CONFIRM BEFORE A PRODUCTION RUN — this number decides whether a live
# rule gets turned off.
LAST_HIT_THRESHOLD_DAYS = 90

# What to do with rules whose timeLastHit is null. These are NOT the same as "not hit
# recently" — there is no evidence either way. In lab these were overwhelmingly OT and
# SCADA paths, which is exactly the traffic that is real but intermittent, and where
# being wrong is worst.
#   "skip"    hold back, write to CSV for a human    <- default, and the safe choice
#   "disable" treat as unused and disable
# UNCONFIRMED. Confirm with the process owner before changing.
NEVER_HIT_POLICY = "skip"

# ── Input ─────────────────────────────────────────────────────────────────────
REPORT_PATH      = "report_rules.xlsx"

# JOIN COLUMN. The UID is exact. Rule names repeat across devices, so a name join
# can attach one sheet row to rules on several boxes — proven on 2026-09-15, where
# one row fanned out to 100 rules. If the sheet has a SecureTrack Rule ID column it
# is used; otherwise the script stops rather than silently falling back.
# Reporting-view columns. These sheets have no UID; the mapping workbook supplies it.
DEVICE_COLUMN    = "Device Name"
RULE_NAME_COLUMN = "Rule Name"        # equals the mapping's "ID on Device"
DECISION_COLUMN  = "Recertification"
UID_COLUMN       = "SecureTrack Rule ID"   # used if the sheet happens to have one

# Which tab to read. Reporting views have one sheet; a decisions workbook may have
# several (Cleanup / Recertified / Recertified-DR) — name the one you want.
INPUT_SHEET      = None               # None = first tab

REQUIRE_UID      = True

# ── Tufin ─────────────────────────────────────────────────────────────────────
SECURETRACK_GRAPHQL = "https://keeppgelabsecure.utility.pge.com/v2/api/sync/graphql"
GRAPHQL_PAGE_SIZE   = 100
GRAPHQL_MAX_PAGES   = 2000
VERIFY_TLS          = False

# One fetch serves both paths — decisions are what split them afterwards.
#
# Be aware decom eligibility is NARROWER than recert. Proven on the dry run: a rule that
# satisfied securechangeTicketInProgressId not exists was still rejected as invalid for
# decommission. The RUD_7 retry absorbs that, so it costs a wasted round
# trip rather than a failed batch. If rejected_by_tufin.csv gets large, the extra
# criteria are worth chasing down and adding as a separate decom filter.
RULE_FILTER = ("vendor='PALO_ALTO' and securechangeTicketInProgressId not exists "
               "and (violationHighestSeverity='CRITICAL' or violationHighestSeverity='HIGH') "
               "and (idOnDevice contains 'ADMS')")

# ── Workflows — all confirmed ─────────────────────────────────────────────────
RECERTIFY_WORKFLOW_TYPE = "RECERTIFY_RULES"
RECERTIFY_WORKFLOW_NAME = "RLM Rule Recertification Workflow"
RECERTIFY_SUBJECT       = "Recertify Firewall Rules - NPS"

DECOM_WORKFLOW_TYPE  = "DECOMMISSION_RULES"
DECOM_WORKFLOW_NAME  = "MP RLM Rule Decommission/Disable"
DECOM_ACTION_DISABLE = "DISABLE_RULES"
DECOM_ACTION_REMOVE  = "REMOVE_RULES"   # not used — see REMOVE PASS note

TICKET_BATCH_SIZE = 300

# ── Auth ──────────────────────────────────────────────────────────────────────
KEYCLOAK_TOKEN_URL = "https://keeppgelabsecure.utility.pge.com/auth/realms/tufin-realm/protocol/openid-connect/token"
KEYCLOAK_CLIENT_ID = "admin-cli"
KEYCLOAK_USERNAME  = ""   # blank -> prompted (or env SECURETRACK_USER)
KEYCLOAK_PASSWORD  = ""   # blank -> prompted. Never hardcode.

OUTPUT_DIR = "recert_output"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("recert_processor")


# ─────────────────────────────────────────────
# Decisions
# ─────────────────────────────────────────────

class Decision(Enum):
    RECERTIFY = "recertify"
    REMOVE    = "remove"      # Cleanup / Remove -> disable ticket
    ASSIST    = "assist"
    NONE      = "none"


def parse_decision(value) -> Decision:
    if value is None:
        return Decision.NONE
    v = str(value).strip().lower()
    if not v:
        return Decision.NONE
    if v.startswith("recert"):
        return Decision.RECERTIFY
    if "cleanup" in v or "remove" in v:
        return Decision.REMOVE
    if "assist" in v:
        return Decision.ASSIST
    return Decision.NONE


class HitState(Enum):
    RECENT = "recent"   # hit inside the threshold -> never disable
    STALE  = "stale"    # hit, but older than the threshold -> safe to disable
    NEVER  = "never"    # timeLastHit null -> no evidence either way


@dataclass
class Rule:
    uid: str
    id_on_device: str = ""
    decision: Decision = Decision.NONE
    last_hit: datetime = None
    hit_state: HitState = None

    @property
    def last_hit_str(self) -> str:
        return self.last_hit.strftime("%Y-%m-%d") if self.last_hit else "never"


# ─────────────────────────────────────────────
# Pre-flight guards
# ─────────────────────────────────────────────

def preflight() -> bool:
    """
    Refuse to run on a closed campaign or a stale reporting view. Returns False to abort.
    This exists because the script acts on decisions it did not make; if those decisions
    are old, acting on them is worse than doing nothing.
    """
    ok = True

    try:
        end = datetime.strptime(CAMPAIGN_END_DATE, "%Y-%m-%d").date()
    except ValueError:
        log.error(f"CAMPAIGN_END_DATE '{CAMPAIGN_END_DATE}' is not YYYY-MM-DD. Aborting.")
        return False

    today = datetime.now().date()
    if today > end:
        log.error(f"Campaign closed on {end} (today is {today}). Refusing to run.")
        log.error("If this campaign is genuinely still open, move CAMPAIGN_END_DATE "
                  "forward deliberately rather than removing this check.")
        ok = False

    path = Path(REPORT_PATH)
    if not path.exists():
        log.error(f"Reporting view not found: {REPORT_PATH}")
        return False

    age_days = (datetime.now() - datetime.fromtimestamp(path.stat().st_mtime)).days
    if age_days > REPORT_MAX_AGE_DAYS:
        log.error(f"{path.name} is {age_days} days old (limit {REPORT_MAX_AGE_DAYS}). "
                  f"Re-download the reporting view before running.")
        ok = False
    else:
        log.info(f"Reporting view {path.name} is {age_days} day(s) old — OK")

    if NEVER_HIT_POLICY not in ("skip", "disable"):
        log.error(f"NEVER_HIT_POLICY must be 'skip' or 'disable', got '{NEVER_HIT_POLICY}'")
        ok = False

    if not RUN_TAG.strip():
        log.error("RUN_TAG is empty. It is the only way to correlate this run's disable "
                  "tickets with a later remove pass.")
        ok = False

    return ok


# ─────────────────────────────────────────────
# Auth
# ─────────────────────────────────────────────

_TOKEN_CACHE = {"token": None}

def get_access_token() -> str:
    import os
    if _TOKEN_CACHE["token"]:
        return _TOKEN_CACHE["token"]
    username = KEYCLOAK_USERNAME or os.environ.get("SECURETRACK_USER", "")
    password = KEYCLOAK_PASSWORD or os.environ.get("SECURETRACK_PASSWORD", "")
    if not username:
        username = input("SecureTrack username (CorpID): ").strip()
    if not password:
        password = getpass.getpass("SecureTrack password: ")
    resp = requests.post(
        KEYCLOAK_TOKEN_URL,
        data={"grant_type": "password", "client_id": KEYCLOAK_CLIENT_ID,
              "username": username, "password": password},
        verify=VERIFY_TLS, timeout=30,
    )
    resp.raise_for_status()
    token = resp.json()["access_token"]
    _TOKEN_CACHE["token"] = token
    return token


# ─────────────────────────────────────────────
# GraphQL
# ─────────────────────────────────────────────

def _graphql(query: str, variables: dict) -> dict:
    token = get_access_token()
    resp = requests.post(
        SECURETRACK_GRAPHQL,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        json={"query": query, "variables": variables},
        verify=VERIFY_TLS, timeout=60,
    )
    resp.raise_for_status()
    data = resp.json()
    if data.get("errors"):
        raise RuntimeError(f"GraphQL errors: {data['errors']}")
    return data


_RULE_QUERY = """
query Rules($filter: String!, $first: Int!, $offset: Int!) {
  rules(filter: $filter) {
    count
    values(first: $first, offset: $offset) {
      id
      idOnDevice
      timeLastHit
    }
  }
}
"""

# Note the enum type names: WorkFlowType (capital F) and DecommissionRulesAction.
# decommissionRulesAction is nullable in the schema, so one mutation serves both paths —
# recertify passes null, decom passes DISABLE_RULES.
_CREATE_TICKET_MUTATION = """
mutation CreateTicket($ruleUids: [String!]!, $workflowType: WorkFlowType!,
                      $workflowName: String!, $subject: String!, $dryRun: Boolean!,
                      $decommissionRulesAction: DecommissionRulesAction) {
  ruleOperations {
    createTicketDraft(input: {
      ruleUids: $ruleUids,
      workflowType: $workflowType,
      workflowName: $workflowName,
      subject: $subject,
      dryRun: $dryRun,
      decommissionRulesAction: $decommissionRulesAction
    }) {
      invalidRules { ruleUid }
      resultStatus { successful errors { errorCode errorMessage } }
    }
  }
}
"""


def _parse_dt(value):
    """timeLastHit comes back as 2023-10-29T07:00:00.000Z. Null means never hit."""
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        log.warning(f"Could not parse timeLastHit '{value}' — treating as never hit")
        return None


def fetch_rules(rule_filter: str) -> list:
    """Paginated rule fetch carrying timeLastHit for the guard."""
    rules, offset, total = [], 0, None
    for _ in range(GRAPHQL_MAX_PAGES):
        data = _graphql(_RULE_QUERY,
                        {"filter": rule_filter, "first": GRAPHQL_PAGE_SIZE, "offset": offset})
        block = data["data"]["rules"]
        total = block.get("count", total)
        batch = block.get("values", [])
        if not batch:
            break
        for item in batch:
            rules.append(Rule(uid=str(item.get("id", "")),
                              id_on_device=item.get("idOnDevice") or "",
                              last_hit=_parse_dt(item.get("timeLastHit"))))
        offset += GRAPHQL_PAGE_SIZE
        log.info(f"Fetched {len(rules)}" + (f" of {total}" if total is not None else "")
                 + " rule(s)")
        if total is not None and offset >= total:
            break
    return rules


def submit_ticket(uids, workflow_type, workflow_name, subject, decom_action=None,
                  dry_run=True, _retry=True) -> dict:
    """
    Create or dry-run one ticket.

    createTicketDraft is all-or-nothing: one ineligible UID fails the entire draft with
    RUD_7. Rather than lose a batch of hundreds over a handful of bad rules, this drops
    the UIDs named in invalidRules and retries once with the remainder.

    Returns { successful, submitted, dropped, errors }.
    """
    data = _graphql(_CREATE_TICKET_MUTATION, {
        "ruleUids": uids,
        "workflowType": workflow_type,
        "workflowName": workflow_name,
        "subject": subject,
        "dryRun": dry_run,
        "decommissionRulesAction": decom_action,
    })
    result  = data["data"]["ruleOperations"]["createTicketDraft"]
    status  = result.get("resultStatus") or {}
    errors  = status.get("errors") or []
    invalid = [r.get("ruleUid") for r in (result.get("invalidRules") or []) if r.get("ruleUid")]

    if status.get("successful"):
        return {"successful": True, "submitted": uids, "dropped": [], "errors": []}

    is_rud7 = any((e.get("errorCode") or "") == "RUD_7" for e in errors)
    if _retry and is_rud7 and invalid:
        remaining = [u for u in uids if u not in set(invalid)]
        if not remaining:
            log.warning(f"  all {len(uids)} rule(s) in this batch were ineligible")
            return {"successful": False, "submitted": [], "dropped": invalid, "errors": errors}
        log.warning(f"  RUD_7: {len(invalid)} ineligible rule(s) dropped, "
                    f"retrying with {len(remaining)}")
        retry = submit_ticket(remaining, workflow_type, workflow_name, subject,
                              decom_action, dry_run, _retry=False)
        retry["dropped"] = invalid + retry.get("dropped", [])
        return retry

    return {"successful": False, "submitted": [], "dropped": invalid, "errors": errors}


# ─────────────────────────────────────────────
# Rule-ID mapping workbook  ->  UID lookup
# ─────────────────────────────────────────────
#
# The reporting views carry decisions and App-IDs but no rule UID. The
# Rule-ID-Mapping workbook carries Device Name + ID on Device -> SecureTrack Rule ID
# for the whole estate. Joining through it keeps the reporting views as the input
# (which is the point) while still addressing rules by UID (which is exact).
#
# The key is built from the Device Name and ID on Device COLUMNS, not by parsing the
# pre-joined "DeviceName+RuleName" column. Rule names contain hyphens of their own
# ("Citrix to GE Relays-svc"), so splitting that column on "-" is not safe.

MAPPING_PATH        = "Rule-ID-Mapping.xlsx"
MAPPING_SHEET       = "Rule-ID-Mapping"   # tab name; also matched case-insensitively
MAP_DEVICE_COLUMN   = "Device Name"
MAP_RULE_COLUMN     = "ID on Device"      # same value as the reporting view's Rule Name
MAP_UID_COLUMN      = "SecureTrack Rule ID"


def _norm(value) -> str:
    """Trim, collapse inner whitespace, uppercase. Device names drift on spacing."""
    if value is None:
        return ""
    return " ".join(str(value).split()).upper()


def _key(device, rule) -> str:
    return f"{_norm(device)}||{_norm(rule)}"


def load_uid_map(path=None, sheet=None):
    """
    Returns (uid_by_key, devices) where uid_by_key is { 'DEVICE||RULE': uid } and
    devices is the set of device names seen — useful for diagnosing a join that
    matches nothing because the two files name devices differently.
    """
    from openpyxl import load_workbook
    from pathlib import Path

    p = Path(path or MAPPING_PATH)
    want = sheet or MAPPING_SHEET
    if not p.exists():
        log.error(f"Rule-ID mapping workbook not found: {p}")
        return {}, set()

    try:
        wb = load_workbook(p, read_only=True, data_only=True)
    except PermissionError:
        log.error(f"{p.name} is locked. Close it in Excel and run again.")
        return {}, set()

    names = wb.sheetnames
    target = next((n for n in names if n.strip().lower() == want.strip().lower()), None)
    if target is None:
        log.error(f"No '{want}' tab in {p.name}. Tabs present: {names}")
        wb.close()
        return {}, set()

    ws = wb[target]
    rows = ws.iter_rows(values_only=True)
    try:
        header = [str(h).strip() if h is not None else "" for h in next(rows)]
    except StopIteration:
        wb.close()
        return {}, set()

    def find(label):
        t = label.lower()
        for i, h in enumerate(header):
            if h.lower() == t:
                return i
        for i, h in enumerate(header):
            if h.lower().startswith(t[:14]):
                return i
        return None

    d_i, r_i, u_i = find(MAP_DEVICE_COLUMN), find(MAP_RULE_COLUMN), find(MAP_UID_COLUMN)
    if None in (d_i, r_i, u_i):
        log.error(f"'{target}' needs '{MAP_DEVICE_COLUMN}', '{MAP_RULE_COLUMN}' and "
                  f"'{MAP_UID_COLUMN}'. Found: {header}")
        wb.close()
        return {}, set()

    uid_by_key, devices, dupes, blanks = {}, set(), 0, 0
    for row in rows:
        if not any(row):
            continue
        dev = row[d_i] if d_i < len(row) else None
        rul = row[r_i] if r_i < len(row) else None
        uid = row[u_i] if u_i < len(row) else None
        if not dev or not rul or not uid:
            blanks += 1
            continue
        k = _key(dev, rul)
        if k in uid_by_key and uid_by_key[k] != str(uid).strip():
            dupes += 1          # same device+rule twice with different UIDs
            continue
        uid_by_key[k] = str(uid).strip()
        devices.add(_norm(dev))

    wb.close()
    log.info(f"Loaded {len(uid_by_key):,} UID mapping(s) from {p.name} [{target}], "
             f"{len(devices)} device(s)")
    if blanks:
        log.info(f"  {blanks:,} mapping row(s) skipped — incomplete")
    if dupes:
        log.warning(f"  {dupes:,} device+rule pair(s) appeared twice with different UIDs "
                    f"and were skipped — those rules cannot be addressed unambiguously")
    return uid_by_key, devices


def resolve_uids(records, uid_by_key, map_devices, label="row"):
    """
    records: list of dicts with 'device' and 'rule' keys. Sets 'uid' on each.
    Returns (resolved, unresolved). Unresolved rows are REPORTED, never silently
    dropped — a silent drop is how a run can look successful having done nothing.
    """
    resolved, unresolved = [], []
    for rec in records:
        uid = uid_by_key.get(_key(rec.get("device"), rec.get("rule")))
        if uid:
            rec["uid"] = uid
            resolved.append(rec)
        else:
            unresolved.append(rec)

    log.info(f"Resolved {len(resolved):,} of {len(records):,} {label}(s) to a rule UID")
    if unresolved:
        log.warning(f"{len(unresolved):,} {label}(s) did not resolve and will be skipped")
        sheet_devices = {_norm(r.get("device")) for r in unresolved if r.get("device")}
        never = sorted(d for d in sheet_devices if d not in map_devices)
        if never:
            log.warning(f"  {len(never)} device name(s) appear in the sheet but NOT in the "
                        f"mapping at all — likely a naming mismatch between the two files:")
            for d in never[:5]:
                log.warning(f"    {d}")
        else:
            log.warning("  all device names matched, so these are rule-name differences "
                        "(renamed, deleted, or not in the mapping's scope)")
        for r in unresolved[:3]:
            log.warning(f"  e.g. {r.get('device')} / {r.get('rule')}")
    return resolved, unresolved


# ─────────────────────────────────────────────
# Reporting view
# ─────────────────────────────────────────────

def load_decisions(report_path):
    """
    Read a reporting view: Device Name + Rule Name + decision.
    Returns a list of {device, rule, decision} — UIDs are resolved separately.
    """
    from openpyxl import load_workbook
    path = Path(report_path)
    if not path.exists():
        log.error(f"Reporting view not found: {report_path}")
        return []

    try:
        wb = load_workbook(path, read_only=True, data_only=True)
    except PermissionError:
        log.error(f"{path.name} is locked. Close it in Excel (and let OneDrive finish "
                  f"syncing), then run again.")
        return []
    except Exception as e:
        log.error(f"Could not open {path.name}: {e}")
        return []

    if INPUT_SHEET:
        tab = next((n for n in wb.sheetnames
                    if n.strip().lower() == INPUT_SHEET.strip().lower()), None)
        if tab is None:
            log.error(f"No '{INPUT_SHEET}' tab in {path.name}. Tabs: {wb.sheetnames}")
            wb.close()
            return []
    else:
        tab = wb.sheetnames[0]

    ws = wb[tab]
    rows = ws.iter_rows(values_only=True)
    try:
        header = [str(h).strip() if h is not None else "" for h in next(rows)]
    except StopIteration:
        wb.close()
        return []

    def find(label):
        t = label.lower()
        for i, h in enumerate(header):
            if h.lower() == t:
                return i
        for i, h in enumerate(header):
            if h.lower().startswith(t[:14]):
                return i
        return None

    dev_i, rule_i, dec_i = find(DEVICE_COLUMN), find(RULE_NAME_COLUMN), find(DECISION_COLUMN)
    uid_i = find(UID_COLUMN)

    missing = [n for n, i in ((DEVICE_COLUMN, dev_i), (RULE_NAME_COLUMN, rule_i),
                              (DECISION_COLUMN, dec_i)) if i is None]
    if missing:
        log.error(f"'{tab}' is missing {missing}. Found: {header}")
        wb.close()
        return []

    seen, out = {}, []
    for row in rows:
        if not any(row):
            continue
        dev  = row[dev_i] if dev_i < len(row) else None
        rule = row[rule_i] if rule_i < len(row) else None
        if not dev or not rule:
            continue
        dec = parse_decision(row[dec_i] if dec_i < len(row) else None)
        k = (str(dev).strip().upper(), str(rule).strip().upper())
        if k in seen and dec is Decision.NONE:
            continue            # a later blank never overwrites a real decision
        rec = {"device": str(dev).strip(), "rule": str(rule).strip(), "decision": dec}
        if uid_i is not None and uid_i < len(row) and row[uid_i]:
            rec["uid"] = str(row[uid_i]).strip()
        if k in seen:
            out[seen[k]] = rec
        else:
            seen[k] = len(out)
            out.append(rec)

    wb.close()
    counts = {}
    for r in out:
        counts[r["decision"].value] = counts.get(r["decision"].value, 0) + 1
    log.info(f"Loaded {len(out):,} rule decision(s) from {path.name} [{tab}]: {counts}")
    return out


# ─────────────────────────────────────────────
# Last-hit guard
# ─────────────────────────────────────────────

def classify_hits(rules):
    """
    Bucket by traffic evidence. Done in Python rather than via a TQL filter on purpose:
    a null timeLastHit matches neither 'after N days ago' nor 'before N days ago', so
    filtering would let never-hit rules fall silently into or out of the disable set
    depending on parser semantics. Bucketing explicitly makes that a decision.
    """
    cutoff = datetime.now(timezone.utc) - timedelta(days=LAST_HIT_THRESHOLD_DAYS)
    for r in rules:
        if r.last_hit is None:
            r.hit_state = HitState.NEVER
        elif r.last_hit >= cutoff:
            r.hit_state = HitState.RECENT
        else:
            r.hit_state = HitState.STALE
    return rules


def split_for_disable(remove_rules):
    """
    Apply the guard to rules marked Cleanup/Remove.
    Returns (to_disable, held_back) where held_back is [(rule, reason)].
    """
    to_disable, held = [], []
    for r in remove_rules:
        if r.hit_state is HitState.RECENT:
            held.append((r, f"hit {r.last_hit_str}, within {LAST_HIT_THRESHOLD_DAYS} days "
                            f"- still carrying traffic"))
        elif r.hit_state is HitState.NEVER:
            if NEVER_HIT_POLICY == "skip":
                held.append((r, "no hit data - needs human review before disable"))
            else:
                to_disable.append(r)
        else:
            to_disable.append(r)
    return to_disable, held


# ─────────────────────────────────────────────
# Output
# ─────────────────────────────────────────────

def chunked(items, size):
    for i in range(0, len(items), size):
        yield items[i:i + size]


def write_csv(name, header, rows):
    path = Path(OUTPUT_DIR) / name
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)
    return path


def write_outputs(recertify, to_disable, held_back, flagged_assist, dropped_uids):
    Path(OUTPUT_DIR).mkdir(exist_ok=True)

    write_csv("recertify_plan.csv",
              ["rule_uid", "rule_name", "last_hit"],
              [[r.uid, r.id_on_device, r.last_hit_str] for r in recertify])

    write_csv("disable_plan.csv",
              ["rule_uid", "rule_name", "last_hit", "hit_state", "run_tag"],
              [[r.uid, r.id_on_device, r.last_hit_str, r.hit_state.value, RUN_TAG]
               for r in to_disable])

    # The important one. Every rule an owner marked for cleanup that the guard held back,
    # with the reason. Review this before widening the guard.
    write_csv("held_back_from_disable.csv",
              ["rule_uid", "rule_name", "last_hit", "hit_state", "reason"],
              [[r.uid, r.id_on_device, r.last_hit_str, r.hit_state.value, reason]
               for r, reason in held_back])

    write_csv("need_assistance.csv",
              ["rule_uid", "rule_name", "last_hit"],
              [[r.uid, r.id_on_device, r.last_hit_str] for r in flagged_assist])

    if dropped_uids:
        write_csv("rejected_by_tufin.csv",
                  ["rule_uid", "note"],
                  [[u, "RUD_7 - not eligible for this workflow; dropped so the batch "
                       "could proceed"] for u in dropped_uids])

    log.info(f"Wrote CSVs to {OUTPUT_DIR}/")


def run_ticket_batches(rules, label, workflow_type, workflow_name, subject,
                       decom_action=None):
    """Submit rules in batches. Returns UIDs Tufin rejected across all batches."""
    if not rules:
        log.info(f"{label}: nothing to do")
        return []

    n_batches = -(-len(rules) // TICKET_BATCH_SIZE)
    log.info(f"{label}: {len(rules)} rule(s) in {n_batches} batch(es)")
    all_dropped = []

    for i, batch in enumerate(chunked(rules, TICKET_BATCH_SIZE), 1):
        uids = [r.uid for r in batch]
        result = submit_ticket(uids, workflow_type, workflow_name, subject,
                               decom_action=decom_action, dry_run=DRY_RUN)
        all_dropped.extend(result.get("dropped", []))
        verb = "validated" if DRY_RUN else "created"
        if result["successful"]:
            log.info(f"  batch {i}/{n_batches}: {verb} for "
                     f"{len(result['submitted'])} rule(s)"
                     + (f", {len(result['dropped'])} dropped" if result["dropped"] else ""))
        else:
            log.error(f"  batch {i}/{n_batches}: FAILED — {result['errors']}")
    return all_dropped


# ─────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────

def main():
    log.info("recert_processor — recertify + decom disable")
    log.info(f"DRY_RUN={DRY_RUN} | run tag: {RUN_TAG!r}")
    if DRY_RUN:
        log.info("DRY RUN — tickets validated via createTicketDraft dryRun, nothing created")
    else:
        log.warning("LIVE RUN — tickets WILL be created in Tufin")

    if not preflight():
        log.error("Pre-flight failed. Nothing was submitted.")
        return

    out = Path(OUTPUT_DIR)
    if out.exists():
        for old in out.glob("*.csv"):
            old.unlink()

    sheet_rows = load_decisions(REPORT_PATH)
    if not sheet_rows:
        log.error("No decisions loaded — nothing to do.")
        return

    need_lookup = [r for r in sheet_rows if not r.get("uid")]
    if need_lookup:
        uid_by_key, map_devices = load_uid_map()
        if not uid_by_key:
            log.error("No UID mapping loaded. Without it a decision cannot be tied to one "
                      "specific rule, and matching by name alone would ticket same-named "
                      "rules on other devices. Stopping.")
            return
        resolve_uids(need_lookup, uid_by_key, map_devices, "decision")

    by_uid = {r["uid"]: r["decision"] for r in sheet_rows if r.get("uid")}
    if not by_uid:
        log.error("No decision resolved to a rule UID — nothing to do.")
        return

    rules = fetch_rules(RULE_FILTER)
    log.info(f"Fetched {len(rules)} candidate rule(s) from Tufin")
    if not rules:
        log.error("No rules returned. Check RULE_FILTER.")
        return

    for r in rules:
        r.decision = by_uid.get(r.uid, Decision.NONE)
    not_fetched = set(by_uid) - {r.uid for r in rules}
    if not_fetched:
        log.warning(f"{len(not_fetched):,} resolved UID(s) were not in the fetched set and "
                    f"will get no ticket. Widen RULE_FILTER to include them.")
    classify_hits(rules)

    recertify = [r for r in rules if r.decision is Decision.RECERTIFY]
    removes   = [r for r in rules if r.decision is Decision.REMOVE]
    assist    = [r for r in rules if r.decision is Decision.ASSIST]
    undecided = [r for r in rules if r.decision is Decision.NONE]

    log.info(f"Recertify: {len(recertify)} | Cleanup/Remove: {len(removes)} | "
             f"Need Assistance: {len(assist)} | no decision: {len(undecided)}")

    to_disable, held_back = split_for_disable(removes)

    if removes:
        recent = sum(1 for r, _ in held_back if r.hit_state is HitState.RECENT)
        never  = sum(1 for r, _ in held_back if r.hit_state is HitState.NEVER)
        log.info(f"Last-hit guard ({LAST_HIT_THRESHOLD_DAYS}d, nulls={NEVER_HIT_POLICY}): "
                 f"{len(to_disable)} to disable, {len(held_back)} held back "
                 f"({recent} hit recently, {never} no hit data)")
        if recent:
            log.warning(f"{recent} rule(s) were marked for cleanup but are STILL PASSING "
                        f"TRAFFIC. Not disabling. See held_back_from_disable.csv.")

    dropped = []
    dropped += run_ticket_batches(
        recertify, "Recertify tickets",
        RECERTIFY_WORKFLOW_TYPE, RECERTIFY_WORKFLOW_NAME, RECERTIFY_SUBJECT)

    dropped += run_ticket_batches(
        to_disable, "Disable tickets",
        DECOM_WORKFLOW_TYPE, DECOM_WORKFLOW_NAME,
        f"Disable Firewall Rules - NPS - {RUN_TAG}",
        decom_action=DECOM_ACTION_DISABLE)

    write_outputs(recertify, to_disable, held_back, assist, dropped)

    # ── REMOVE PASS — deliberately not wired ──────────────────────────────────
    # The remove ticket is the irreversible half, so it is a separate run some weeks
    # after the disable, not part of this one. Everything it needs is already confirmed:
    # same mutation, same workflow, decommissionRulesAction: REMOVE_RULES.
    #
    # Two things must be settled before it is built:
    #
    #   1. How to identify what this run disabled. RUN_TAG is in the subject of every
    #      disable ticket, so the correlation exists — but reading it back means querying
    #      SecureChange tickets, which this script has never done. The alternative is
    #      Tufin's current rule state (is the rule disabled now?), which is simpler but
    #      cannot distinguish a rule this script disabled from one disabled by hand last
    #      year. Needs the Tufin platform owner.
    #
    #   2. Whether elapsed time alone authorises removal, or a human signs off first.
    #      Needs the process owner.
    #
    # The standing requirement holds either way: re-validate the rule is STILL disabled
    # immediately before removing. Someone may have re-enabled it during the wait, and
    # that is precisely the signal the soak period exists to surface.
    # ─────────────────────────────────────────────────────────────────────────

    log.info("Done" + (" (dry run)" if DRY_RUN else ""))


if __name__ == "__main__":
    main()

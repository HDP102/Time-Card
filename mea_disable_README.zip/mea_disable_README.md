# MEA Account Disable (`mea_disable.py`)

Submits the recertification disable list to MEA (SailPoint IdentityIQ) through the MuleSoft
proxy. It is the last step of the escalation process: on the deadline, `escalation_notify.py`
writes `disable_list_<date>.csv` with the IT SME and IT SME Backup accounts still outstanding,
and this script sends that list to MEA's UDN Account Disable workflow.

The script does not disable anything itself — it asks MEA to. MEA validates the accounts,
disables them, and emails a confirmation.

---

## How it works

```
mea_disable.py ──(1) certificate-signed JWT──▶ Entra ID ──▶ bearer token
mea_disable.py ──(2) bearer token + request──▶ MuleSoft proxy (JWT validation policy)
MuleSoft ──(3) passes the request through unchanged──▶ SailPoint UDN Account Disable workflow
```

1. Read LAN IDs from the input file (`CorpID` column of the disable list, or one per line).
   IDs are upper-cased, de-duplicated and validated; any invalid ID stops the run.
2. Get an Entra ID token with the certificate (client credentials, `msal`). The thumbprint is
   read from the certificate file.
3. Send **one request with every account**:
   ```json
   {"workflowArgs": {"users": "AB12,CD34", "requestedBy": "H2PR", "certificationID": "NPS-FER-RECERT-2026"}}
   ```
4. Log the request, the response and MEA's `requestID`, and email a summary.

### MEA processing rule

| Accounts in the request | MEA does |
|---|---|
| 5 or fewer | Validates, disables, sends a completion email |
| More than 5 | Creates an approval work item per user for our approvers, disables once approved |

The launch only returns a `requestID` (`complete: false`) — the workflow runs afterwards.
Completion is confirmed by MEA's notification email and the MEA link in it, not by this script.

There is **no automatic retry**: a retry after an unclear failure could launch the workflow
twice. A failed run exits with code 1 and is logged; rerun by hand after checking MEA.

---

## Setup

```
py -m pip install msal requests cryptography
```

The certificate and private key are created once with OpenSSL (see the project notes) and
kept outside the repository. Only the public `.crt` is shared, with the Azure SSO team.
**Never commit the `.key`.**

---

## Running

By hand:
```
py mea_disable.py --input disable_list_20261207.csv --dry-run
py mea_disable.py --input disable_list_20261207.csv
```

From `escalation_notify.py` (runs automatically when the disable list is produced; never on
its `DRY_RUN`):
```python
DISABLE_HANDOFF = "command"
DISABLE_COMMAND = ["py", r"<path>\Escalation\mea_disable.py", "--input", "{file}"]
```

| Flag | Effect |
|---|---|
| `--input` | The disable list CSV, or a file with one LAN ID per line |
| `--dry-run` | Print and log the exact request; call nothing |
| `--force` | Allow a list larger than `MAX_USERS` |

Exit code `0` = submitted (or dry run); `1` = failed. `escalation_notify.py` treats a non-zero
exit as a failed run and alerts.

---

## Key settings

| Setting | Purpose |
|---|---|
| `DRY_RUN` | `True` until tested end to end. **Default.** |
| `ENVIRONMENT` | Label in logs and emails (`test` = MuleSoft Test → SailPoint QA) |
| `MULESOFT_URL` | Proxy endpoint — from the MuleSoft developer |
| `TENANT_ID`, `CLIENT_ID`, `SCOPE` | From Azure SSO after the Entra ID registration |
| `CERT_FILE`, `KEY_FILE` | Certificate and private key paths |
| `REQUESTED_BY` | LAN ID of the person submitting (MEA requirement) |
| `CERTIFICATION_ID` | Reference shown on the MEA request |
| `BATCH_SIZE` | `0` = all accounts in one request |
| `MAX_USERS` | Safety stop for an unexpectedly large list |
| `NOTIFY_TO` | Summary email recipients (engineer + team DL) |

---

## Output (`mea_output/`)

| File | What |
|---|---|
| `mea_requests.csv` | One row per request: time, environment, result, HTTP status, requestID, accounts, approval needed, errors |
| `<timestamp>_<result>.json` | Exact request and response for each call |

Contains LAN IDs — kept out of git (`mea_output/` in `.gitignore`).

---

## Environments

| | MuleSoft | SailPoint |
|---|---|---|
| Testing | Test | QA (`sailpointqaui.utility.pge.com`) |
| Production | Prod | Prod — separate certificate and Entra ID registration |

---

## Open items

- `MULESOFT_URL` (MuleSoft developer, work order 0000003454112)
- `TENANT_ID` / `CLIENT_ID` / `SCOPE` (Azure SSO intake)
- Approvers for requests over 5 users
- MEA notification emails to the team DL
- Re-enable process when a disabled SME completes recertification

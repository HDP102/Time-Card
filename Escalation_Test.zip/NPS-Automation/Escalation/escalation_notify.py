"""
escalation_notify.py - recertification reminders that escalate up the owner chain.

Each run (schedule it once a day):
  1. Loads the in-scope rules (SCOPE_GLOB in SharedData - the FER rule list).
  2. Drops every rule that has been answered: certification date on/after CAMPAIGN_START
     (or a decision in ANSWERED_VALUES, once "no longer needed" is settled).
  3. Groups what is left by owner set (same IT SME / Backup / Lead / ... = one email).
  4. Works out which LADDER stage is due today and sends it to every group that has not
     had that stage yet. A missed run does not stack mail - only the latest due stage goes.
  5. Before every email, checks the IT SME and IT SME Backup accounts are active in AD.
     Inactive ones are dropped from the email; if neither is active the IT Lead is
     addressed instead and the group is listed in no_active_sme_<date>.csv.
  6. On/after the deadline, writes disable_list_<date>.csv: the IT SME and IT SME Backup
     (active accounts only - never the IT Lead or leaders) of every group still
     outstanding, then hands it to MEA (DISABLE_HANDOFF). The script disables nothing
     itself - MEA's code does, once it is wired in. DISABLE_ONLY limits the list for tests.
  7. Saves evidence of every email (.eml + evidence_log.csv) and an outstanding snapshot.

Safety: DRY_RUN writes evidence/previews only - no mail, no state change.
        TEST_MODE sends everything to TEST_RECIPIENT, uses a separate state file.
        COMPRESSED runs one stage per day from CAMPAIGN_START (the leadership test).

Open items (plug in when decided - search for "TBD"):
  AD_SERVER / AD_BASE_DN, DISABLE_HANDOFF + DISABLE_LIST_COLUMNS (Gargi), COPY_MANAGER
  (Nitin/Megan), ANSWERED_VALUES ("no longer needed"), SCOPE_GLOB (Leonard's extract),
  OWNER_SIDES (both or destination), REPLY_TO (team DL), COPY_TO (Nitin + DL),
  RESPONSE_INSTRUCTIONS / SENDER_EMAIL, RESPONSE_SOURCE.

Run:  py escalation_notify.py
Unattended (Task Scheduler): set env vars TICKETAPI_PASSWORD (for AD) - nothing prompts
      when stdin is not a terminal; a missing password fails the run and sends an alert.
"""
import csv
import getpass
import hashlib
import json
import os
import re
import smtplib
import sys
import time
import traceback
from datetime import date, datetime, timedelta
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from html import escape
from io import BytesIO
from pathlib import Path

from openpyxl import Workbook, load_workbook

# ═══════════════════════════════ CONFIG ═══════════════════════════════

# ── Run mode ───────────────────────────────────────────────────────────
DRY_RUN        = True   # True = no mail, no state change. Previews go to evidence/dry_run/
TEST_MODE      = True   # True = every email goes to TEST_RECIPIENT only (real To/CC shown in a banner)
TEST_RECIPIENT = "h2pr@pge.com"
TEST_LIMIT     = 0   # max groups emailed per test run (0 = no cap)
COMPRESSED     = True   # True = one stage per COMPRESS_DAYS from CAMPAIGN_START, ignore the
COMPRESS_DAYS  = 1             #        day offsets. The leadership test: Swapnil ladder = ~4 days.
FORCE_STAGE    = None   # e.g. "30" = send that stage now regardless of dates (demo / evidence)
TODAY_OVERRIDE = None   # e.g. "2026-10-12" to simulate a date. None = real today.

# ── Campaign ───────────────────────────────────────────────────────────
CAMPAIGN_NAME  = "FER Firewall Rule Recertification"
CAMPAIGN_START = "2026-10-14"   # a rule is answered if certified on/after this date
DEADLINE       = "2026-12-07"  # stage days count back from here; disable list on/after it

# ── Escalation ladder (TBD - Nitin to pick) ─────────────────────────────
# days_before: days before DEADLINE the stage goes out (ignored when COMPRESSED).
# to / cc:     owner-role columns. IT SME + IT SME Backup are AD-checked before each send.
# label:      subject prefix (REMINDER / ESCALATION / FINAL NOTICE).
# disable_warning: adds the account-disable wording (IT SME + IT SME Backup only).
# cc_manager: also CC the IT SME / Backup's direct manager from AD (only if COPY_MANAGER).
# Production = "megan"; the compressed test run = "swapnil".
LADDER = "swapnil"
LADDERS = {
    "megan": [      # Megan: 60/45/30/15/7
        {"name": "60", "label": "REMINDER", "days_before": 60, "to": ["IT SME", "IT SME Backup"], "cc": ["IT Lead"]},
        {"name": "45", "label": "REMINDER", "days_before": 45, "to": ["IT SME", "IT SME Backup"], "cc": ["IT Lead"]},
        {"name": "30", "label": "ESCALATION", "days_before": 30, "to": ["IT SME", "IT SME Backup"],
         "cc": ["IT Lead", "IT Director", "Client Owner"]},
        {"name": "15", "label": "ESCALATION", "days_before": 15, "to": ["IT SME", "IT SME Backup"],
         "cc": ["IT Lead", "IT Director", "Client Owner", "IT Senior Leader"], "disable_warning": True},
        {"name": "7", "label": "FINAL NOTICE", "days_before": 7, "to": ["IT SME", "IT SME Backup"],
         "cc": ["IT Lead", "IT Director", "Client Owner", "IT Senior Leader"], "disable_warning": True,
         "cc_manager": True},
    ],
    "swapnil": [    # Swapnil demo: SME -> IT Lead -> Owner -> disable, day by day
        {"name": "SME", "label": "REMINDER", "days_before": 3, "to": ["IT SME", "IT SME Backup"], "cc": []},
        {"name": "Lead", "label": "ESCALATION", "days_before": 2, "to": ["IT SME", "IT SME Backup"], "cc": ["IT Lead"]},
        {"name": "Owner", "label": "FINAL NOTICE", "days_before": 1, "to": ["IT SME", "IT SME Backup"],
         "cc": ["IT Lead", "Client Owner", "IT Director", "IT Senior Leader"], "disable_warning": True,
         "cc_manager": True},
    ],
}

# ── Scope: which rules (TBD - Swapnil's FER list, both the Nitin and Satish sets) ──
SCOPE_GLOB     = "Sathish_Rule_report*.xlsx"   # in SharedData; every matching file is read, duplicates kept once
COL_UID        = ["Rule UID", "UID", "rule_uid", "SecureTrack Rule ID"]   # first header found wins
COL_DEVICE     = ["Device Name", "Device", "device"]
COL_RULE       = ["Rule Name", "ID on Device", "rule_name"]
COL_APP_ID     = ["Single APPID", "App-ID", "APP ID", "Application ID"]
COL_LAST_HIT   = ["Last Hit", "last_hit"]
ROLE_COLUMNS   = ["IT SME", "IT SME Backup", "IT Lead", "IT Lead Delegate",
                  "Client Owner", "IT Director", "IT Senior Leader"]

# ── AMPS owner format (Leonard's Tufin extract) ─────────────────────────
# Owners sit inside one text cell per side: "10.1.2.3 = {'APP-1234': {... 'IT SME': 'Last, First (ID)' ...}}"
# A rule can hold several apps; each app's owners get their own email for that rule.
# Files with the role columns above still work - the format is detected per file.
COL_AMPS_OWNERS     = {"source": "Source AMPS owners list", "destination": "Destination AMPS owners list"}
OWNER_SIDES         = ["source", "destination"]   # TBD - both sides, or ["destination"] only
SCOPE_OWNER_FILTER  = []        # e.g. ["S1KO"]: keep only apps where this CorpID holds any role;
                                # rules dropped by it are listed in scope_dropped_<date>.csv
COL_DISABLED        = ["Disabled"]
SKIP_DISABLED_RULES = True      # rules already disabled in Tufin are not chased

# ── Response signal ────────────────────────────────────────────────────
# "sheet": certification date column in the scope file (re-export it before each run).
# "tufin": read live from Tufin - TBD, see cert_dates_from_tufin().
RESPONSE_SOURCE   = "sheet"
COL_CERT_DATE     = ["Certification Date", "Last Certification Date", "Recertification Date"]
COL_DECISION      = ["Recertification", "Decision"]
ANSWERED_VALUES   = []         # TBD - e.g. ["No Longer Needed"] once the RE check settles it

# ── AD account check (ticketAPI has the access; server / base DN TBD) ────
# "off"  : skip the check (everyone treated as active; logged as unchecked)
# "ldap" : query AD with ticketAPI (needs: py -m pip install ldap3)
# "file" : CSV export from MEA with columns corpid,status (status: active/disabled)
AD_MODE        = "off"
AD_SERVER      = "ldaps://TBD.utility.pge.com"
AD_BASE_DN     = "DC=TBD,DC=pge,DC=com"
AD_BIND_USER   = "TBD\\ticketAPI"      # domain\user
AD_STATUS_FILE = "ad_status.csv"        # for AD_MODE = "file", in SharedData (optional "manager" column = CorpID)

# COPY_MANAGER - on stages marked cc_manager, also CC the direct manager (AD "manager"
#   attribute) of the IT SME and IT SME Backup, since the AMPS chain may not include them.
#   Needs AD_MODE "ldap" (or "file" with a manager column). TBD - Nitin / Megan.
COPY_MANAGER   = False   # ── Disable list handoff to MEA (TBD - Gargi's format) ──────────────────
DISABLE_ROLES        = ["IT SME", "IT SME Backup"]   # NEVER add IT Lead or leaders here
DISABLE_LIST_COLUMNS = ["CorpID", "Name", "Role", "AD Status", "App IDs",
                        "Outstanding Rules", "Last Reminder", "Campaign"]
DISABLE_LIST_TO      = []      # e.g. ["MEA-mailbox@pge.com"]; [] = file only, send it by hand

# DISABLE_ONLY - test safety. When set, the disable list holds ONLY these CorpIDs, whatever
#   is outstanding. A listed account that is not an SME in scope is still added (marked TEST)
#   so a designated test account can be used. [] = normal (everyone outstanding).
DISABLE_ONLY         = []

# DISABLE_HANDOFF - how the list reaches MEA (TBD - Gargi's interface):
#   "file"    : just write disable_list_<date>.csv (and email it if DISABLE_LIST_TO is set)
#   "command" : also run DISABLE_COMMAND with {file} replaced by the CSV path. Never runs on
#               DRY_RUN. Output is saved with the evidence; a non-zero exit fails the run.
DISABLE_HANDOFF      = "file"
DISABLE_COMMAND      = ["TBD_mea_disable.exe", "--input", "{file}"]
NPS_TEAM_TO          = []      # who gets the run summary / disable list notice

# ── Filters (apply in every mode) ──────────────────────────────────────
ONLY_SME     = []              # only groups whose IT SME/Backup CorpID is in this list
EXCLUDE      = []              # CorpIDs never emailed

# ── Mail ───────────────────────────────────────────────────────────────
SENDER_EMAIL = "h2pr@pge.com"
REPLY_TO     = "cybersecuritynps@pge.com"   # TBD - confirm the monitored DL; owner replies go here
COPY_TO      = []               # Bcc on every LIVE notification (e.g. Nitin, the team DL)
TEST_COPY_TO = []               # extra recipients of TEST emails besides TEST_RECIPIENT
SMTP_HOST    = "mailhost"
SMTP_PORT    = 25
ALERT_TO     = ["h2pr@pge.com"]   # job-failure alerts
SEND_DELAY   = 0.5                  # seconds between emails
MAX_ROWS_IN_BODY = 25               # rules listed in the body; the attachment has them all

RESPONSE_INSTRUCTIONS = (          # TBD - where owners recertify
    "Please review each rule below and record your decision in the recertification "
    "list. If you need help, reply to this email or join NPS office hours."
)
DISABLE_WARNING_TEXT = (
    "If these rules are not recertified by <strong>{deadline}</strong>, the IT SME and "
    "IT SME Backup accounts listed on this request will be <strong>disabled</strong>."
)
SIGNATURE = "Network Protection Services<br>Pacific Gas and Electric Company"
# ══════════════════════════════════════════════════════════════════════

SCRIPT_DIR = Path(__file__).resolve().parent
SHARED_ROOT = SCRIPT_DIR.parent
DATA_DIR = SHARED_ROOT / "SharedData"
OUT = SCRIPT_DIR / "escalation_output"
EVIDENCE = OUT / "evidence"
HEARTBEAT_DIR = SHARED_ROOT / "heartbeats"
JOB_NAME = "escalation_notify"
CORPID_RE = re.compile(r"^(.*?)\s*\(([A-Za-z0-9]{3,8})\)\s*$")

TODAY = date.fromisoformat(TODAY_OVERRIDE) if TODAY_OVERRIDE else date.today()
STAMP = datetime.now().strftime("%Y%m%d_%H%M%S")


def log(msg):
    print(f"{datetime.now():%H:%M:%S} {msg}", flush=True)


def state_path():
    return OUT / ("escalation_state_test.json" if TEST_MODE else "escalation_state.json")


# ─────────────────────────────── inputs ───────────────────────────────

def person(cell, role):
    """'Last, First (CORPID)' -> dict, or None for blank / '0' / unparsable."""
    s = str(cell or "").strip()
    if not s or s == "0":
        return None
    m = CORPID_RE.match(s)
    if not m:
        return None
    cid = m.group(2).upper()
    return {"corpid": cid, "name": m.group(1).strip(), "email": f"{cid}@pge.com", "role": role}


def find_col(header, names):
    low = [h.lower() for h in header]
    for n in names:
        if n.lower() in low:
            return low.index(n.lower())
    return None


def as_date(v):
    if v in (None, "", "0"):
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    s = str(v).strip()
    for fmt in ("%m/%d/%Y", "%m/%d/%Y %H:%M", "%m/%d/%Y %H:%M:%S", "%d-%b-%Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    try:
        return datetime.fromisoformat(s[:19].replace("T", " ")).date()
    except ValueError:
        return None


def read_rows(path):
    """Header + rows of the first sheet (xlsx) or a CSV. Skips metadata lines above the header."""
    if path.suffix.lower() == ".csv":
        with open(path, newline="", encoding="utf-8-sig") as f:
            rows = list(csv.reader(f))
    else:
        try:
            wb = load_workbook(path, read_only=True, data_only=True)
        except PermissionError:
            raise SystemExit(f"{path.name} is open in Excel - close it and run again.")
        rows = [list(r) for r in wb[wb.sheetnames[0]].iter_rows(values_only=True)]
        wb.close()
    for i, row in enumerate(rows[:20]):
        header = [str(h).strip() if h is not None else "" for h in row]
        if any(h in header for h in ROLE_COLUMNS + list(COL_AMPS_OWNERS.values())):
            return header, rows[i + 1:]
    raise SystemExit(f"{path.name}: no header row with owner columns ({ROLE_COLUMNS} or "
                     f"{list(COL_AMPS_OWNERS.values())}) in the first 20 rows")


ROLE_ALIASES = {r.lower(): r for r in ROLE_COLUMNS}
ROLE_ALIASES.update({"it sme backup": "IT SME Backup", "it sme back up": "IT SME Backup",
                     "it lead delegate": "IT Lead Delegate"})
_AMPS_ENTRY = re.compile(r"\n(?=\s*[\w.:/-]+\s*=\s*\{)")
_AMPS_APP = re.compile(r"""['"](APP-[A-Za-z0-9]+)['"]""")
_AMPS_ROLE = re.compile(r"""(['"])([^'"]+?)\1\s*:\s*(?:'([^']*?\([A-Za-z0-9]{3,8}\))'|"([^"]*?\([A-Za-z0-9]{3,8}\))")""")


def parse_amps(cell):
    """AMPS owners text -> {APP-ID: {role: person}}. 'Skip AMPS ...' / blank -> {}."""
    out = {}
    s = str(cell or "").strip()
    if not s or s.lower().startswith("skip amps"):
        return out
    for chunk in _AMPS_ENTRY.split(s):
        apps = _AMPS_APP.findall(chunk)
        if not apps:
            continue
        roles = out.setdefault(apps[0].upper(), {})
        for _q, key, v1, v2 in _AMPS_ROLE.findall(chunk):
            role = ROLE_ALIASES.get(key.strip().lower())
            if role and not roles.get(role):
                roles[role] = person(v1 or v2, role)
    return out


def truthy(v):
    return str(v).strip().lower() in ("true", "yes", "1", "y")


def load_scope():
    files = sorted(DATA_DIR.glob(SCOPE_GLOB))
    if not files:
        raise SystemExit(f"No scope files matching {SCOPE_GLOB!r} in {DATA_DIR}")
    rules, skipped_disabled = {}, 0
    for f in files:
        header, rows = read_rows(f)
        c = {k: find_col(header, v) for k, v in {
            "uid": COL_UID, "device": COL_DEVICE, "rule": COL_RULE, "app": COL_APP_ID,
            "hit": COL_LAST_HIT, "cert": COL_CERT_DATE, "dec": COL_DECISION,
            "dis": COL_DISABLED}.items()}
        roles_idx = {r: header.index(r) for r in ROLE_COLUMNS if r in header}
        amps_idx = {side: find_col(header, [col]) for side, col in COL_AMPS_OWNERS.items()
                    if side in OWNER_SIDES}
        amps_idx = {k: v for k, v in amps_idx.items() if v is not None}
        fmt = "amps" if amps_idx and not roles_idx else "roles"
        if c["uid"] is None and (c["device"] is None or c["rule"] is None):
            raise SystemExit(f"{f.name}: needs a UID column, or Device + Rule Name columns")
        if RESPONSE_SOURCE == "sheet" and c["cert"] is None:
            log(f"  WARNING {f.name}: no certification-date column {COL_CERT_DATE} - "
                f"every rule in it counts as outstanding")
        added = 0
        for row in rows:
            g = lambda k: (row[c[k]] if c[k] is not None and c[k] < len(row) else None)
            uid = str(g("uid") or "").strip()
            dev, name = str(g("device") or "").strip(), str(g("rule") or "").strip()
            key = uid or f"{dev}|{name}"
            if key in ("", "|") or key in rules:
                continue
            if SKIP_DISABLED_RULES and truthy(g("dis")):
                skipped_disabled += 1
                continue
            if fmt == "amps":
                apps = {}
                for side, i in amps_idx.items():
                    for app, ro in parse_amps(row[i] if i < len(row) else None).items():
                        merged = apps.setdefault(app, {})
                        for role, p in ro.items():
                            merged.setdefault(role, p)
            else:
                ro = {r: person(row[i] if i < len(row) else None, r) for r, i in roles_idx.items()}
                apps = {str(g("app") or "").strip(): ro}
            rules[key] = {
                "key": key, "uid": uid, "device": dev, "rule": name,
                "last_hit": str(g("hit") or "Never"),
                "cert_date": as_date(g("cert")), "decision": str(g("dec") or "").strip(),
                "source": f.name, "apps": apps,
            }
            added += 1
        log(f"  {f.name}: {added:,} rules ({fmt} owner format"
            f"{', sides: ' + '/'.join(amps_idx) if fmt == 'amps' else ''})")
    if skipped_disabled:
        log(f"  {skipped_disabled:,} rules skipped - already disabled in Tufin")
    return rules


def make_items(rules):
    """One item per (rule, owner set). Apps on a rule with identical owners merge into one item.
    Returns (items, dropped_by_SCOPE_OWNER_FILTER)."""
    items, dropped = [], []
    want = {c.upper() for c in SCOPE_OWNER_FILTER}
    for r in rules:
        apps = {a: ro for a, ro in r["apps"].items() if any(ro.values())}
        if want:
            apps = {a: ro for a, ro in apps.items()
                    if {p["corpid"] for p in ro.values() if p} & want}
            if not apps:
                dropped.append(r)
                continue
        bysig = {}
        for a, ro in sorted(apps.items()):
            bysig.setdefault(group_key({"roles": ro}), (ro, []))[1].append(a)
        if not bysig:                                   # no owners at all
            bysig[group_key({"roles": {}})] = ({}, [])
        for sig, (ro, alist) in bysig.items():
            it = dict(r)
            it.update(roles=ro, app_id=", ".join(a for a in alist if a),
                      key=f"{r['key']}|{sig}", rule_key=r["key"])
            items.append(it)
    return items, dropped


def cert_dates_from_tufin(rules):
    """TBD: fill rule['cert_date'] from Tufin (GraphQL / SecureTrack REST) once the field
    that holds the certification date is confirmed. Must set cert_date on each rule."""
    raise NotImplementedError("RESPONSE_SOURCE='tufin' is not wired yet - use 'sheet'")


def is_answered(rule, start):
    if rule["cert_date"] and rule["cert_date"] >= start:
        return True
    return bool(ANSWERED_VALUES) and rule["decision"].lower() in {v.lower() for v in ANSWERED_VALUES}


# ─────────────────────────────── AD check ───────────────────────────────

class AD:
    """active / disabled / not_found / unchecked per CorpID, cached for the run."""

    def __init__(self):
        self.cache, self.conn, self.file, self.managers = {}, None, None, {}
        if AD_MODE == "ldap":
            try:
                import ldap3
            except ImportError:
                raise SystemExit("AD_MODE='ldap' needs ldap3:  py -m pip install ldap3")
            pwd = os.environ.get("TICKETAPI_PASSWORD")
            if not pwd:
                if not sys.stdin.isatty():
                    raise RuntimeError("TICKETAPI_PASSWORD not set (unattended run cannot prompt)")
                pwd = getpass.getpass(f"AD password for {AD_BIND_USER}: ")
            self.conn = ldap3.Connection(ldap3.Server(AD_SERVER, get_info=None),
                                         user=AD_BIND_USER, password=pwd, auto_bind=True)
        elif AD_MODE == "file":
            p = DATA_DIR / AD_STATUS_FILE
            with open(p, newline="", encoding="utf-8-sig") as f:
                rows = [r for r in csv.DictReader(f) if r.get("corpid")]
            self.file = {r["corpid"].strip().upper(): r["status"].strip().lower() for r in rows}
            self.managers = {r["corpid"].strip().upper(): (r.get("manager") or "").strip().upper()
                             for r in rows}

    def status(self, corpid):
        if corpid in self.cache:
            return self.cache[corpid]
        if AD_MODE == "ldap":
            self.conn.search(AD_BASE_DN, f"(sAMAccountName={corpid})",
                             attributes=["userAccountControl"])
            if not self.conn.entries:
                s = "not_found"
            else:
                uac = int(self.conn.entries[0].userAccountControl.value or 0)
                s = "disabled" if uac & 2 else "active"
        elif AD_MODE == "file":
            s = self.file.get(corpid, "not_found")
        else:
            s = "unchecked"
        self.cache[corpid] = s
        return s

    def ok(self, corpid):
        return self.status(corpid) in ("active", "unchecked")

    def manager(self, corpid):
        """Direct manager as a person dict, or None. Cached."""
        key = ("mgr", corpid)
        if key in self.cache:
            return self.cache[key]
        mgr = None
        if AD_MODE == "ldap":
            self.conn.search(AD_BASE_DN, f"(sAMAccountName={corpid})", attributes=["manager"])
            dn = self.conn.entries[0].manager.value if self.conn.entries else None
            if dn:
                from ldap3 import BASE
                self.conn.search(dn, "(objectClass=*)", search_scope=BASE,
                                 attributes=["sAMAccountName", "displayName"])
                if self.conn.entries:
                    e = self.conn.entries[0]
                    cid = str(e.sAMAccountName.value).upper()
                    mgr = {"corpid": cid, "name": str(e.displayName.value or cid),
                           "email": f"{cid}@pge.com", "role": "Manager (AD)"}
        elif AD_MODE == "file" and self.managers.get(corpid):
            cid = self.managers[corpid]
            mgr = {"corpid": cid, "name": cid, "email": f"{cid}@pge.com", "role": "Manager (AD)"}
        self.cache[key] = mgr
        return mgr


# ─────────────────────────────── grouping ───────────────────────────────

def group_key(rule):
    """Rules with the same people in every role share one email."""
    parts = [f"{r}={(p or {}).get('corpid', '')}" for r, p in sorted(rule["roles"].items()) if p]
    return hashlib.sha1("|".join(parts).encode()).hexdigest()[:12]


def build_groups(rules):
    groups = {}
    for rule in rules:
        g = groups.setdefault(group_key(rule), {"rules": [], "roles": rule["roles"]})
        g["rules"].append(rule)
    for g in groups.values():
        g["app_ids"] = sorted({a for r in g["rules"] for a in r["app_id"].split(", ") if a})
        g["smes"] = [g["roles"].get(r) for r in DISABLE_ROLES if g["roles"].get(r)]
    return groups


def passes_filters(g):
    if ONLY_SME:
        want = {c.upper() for c in ONLY_SME}
        if not {p["corpid"] for p in g["smes"]} & want:
            return False
    return True


# ─────────────────────────────── stages ───────────────────────────────

def due_stage_index(stages):
    """Index of the latest stage due today; len(stages) = disable stage; -1 = nothing yet."""
    if FORCE_STAGE is not None:
        names = [s["name"] for s in stages]
        if str(FORCE_STAGE).lower() == "disable":
            return len(stages)
        if str(FORCE_STAGE) not in names:
            raise SystemExit(f"FORCE_STAGE {FORCE_STAGE!r} not in ladder {names}")
        return names.index(str(FORCE_STAGE))
    start, deadline = date.fromisoformat(CAMPAIGN_START), date.fromisoformat(DEADLINE)
    if COMPRESSED:
        if TODAY < start:
            return -1
        return min((TODAY - start).days // COMPRESS_DAYS, len(stages))
    if TODAY >= deadline:
        return len(stages)
    due = -1
    for i, s in enumerate(stages):
        if TODAY >= deadline - timedelta(days=s["days_before"]):
            due = i
    return due


def effective_deadline(stages):
    if COMPRESSED:
        return date.fromisoformat(CAMPAIGN_START) + timedelta(days=len(stages) * COMPRESS_DAYS)
    return date.fromisoformat(DEADLINE)


def recipients(g, stage, ad):
    """(to, cc, notes). IT SME / Backup AD-checked; inactive dropped; none left -> IT Lead."""
    to, cc, notes = [], [], []
    for role in stage["to"]:
        p = g["roles"].get(role)
        if not p:
            continue
        if role in DISABLE_ROLES and not ad.ok(p["corpid"]):
            notes.append(f"{role} {p['corpid']} {ad.status(p['corpid'])} - not emailed")
            continue
        to.append(p)
    if not [p for p in to if p["role"] in DISABLE_ROLES]:
        lead = g["roles"].get("IT Lead") or g["roles"].get("IT Lead Delegate")
        if lead and lead not in to:
            to.append(lead)
            notes.append("no active IT SME/Backup - addressed to IT Lead")
    for role in stage["cc"]:
        p = g["roles"].get(role)
        if p and p["corpid"] not in {x["corpid"] for x in to + cc}:
            cc.append(p)
    if COPY_MANAGER and stage.get("cc_manager"):
        for p in g["smes"]:
            m = ad.manager(p["corpid"])
            if m and m["corpid"] not in {x["corpid"] for x in to + cc}:
                cc.append(m)
                notes.append(f"manager of {p['corpid']} ({m['corpid']}) copied from AD")
    excl = {c.upper() for c in EXCLUDE}
    return ([p for p in to if p["corpid"] not in excl],
            [p for p in cc if p["corpid"] not in excl], notes)


# ─────────────────────────────── email ───────────────────────────────

def first_name(p):
    parts = p["name"].split(",")
    return (parts[1].strip().split() or [parts[0]])[0] if len(parts) > 1 else parts[0].strip()


def subject_for(stage, n_rules):
    s = (f"{stage.get('label', 'REMINDER')}: Firewall rule recertification - "
         f"{n_rules} rule{'s' if n_rules != 1 else ''} outstanding")
    return ("[TEST] " if TEST_MODE else "") + s


def body_for(g, stage, to, cc, deadline, notes):
    rows = "".join(
        f"<tr><td>{escape(r['device'])}</td><td>{escape(r['rule'])}</td>"
        f"<td>{escape(r['app_id'])}</td><td>{escape(r['last_hit'])}</td></tr>"
        for r in g["rules"][:MAX_ROWS_IN_BODY])
    more = (f"<p><em>Showing {MAX_ROWS_IN_BODY} of {len(g['rules'])} - the attachment lists all.</em></p>"
            if len(g["rules"]) > MAX_ROWS_IN_BODY else "")
    owners = "".join(f"<li>{escape(role)}: {escape(p['name'])} ({p['corpid']})</li>"
                     for role, p in g["roles"].items() if p)
    dl = deadline.strftime("%m/%d/%Y")
    warn = (f"<p style='color:#a00'>{DISABLE_WARNING_TEXT.format(deadline=dl)}</p>"
            if stage.get("disable_warning") else "")
    test = ""
    if TEST_MODE:
        # A table with bgcolor - Outlook desktop drops styled <div> boxes
        test = (f"<table width='100%' cellpadding='8' cellspacing='0' bgcolor='#FFF1DC' "
                f"style='border:2px solid #CC6600;margin-bottom:12px'><tr><td "
                f"style='font-family:Arial,sans-serif;font-size:13px;color:#333'>"
                f"<b>TEST - stage {escape(stage['name'])}. Real recipients:</b><br>"
                f"To: {escape(', '.join(p['email'] for p in to))}<br>"
                f"Cc: {escape(', '.join(p['email'] for p in cc)) or '-'}<br>"
                f"{'<br>'.join(escape(n) for n in notes)}</td></tr></table>")
    greet = ", ".join(first_name(p) for p in to) or "team"
    return f"""<html><body style='font-family:Arial,sans-serif;color:#333;line-height:1.45'>
{test}<p>Hi {escape(greet)},</p>
<p>The following <strong>{len(g['rules'])}</strong> firewall rule(s) for application(s)
<strong>{escape(', '.join(g['app_ids']) or 'n/a')}</strong> are still awaiting recertification
for <strong>{escape(CAMPAIGN_NAME)}</strong>. All rules must be recertified by
<strong>{deadline:%m/%d/%Y}</strong>.</p>
{warn}<p>{RESPONSE_INSTRUCTIONS}</p>
<table border='1' cellpadding='4' cellspacing='0' style='border-collapse:collapse;font-size:12px'>
<tr style='background:#003366;color:#fff'><th>Device</th><th>Rule</th><th>App ID</th><th>Last Hit</th></tr>
{rows}</table>{more}
<p>Owners on record:</p><ul>{owners}</ul>
<p>Thank you,<br>{SIGNATURE}</p>
<p style='font-size:11px;color:#888'>Automated notice, stage {escape(stage['name'])}.</p>
</body></html>"""


def rules_xlsx(rules):
    wb = Workbook()
    ws = wb.active
    ws.title = "Outstanding"
    ws.append(["Device", "Rule Name", "Rule UID", "App ID", "Last Hit", "Certification Date"])
    for r in rules:
        ws.append([r["device"], r["rule"], r["uid"], r["app_id"], r["last_hit"],
                   r["cert_date"].isoformat() if r["cert_date"] else ""])
    buf = BytesIO()
    wb.save(buf)
    return buf.getvalue()


def make_msg(subject, html, to, cc, attachments=()):
    msg = MIMEMultipart("mixed")
    msg["Subject"], msg["From"] = subject, SENDER_EMAIL
    msg["To"], msg["Cc"] = ", ".join(to), ", ".join(cc)
    if REPLY_TO:
        msg["Reply-To"] = REPLY_TO
    msg.attach(MIMEText(html, "html"))
    for name, data in attachments:
        part = MIMEApplication(data, Name=name)
        part["Content-Disposition"] = f'attachment; filename="{name}"'
        msg.attach(part)
    return msg


class Mailer:
    def __init__(self):
        self.smtp = None

    def send(self, msg, rcpts):
        if DRY_RUN:
            return
        if self.smtp is None:
            self.smtp = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=60)
        self.smtp.sendmail(SENDER_EMAIL, rcpts, msg.as_string())
        time.sleep(SEND_DELAY)

    def close(self):
        if self.smtp:
            try:
                self.smtp.quit()
            except Exception:
                pass


def save_evidence(msg, label):
    d = EVIDENCE / ("dry_run" if DRY_RUN else ("test" if TEST_MODE else "live")) / TODAY.isoformat()
    d.mkdir(parents=True, exist_ok=True)
    p = d / f"{STAMP}_{re.sub(r'[^A-Za-z0-9_-]', '_', label)}.eml"
    p.write_bytes(msg.as_bytes())
    return p


EVIDENCE_COLS = ["timestamp", "run_date", "mode", "stage", "group", "to", "cc", "actual_rcpts",
                 "rules", "app_ids", "ad_notes", "result", "eml"]


def evidence_row(row):
    p = OUT / "evidence_log.csv"
    new = not p.exists()
    with open(p, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, EVIDENCE_COLS)
        if new:
            w.writeheader()
        w.writerow(row)


def write_csv(name, header, rows):
    p = OUT / name
    with open(p, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)
    return p


# ─────────────────────────────── main ───────────────────────────────

def heartbeat(status, message=""):
    if DRY_RUN:                      # rehearsals do not count as the scheduled job running
        return
    HEARTBEAT_DIR.mkdir(parents=True, exist_ok=True)
    (HEARTBEAT_DIR / f"{JOB_NAME}.json").write_text(json.dumps({
        "job": JOB_NAME, "status": status, "time": datetime.now().isoformat(timespec="seconds"),
        "dry_run": DRY_RUN, "test_mode": TEST_MODE, "message": message[:2000]}, indent=2))


def send_alert(subject, text):
    if not ALERT_TO or DRY_RUN:
        log(f"(alert not sent - {'DRY_RUN' if DRY_RUN else 'no ALERT_TO'}): {subject}")
        return
    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=60) as s:
            m = make_msg(subject, f"<pre>{escape(text)}</pre>", ALERT_TO, [])
            s.sendmail(SENDER_EMAIL, ALERT_TO, m.as_string())
    except Exception as e:
        log(f"Could not send alert: {e}")


def mea_handoff(csv_path):
    """Pass the disable list to MEA. 'file' = nothing more to do; 'command' = run their tool."""
    if DISABLE_HANDOFF == "file":
        return "file written"
    if DISABLE_HANDOFF != "command":
        raise SystemExit(f"DISABLE_HANDOFF must be 'file' or 'command', not {DISABLE_HANDOFF!r}")
    cmd = [str(a).replace("{file}", str(csv_path)) for a in DISABLE_COMMAND]
    if DRY_RUN:
        log(f"  [DRY_RUN] would run: {' '.join(cmd)}")
        return "dry run - command not run"
    import subprocess
    res = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
    out = EVIDENCE / ("test" if TEST_MODE else "live") / TODAY.isoformat()
    out.mkdir(parents=True, exist_ok=True)
    (out / f"{STAMP}_mea_handoff.txt").write_text(
        f"command: {cmd}\nexit: {res.returncode}\n--- stdout\n{res.stdout}\n--- stderr\n{res.stderr}")
    if res.returncode != 0:
        raise RuntimeError(f"MEA handoff failed (exit {res.returncode}): {res.stderr[-500:]}")
    return f"command ran (exit 0)"


def run():
    OUT.mkdir(parents=True, exist_ok=True)
    stages = LADDERS[LADDER]
    mode = "DRY_RUN" if DRY_RUN else ("TEST" if TEST_MODE else "LIVE")
    log(f"{CAMPAIGN_NAME} | ladder={LADDER} | {mode} | compressed={COMPRESSED} | today={TODAY}")

    log("Loading scope...")
    rules = load_scope()
    if RESPONSE_SOURCE == "tufin":
        cert_dates_from_tufin(rules)
    start = date.fromisoformat(CAMPAIGN_START)
    outstanding = [r for r in rules.values() if not is_answered(r, start)]
    log(f"  {len(rules):,} in scope, {len(rules) - len(outstanding):,} answered, "
        f"{len(outstanding):,} outstanding")
    items, dropped = make_items(outstanding)
    if SCOPE_OWNER_FILTER:
        log(f"  SCOPE_OWNER_FILTER {SCOPE_OWNER_FILTER}: {len(dropped):,} outstanding rules have none "
            f"of them as an owner - dropped (scope_dropped_{TODAY:%Y%m%d}.csv)")
        write_csv(f"scope_dropped_{TODAY:%Y%m%d}.csv", ["Rule UID", "Device", "Rule", "Apps found", "Source"],
                  [[r["uid"], r["device"], r["rule"], ", ".join(a for a in r["apps"] if a), r["source"]]
                   for r in dropped])

    idx = due_stage_index(stages)
    deadline = effective_deadline(stages)
    stage_name = "none" if idx < 0 else ("disable" if idx >= len(stages) else stages[idx]["name"])
    log(f"Due stage: {stage_name}  (deadline {deadline})")

    state = json.loads(state_path().read_text()) if state_path().exists() else {}
    groups = build_groups(items)
    log(f"  {len(items):,} rule/owner pairs in {len(groups):,} owner groups")
    groups = {k: g for k, g in groups.items() if passes_filters(g)}
    ad = AD()

    write_csv(f"outstanding_{TODAY:%Y%m%d}.csv",
              ["Rule UID", "Device", "Rule", "App ID", "IT SME", "IT SME Backup", "IT Lead",
               "Group", "Last Stage Sent", "Source"],
              [[r["uid"], r["device"], r["rule"], r["app_id"],
                *[(r["roles"].get(x) or {}).get("corpid", "") for x in ("IT SME", "IT SME Backup", "IT Lead")],
                gk, state.get(r["key"], {}).get("stage", ""), r["source"]]
               for gk, g in groups.items() for r in g["rules"]])

    sent = skipped = failed = 0
    no_sme, disable_rows = [], []
    mailer = Mailer()
    try:
        if 0 <= idx < len(stages):
            stage = stages[idx]
            for gk, g in sorted(groups.items(), key=lambda kv: -len(kv[1]["rules"])):
                if TEST_MODE and TEST_LIMIT and sent >= TEST_LIMIT:
                    break
                if FORCE_STAGE is None and all(state.get(r["key"], {}).get("idx", -1) >= idx
                                               for r in g["rules"]):
                    skipped += 1
                    continue
                to, cc, notes = recipients(g, stage, ad)
                if not to:
                    no_sme.append([gk, ", ".join(g["app_ids"]), len(g["rules"]), "; ".join(notes)
                                   or "no recipients in role columns"])
                    continue
                if any("IT Lead" in n for n in notes):
                    no_sme.append([gk, ", ".join(g["app_ids"]), len(g["rules"]), "; ".join(notes)])
                subject = subject_for(stage, len(g["rules"]))
                real_to, real_cc = [p["email"] for p in to], [p["email"] for p in cc]
                rcpt_to, rcpt_cc = ([TEST_RECIPIENT], []) if TEST_MODE else (real_to, real_cc)
                bcc = list(TEST_COPY_TO if TEST_MODE else COPY_TO)
                msg = make_msg(subject, body_for(g, stage, to, cc, deadline, notes), rcpt_to, rcpt_cc,
                               [(f"Outstanding_Rules_{stage['name']}_{gk}.xlsx", rules_xlsx(g["rules"]))])
                eml = save_evidence(msg, f"{stage['name']}_{gk}")
                try:
                    mailer.send(msg, rcpt_to + rcpt_cc + bcc)
                    result = "dry_run" if DRY_RUN else "sent"
                    sent += 1
                    if not DRY_RUN:
                        now = datetime.now().isoformat(timespec="seconds")
                        for r in g["rules"]:
                            state[r["key"]] = {"idx": idx, "stage": stage["name"], "time": now}
                except Exception as e:
                    result, failed = f"FAILED: {e}", failed + 1
                    log(f"  send failed for group {gk}: {e}")
                evidence_row({"timestamp": datetime.now().isoformat(timespec="seconds"),
                              "run_date": TODAY.isoformat(), "mode": mode, "stage": stage["name"],
                              "group": gk, "to": "; ".join(real_to), "cc": "; ".join(real_cc),
                              "actual_rcpts": "; ".join(rcpt_to + rcpt_cc + [f"bcc:{b}" for b in bcc]), "rules": len(g["rules"]),
                              "app_ids": ", ".join(g["app_ids"]), "ad_notes": "; ".join(notes),
                              "result": result, "eml": eml.name})
                if not DRY_RUN:     # save as we go - a crash mid-run never re-sends
                    state_path().write_text(json.dumps(state, indent=1))

        elif idx >= len(stages) and state.get("__disable_list__") and FORCE_STAGE is None:
            log(f"Disable list already produced {state['__disable_list__']} - not repeated. "
                f"Set FORCE_STAGE = 'disable' to regenerate.")
        elif idx >= len(stages):
            last = {r["key"]: state.get(r["key"], {}).get("time", "") for g in groups.values() for r in g["rules"]}
            seen = set()
            for gk, g in groups.items():
                for p in g["smes"]:
                    st = ad.status(p["corpid"])
                    if st not in ("active", "unchecked") or (p["corpid"], gk) in seen:
                        continue
                    seen.add((p["corpid"], gk))
                    disable_rows.append([p["corpid"], p["name"], p["role"], st, ", ".join(g["app_ids"]),
                                         len(g["rules"]), max(last[r["key"]] for r in g["rules"]),
                                         CAMPAIGN_NAME])
            if DISABLE_ONLY:
                only = {c.strip().upper() for c in DISABLE_ONLY}
                disable_rows = [row for row in disable_rows if row[0] in only]
                for cid in sorted(only - {row[0] for row in disable_rows}):
                    log(f"  DISABLE_ONLY {cid}: not an outstanding SME in scope - added as TEST")
                    disable_rows.append([cid, "", "TEST", ad.status(cid), "", 0, "", CAMPAIGN_NAME])
                log(f"  DISABLE_ONLY active - list limited to {sorted(only)}")
            if disable_rows:
                p = write_csv(f"disable_list_{TODAY:%Y%m%d}.csv", DISABLE_LIST_COLUMNS, disable_rows)
                log(f"Disable list: {len(disable_rows)} account(s) -> {p.name}  (for MEA - nothing disabled here)")
                to = DISABLE_LIST_TO + NPS_TEAM_TO
                if to:
                    rcpt = [TEST_RECIPIENT] + list(TEST_COPY_TO) if TEST_MODE else to
                    msg = make_msg(("[TEST] " if TEST_MODE else "") +
                                   f"{CAMPAIGN_NAME}: accounts for disable review ({len(disable_rows)})",
                                   f"<p>Attached: IT SME / IT SME Backup accounts whose rules were not "
                                   f"recertified by {deadline:%m/%d/%Y}. Intended to: {escape(', '.join(to))}</p>",
                                   rcpt, [], [(p.name, p.read_bytes())])
                    save_evidence(msg, "disable_list")
                    mailer.send(msg, rcpt)
                log(f"  MEA handoff ({DISABLE_HANDOFF}): {mea_handoff(p)}")
                if not DRY_RUN:
                    state["__disable_list__"] = f"{p.name} at {datetime.now():%Y-%m-%d %H:%M}"
                    state_path().write_text(json.dumps(state, indent=1))
            else:
                log("Disable stage: nothing outstanding - no disable list.")
    finally:
        mailer.close()

    if no_sme:
        write_csv(f"no_active_sme_{TODAY:%Y%m%d}.csv", ["Group", "App IDs", "Rules", "Notes"], no_sme)

    summary = (f"stage={stage_name} in_scope={len(rules)} outstanding={len(outstanding)} "
               f"groups={len(groups)} sent={sent} already_had_stage={skipped} failed={failed} "
               f"no_active_sme={len(no_sme)} disable_list={len(disable_rows)}")
    log(summary)
    if failed:
        raise RuntimeError(f"{failed} email(s) failed - see evidence_log.csv. {summary}")
    return summary


def main():
    try:
        summary = run()
        heartbeat("ok", summary)
    except SystemExit as e:          # config / input problem - still a failed job
        heartbeat("failed", str(e))
        send_alert(f"FAILED: {JOB_NAME}", str(e))
        raise
    except Exception:
        tb = traceback.format_exc()
        log(tb)
        heartbeat("failed", tb)
        send_alert(f"FAILED: {JOB_NAME}", tb)
        sys.exit(1)


if __name__ == "__main__":
    main()

"""
job_watchdog.py - hourly health check; emails ALERT_TO when something breaks.

Checks
  1. SecureTrack GraphQL  - Keycloak login + a trivial query (catches outages, upgrades,
                            expired ticketAPI password).
  2. SecureChange REST    - authenticated GET (catches the same on the workflow side).
  3. Job heartbeats       - every job in JOBS writes SharedRoot/heartbeats/<job>.json at the
                            end of each run. Alert if its last run failed, or it has not
                            run within max_age_hours (job not scheduled / machine off).

Alerting
  First failure -> alert. Still failing -> re-alert every REALERT_HOURS (not every hour).
  Back to healthy -> one RECOVERED email. State in heartbeats/watchdog_state.json.

Schedule: Windows Task Scheduler, every hour.  Run: py job_watchdog.py
Unattended runs read SECURETRACK_USER / SECURETRACK_PASSWORD (ticketAPI) from env vars.
"""
import json
import os
import smtplib
import sys
import traceback
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from html import escape
from pathlib import Path

import requests
import urllib3

urllib3.disable_warnings()

# ═══════════════════════════════ CONFIG ═══════════════════════════════
TUFIN_HOST      = "keeppgesecure.utility.pge.com"     # prod
CHECK_TUFIN     = True
SC_HEALTH_PATH  = "/securechangeworkflow/api/securechange/workflows/active_workflows"
VERIFY_TLS      = False
TIMEOUT         = 60

# job name -> hours allowed since its last run (daily job: 26 gives a 2-hour cushion)
JOBS = {
    "escalation_notify": 26,
}

ALERT_TO        = ["h2pr@pge.com"]
SENDER_EMAIL    = "h2pr@pge.com"
SMTP_HOST       = "mailhost"
SMTP_PORT       = 25
REALERT_HOURS   = 4
DRY_RUN         = False          # True = print alerts instead of emailing
# ══════════════════════════════════════════════════════════════════════

SCRIPT_DIR = Path(__file__).resolve().parent
HEARTBEAT_DIR = SCRIPT_DIR.parent / "heartbeats"
STATE = HEARTBEAT_DIR / "watchdog_state.json"


def log(msg):
    print(f"{datetime.now():%H:%M:%S} {msg}", flush=True)


def creds():
    u, p = os.environ.get("SECURETRACK_USER"), os.environ.get("SECURETRACK_PASSWORD")
    if not (u and p):
        raise RuntimeError("SECURETRACK_USER / SECURETRACK_PASSWORD env vars not set")
    return u, p


def check_securetrack():
    u, p = creds()
    tok = requests.post(
        f"https://{TUFIN_HOST}/auth/realms/tufin-realm/protocol/openid-connect/token",
        data={"grant_type": "password", "client_id": "admin-cli", "username": u, "password": p},
        verify=VERIFY_TLS, timeout=TIMEOUT)
    if tok.status_code != 200:
        raise RuntimeError(f"Keycloak login {tok.status_code}: {tok.text[:300]}")
    r = requests.post(f"https://{TUFIN_HOST}/v2/api/sync/graphql",
                      json={"query": "{__typename}"},
                      headers={"Authorization": f"Bearer {tok.json()['access_token']}"},
                      verify=VERIFY_TLS, timeout=TIMEOUT)
    if r.status_code != 200 or "errors" in r.text[:2000]:
        raise RuntimeError(f"GraphQL {r.status_code}: {r.text[:300]}")
    return "login + query OK"


def check_securechange():
    r = requests.get(f"https://{TUFIN_HOST}{SC_HEALTH_PATH}", auth=creds(),
                     headers={"Accept": "application/json"}, verify=VERIFY_TLS, timeout=TIMEOUT)
    if r.status_code != 200:
        raise RuntimeError(f"GET {SC_HEALTH_PATH} -> {r.status_code}: {r.text[:300]}")
    return "REST OK"


def check_job(name, max_age):
    p = HEARTBEAT_DIR / f"{name}.json"
    if not p.exists():
        raise RuntimeError(f"no heartbeat file ({p.name}) - job has never run here")
    hb = json.loads(p.read_text())
    ran = datetime.fromisoformat(hb["time"])
    if hb.get("status") != "ok":
        raise RuntimeError(f"last run {hb['time']} FAILED:\n{hb.get('message', '')}")
    if datetime.now() - ran > timedelta(hours=max_age):
        raise RuntimeError(f"last run {hb['time']} - older than {max_age}h (not scheduled? machine off?)")
    return f"ok at {hb['time']}"


def send(subject, lines):
    body = "<br>".join(escape(x).replace("\n", "<br>") for x in lines)
    if DRY_RUN or not ALERT_TO:
        log(f"[alert not sent] {subject}\n  " + "\n  ".join(lines))
        return
    m = MIMEText(f"<html><body style='font-family:Arial'>{body}</body></html>", "html")
    m["Subject"], m["From"], m["To"] = subject, SENDER_EMAIL, ", ".join(ALERT_TO)
    with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=60) as s:
        s.sendmail(SENDER_EMAIL, ALERT_TO, m.as_string())


def main():
    HEARTBEAT_DIR.mkdir(parents=True, exist_ok=True)
    checks = {}
    if CHECK_TUFIN:
        checks["Tufin SecureTrack"] = check_securetrack
        checks["Tufin SecureChange"] = check_securechange
    for job, hrs in JOBS.items():
        checks[f"Job {job}"] = (lambda j=job, h=hrs: check_job(j, h))

    state = json.loads(STATE.read_text()) if STATE.exists() else {}
    now = datetime.now()
    alerts, recovered = [], []
    for name, fn in checks.items():
        try:
            log(f"{name}: {fn()}")
            if name in state:
                recovered.append(f"{name}: healthy again (failing since {state[name]['since']})")
                del state[name]
        except Exception as e:
            msg = str(e) or traceback.format_exc()
            log(f"{name}: FAIL - {msg.splitlines()[0]}")
            s = state.get(name)
            due = s is None or now - datetime.fromisoformat(s["last_alert"]) >= timedelta(hours=REALERT_HOURS)
            if due:
                since = s["since"] if s else now.isoformat(timespec="seconds")
                alerts.append(f"{name} (failing since {since}):\n{msg}")
                state[name] = {"since": since, "last_alert": now.isoformat(timespec="seconds")}

    if alerts:
        send(f"ALERT: {len(alerts)} NPS automation check(s) failing", alerts)
    if recovered:
        send("RECOVERED: NPS automation checks", recovered)
    STATE.write_text(json.dumps(state, indent=1))
    log(f"{len(checks)} checks, {len(state)} failing, {len(alerts)} alert(s) sent, "
        f"{len(recovered)} recovered")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        tb = traceback.format_exc()
        log(tb)
        try:
            send("ALERT: job_watchdog itself failed", [tb])
        except Exception:
            pass
        sys.exit(1)

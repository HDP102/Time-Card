NPS Automation — Firewall Rule Recertification
==============================================

Folder layout (keep this structure intact — the scripts rely on it):

  NPS-Automation/
  ├── responses/            Shared. Returned spreadsheets from rule owners.
  ├── Notify/               Notification tool (LIVE).
  │   ├── notify_rule_owners.py
  │   ├── README.md         How to run notifications + answers to common questions.
  │   └── logs/             Created on first real send. One running log.
  └── RecertProcessor/      Response-processing tool (SCAFFOLD — not yet runnable).
      ├── recert_processor.py
      └── README.md         How the pipeline works + current blockers.

Both scripts find the shared responses/ folder relative to their own location,
so the whole NPS-Automation folder can live anywhere in OneDrive and still work
on any machine.

Start with Notify/README.md — that's the tool in active use.

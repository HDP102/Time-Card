"""
verify_uid.py - read-only. Looks up the sample ticket's rule in GraphQL and checks whether
the GraphQL `id` decodes to the GUID `uid` SecureChange REST uses. Also prints the device
id so we can compare it to management_id (7081 in the sample ticket).
Run from RecertProcessor/:   py verify_uid.py
"""
import base64
import uuid

import recert_processor as r

RULE_NAME = "ff-mdms-Rule 125"
TARGET = uuid.UUID("8487FFF8-69B1-F0D7-D36B-F77CDC852B11")   # uid from ticket 139744

QUERY = """query($f:String){ rules(filter:$f){ count values(first:20){
  id idOnDevice name device{ id name } policy{ id name } } } }"""


def decode(i):
    raw = base64.urlsafe_b64decode(i + "=" * (-len(i) % 4))
    if len(raw) != 16:
        return None, None
    return uuid.UUID(bytes=raw), uuid.UUID(bytes_le=raw)


for f in (f"name = '{RULE_NAME}'", f"name contains '{RULE_NAME}'"):
    try:
        data = r._graphql(QUERY, {"f": f})["data"]["rules"]
    except Exception as e:
        print(f"filter [{f}] -> {e}")
        continue
    print(f"filter [{f}] -> {data['count']} rule(s)")
    for v in data["values"]:
        straight, mixed = decode(v["id"])
        print(f"\n  id:          {v['id']}")
        print(f"  idOnDevice:  {v['idOnDevice']}   name: {v['name']}")
        print(f"  device:      id={v['device']['id']}  name={v['device']['name']}")
        print(f"  policy:      id={(v.get('policy') or {}).get('id')}  "
              f"name={(v.get('policy') or {}).get('name')}")
        print(f"  decoded:     straight={straight}  ms={mixed}")
        if TARGET in (straight, mixed):
            print(f"  >>> MATCH ({'straight' if TARGET == straight else 'ms-mixed'} byte order)")
    if data["count"]:
        break

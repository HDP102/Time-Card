"""
field_shape.py - reads recert_output/sample_<id>.json (from get_sc_ticket.py) and prints
the SHAPE of the Recertification Field in each step: keys, scalar values, first rule only,
bulky network/service objects collapsed. Offline, no login.

Run from RecertProcessor/:   py field_shape.py 139744
"""
import json
import sys
from pathlib import Path

import recert_processor as r

COLLAPSE = {"sourceNetworks", "destinationNetworks", "destNetworks", "services",
            "destinationServices", "applications", "users", "source_networks",
            "destination_networks", "install_ons", "track"}


def L(x):
    return x if isinstance(x, list) else [x]


def walk(obj, indent=0, key=""):
    pad = "  " * indent
    if isinstance(obj, dict):
        if key in COLLAPSE:
            print(f"{pad}{key}: {{...{len(obj)} keys, collapsed}}")
            return
        print(f"{pad}{key + ': ' if key else ''}{{")
        for k, v in obj.items():
            walk(v, indent + 1, k)
        print(f"{pad}}}")
    elif isinstance(obj, list):
        if key in COLLAPSE:
            print(f"{pad}{key}: [...{len(obj)} items, collapsed]")
            return
        print(f"{pad}{key}: [ {len(obj)} item(s), showing first ]")
        if obj:
            walk(obj[0], indent + 1)
    else:
        v = str(obj)
        print(f"{pad}{key}: {v[:70]}{'...' if len(v) > 70 else ''}")


tid = sys.argv[1] if len(sys.argv) > 1 else "139744"
t = json.loads((Path(r.OUTPUT_DIR) / f"sample_{tid}.json").read_text(encoding="utf-8"))["ticket"]

for step in L(t["steps"]["step"])[:2]:
    field = L(L(step["tasks"]["task"])[0]["fields"]["field"])[0]
    print(f"\n==================== {step['name']} ====================")
    walk(field)

print("\n==================== comments / completion_details ====================")
walk(t.get("comments"), key="comments")
walk(t.get("completion_details"), key="completion_details")

"""
tag_app_ids.py
==============
Workstream 2, Task 1 — Tag AMPS/App-IDs into the rule Description field  (SCAFFOLD)
PG&E | NPS Automation

STATUS: structural scaffold. The pipeline, batching, dry-run, and the app-ID -> rule
mapping logic are real and tested. Every call that touches Tufin (the GraphQL read and
the Description-field write) is a STUB marked with TODO — wire these up once:
  - Tufin access is provisioned (gated on PRA + NERC training)
  - The read query + auth are confirmed in Postman against the LAB VIP first
  - The exact "write Description" mutation is confirmed against a known-good example
    (the tufin console showed the createTicketDraft mutation and the update_metadata
    REST endpoint, but the specific set-Description mutation is NOT yet confirmed —
    see _write_description below and DO NOT assume the shape until verified)

WHAT THIS DOES:
  Writes the AMPS / application ID into each firewall rule's Description metadata field
  (Tufin: DOCUMENTATION -> ADDITIONAL INFORMATION -> Description). This makes the app ID
  a queryable attribute on the rule, which everything downstream (recert, reporting)
  relies on. This is the approach the review meetings converged on — the Description
  field, NOT Panorama tags (tags overload the firewalls).

  1. Pull rules from SecureTrack via GraphQL (paginated), each with its UID and
     current Description.
  2. Resolve each rule to its app ID(s) — from a provided mapping (app-ID-per-rule),
     or from data already present on the rule.
  3. Build the new Description text (add "app_id: APP-XXXX", preserving anything already
     there; skip rules that already carry the tag).
  4. Write it back per rule via a GraphQL mutation keyed on the rule UID.
  5. Batch and log everything. Nothing is written while DRY_RUN is on or stubs are in place.

Rules are addressed by UID (e.g. "eKjsG1k6-pNIOx289Tocsg=="), taken from the read query.
"""

import csv
import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────

DRY_RUN              = True          # True = log intended writes, change nothing

# SecureTrack GraphQL — verify in Postman (lab) before trusting
SECURETRACK_GRAPHQL  = "<SECURETRACK_GRAPHQL_URL>"   # TODO: lab VIP first
GRAPHQL_PAGE_SIZE    = 100                            # results paginate 100 at a time
GRAPHQL_MAX_PAGES    = 500                            # safety cap; count tells real total

# Which rules to pull. Narrow this to the set you're tagging (a device group, a filter).
# The read query's filter syntax matches the Rule Viewer (e.g. "idOnDevice contains 'ADMS'").
RULE_FILTER          = "certificationStatus not exists"

# How app IDs are supplied per rule:
#   "mapping" — read a CSV that maps a rule identifier to its app ID(s). This is the
#               usual case: the app-ID-per-rule correlation already exists (the
#               server-to-App-ID correlation module produces it).
#   "onrule"  — the rule already carries the app ID somewhere the read query returns,
#               and this script just normalises it into the Description.
APPID_SOURCE         = "mapping"
APPID_MAP_CSV        = "rule_appid_map.csv"   # columns: rule_uid (or id_on_device), app_id

# The line written into the Description. Kept as a labelled line so it's easy to find
# and to parse back out later. Matches the convention the recert processor reads.
DESC_APPID_PREFIX    = "app_id:"

# If a rule already has a Description, how to combine:
#   "append"  — keep existing text, add the app_id line if not already present
#   "replace" — overwrite the Description with just the app_id line (destructive)
DESC_WRITE_MODE      = "append"

# Batch size for write operations (kept modest; writes are per-rule mutations)
WRITE_BATCH_SIZE     = 100

OUTPUT_DIR           = "tag_output"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("tag_app_ids")


# ─────────────────────────────────────────────
# Data model
# ─────────────────────────────────────────────

@dataclass
class Rule:
    uid: str
    name: str = ""
    id_on_device: str = ""
    description: str = ""
    app_ids: list = field(default_factory=list)


@dataclass
class PlannedWrite:
    uid: str
    id_on_device: str
    old_description: str
    new_description: str
    app_ids: list
    reason: str = ""          # why this write (or why skipped)
    skip: bool = False


# ─────────────────────────────────────────────
# STUBS — external calls (wire up when access + shapes are confirmed)
# ─────────────────────────────────────────────

def graphql_query(query: str, variables: dict) -> dict:
    """
    STUB. Run a GraphQL read against SecureTrack and return parsed JSON.

    TODO when SECURETRACK_GRAPHQL + auth are known:
      - POST {query, variables} with the session/token header
      - confirmed shape (from the Tufin console): rules { count values(first,offset)
        { id name idOnDevice description ... } }
      - verify in Postman against the LAB VIP first
    """
    raise NotImplementedError("graphql_query: connect to SecureTrack GraphQL (see TODO)")


def _write_description(uid: str, new_description: str) -> bool:
    """
    STUB. Write new_description into one rule's Description field, keyed on UID.

    ⚠️ The exact mutation for setting the Description is NOT yet confirmed. The Tufin
    console showed the createTicketDraft mutation and an update_metadata REST endpoint,
    but not a verified set-Description mutation. DO NOT assume the shape below is correct
    — confirm it against a known-good example before enabling.

    Two likely paths, both to be verified:
      A) GraphQL mutation, e.g.
         mutation SetDesc($uid: ID!, $desc: String!) {
           ruleOperations { updateDocumentation(input: {
             ruleUid: $uid, description: $desc }) { resultStatus { successful errors {
             errorCode errorMessage }}}}}
      B) The SecureChange REST endpoint
         PUT .../rule_recertification/update_metadata  (per-ticket/per-task; 403 without
         the right permission)

    TODO: pick the confirmed path, send it, return True on success / False on failure.
    """
    raise NotImplementedError("_write_description: confirmed set-Description mutation needed (see TODO)")


# ─────────────────────────────────────────────
# Read (real pagination; depends only on the read stub)
# ─────────────────────────────────────────────

_RULE_QUERY = """
query Rules($filter: String!, $first: Int!, $offset: Int!) {
  rules(filter: $filter) {
    count
    values(first: $first, offset: $offset) {
      id
      name
      idOnDevice
      description
    }
  }
}
"""  # Shape per the Tufin console read query. `id` here is the rule UID used for writes.


def fetch_rules(rule_filter: str) -> list:
    rules, offset, total = [], 0, None
    for _ in range(GRAPHQL_MAX_PAGES):
        variables = {"filter": rule_filter, "first": GRAPHQL_PAGE_SIZE, "offset": offset}
        data = graphql_query(_RULE_QUERY, variables)
        block = data["data"]["rules"]
        total = block.get("count", total)
        batch = block.get("values", [])
        if not batch:
            break
        for item in batch:
            rules.append(Rule(
                uid=str(item.get("id", "")),
                name=item.get("name", ""),
                id_on_device=item.get("idOnDevice", ""),
                description=item.get("description", "") or "",
            ))
        offset += GRAPHQL_PAGE_SIZE
        log.info(f"Fetched {len(rules)}" + (f" of {total}" if total is not None else "") + " rules")
        if total is not None and offset >= total:
            break
    return rules


# ─────────────────────────────────────────────
# App-ID resolution (real)
# ─────────────────────────────────────────────

def _clean_appid(value) -> str:
    if value is None:
        return ""
    s = str(value).strip().upper()
    if not s or s in ("NONE", "NO APPID", "NAN"):
        return ""
    if s.startswith("APP-"):
        return s
    if s.replace("-", "").isdigit():
        return f"APP-{s}"
    return s


def load_appid_map() -> dict:
    """
    Load the rule -> app-ID(s) mapping from CSV. Keyed by rule UID if present, else by
    id_on_device. Returns {key_upper: [app_id, ...]}.
    """
    path = Path(APPID_MAP_CSV)
    if not path.exists():
        log.warning(f"App-ID map not found: {APPID_MAP_CSV} — no rules will be tagged")
        return {}
    mapping = {}
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        cols = {c.lower(): c for c in (reader.fieldnames or [])}
        key_col = cols.get("rule_uid") or cols.get("uid") or cols.get("id_on_device")
        app_col = cols.get("app_id") or cols.get("appid") or cols.get("single appid")
        if not key_col or not app_col:
            log.error(f"{APPID_MAP_CSV} needs a rule key column (rule_uid or id_on_device) "
                      f"and an app_id column")
            return {}
        for row in reader:
            key = str(row.get(key_col, "")).strip().upper()
            app = _clean_appid(row.get(app_col))
            if key and app:
                mapping.setdefault(key, [])
                if app not in mapping[key]:
                    mapping[key].append(app)
    log.info(f"Loaded app-ID map for {len(mapping)} rule(s) from {APPID_MAP_CSV}")
    return mapping


def resolve_app_ids(rule: Rule, appid_map: dict) -> list:
    """Attach app IDs to a rule from the map (by UID, then id_on_device)."""
    if APPID_SOURCE == "mapping":
        return (appid_map.get(rule.uid.upper())
                or appid_map.get(rule.id_on_device.upper())
                or [])
    # "onrule": pull an app id already present in the description, if any
    found = []
    for line in rule.description.splitlines():
        line = line.strip()
        if line.lower().startswith(DESC_APPID_PREFIX):
            val = line[len(DESC_APPID_PREFIX):].strip()
            found.extend(_clean_appid(v) for v in val.split(",") if _clean_appid(v))
    return found


# ─────────────────────────────────────────────
# Build the new Description (real, pure functions)
# ─────────────────────────────────────────────

def _existing_app_ids(description: str) -> list:
    out = []
    for line in description.splitlines():
        line = line.strip()
        if line.lower().startswith(DESC_APPID_PREFIX):
            val = line[len(DESC_APPID_PREFIX):].strip()
            out.extend(_clean_appid(v) for v in val.split(",") if _clean_appid(v))
    return out


def build_new_description(rule: Rule) -> PlannedWrite:
    """
    Decide the new Description for a rule. Pure logic — no I/O. This is the part that
    won't change when the stubs get wired.
    """
    app_ids = rule.app_ids
    if not app_ids:
        return PlannedWrite(rule.uid, rule.id_on_device, rule.description, rule.description,
                            [], reason="no app id for this rule", skip=True)

    already = _existing_app_ids(rule.description)
    to_add = [a for a in app_ids if a not in already]

    if DESC_WRITE_MODE == "replace":
        new_desc = f"{DESC_APPID_PREFIX} {', '.join(app_ids)}"
        if new_desc.strip() == rule.description.strip():
            return PlannedWrite(rule.uid, rule.id_on_device, rule.description, rule.description,
                                app_ids, reason="already correct", skip=True)
        return PlannedWrite(rule.uid, rule.id_on_device, rule.description, new_desc,
                            app_ids, reason="replace description with app id line")

    # append mode
    if not to_add:
        return PlannedWrite(rule.uid, rule.id_on_device, rule.description, rule.description,
                            app_ids, reason="app id already present", skip=True)

    app_line = f"{DESC_APPID_PREFIX} {', '.join(already + to_add)}"
    if already:
        # replace the existing app_id line, keep everything else
        kept = [ln for ln in rule.description.splitlines()
                if not ln.strip().lower().startswith(DESC_APPID_PREFIX)]
        new_desc = "\n".join(kept + [app_line]).strip()
    elif rule.description.strip():
        new_desc = f"{rule.description.rstrip()}\n{app_line}"
    else:
        new_desc = app_line

    return PlannedWrite(rule.uid, rule.id_on_device, rule.description, new_desc,
                        app_ids, reason=f"add {', '.join(to_add)}")


# ─────────────────────────────────────────────
# Execute (batching real; the write is stubbed)
# ─────────────────────────────────────────────

def chunked(items, size):
    for i in range(0, len(items), size):
        yield items[i:i + size]


def execute_writes(planned: list) -> None:
    writes = [p for p in planned if not p.skip]
    skips = [p for p in planned if p.skip]
    log.info(f"{len(writes)} rule(s) to write, {len(skips)} skipped")

    if not writes:
        return

    n_batches = -(-len(writes) // WRITE_BATCH_SIZE)
    log.info(f"Writing in {n_batches} batch(es) of <= {WRITE_BATCH_SIZE}")
    done = 0
    for i, batch in enumerate(chunked(writes, WRITE_BATCH_SIZE), 1):
        for p in batch:
            if DRY_RUN:
                log.info(f"  [DRY RUN] would set Description on {p.id_on_device or p.uid}: "
                         f"{p.reason}")
                done += 1
                continue
            ok = _write_description(p.uid, p.new_description)
            if ok:
                done += 1
            else:
                log.error(f"  write failed for {p.uid}")
        log.info(f"  batch {i}: {done}/{len(writes)} so far")


def write_plan_csv(planned: list, path: str) -> None:
    Path(OUTPUT_DIR).mkdir(exist_ok=True)
    out = Path(OUTPUT_DIR) / path
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["rule_uid", "id_on_device", "app_ids", "action", "skip",
                    "old_description", "new_description"])
        for p in planned:
            w.writerow([p.uid, p.id_on_device, "; ".join(p.app_ids), p.reason, p.skip,
                        p.old_description, p.new_description])
    log.info(f"Wrote plan: {out}")


# ─────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────

def main():
    log.info("tag_app_ids — SCAFFOLD run")
    log.info(f"APPID_SOURCE={APPID_SOURCE} | DESC_WRITE_MODE={DESC_WRITE_MODE} | DRY_RUN={DRY_RUN}")
    if DRY_RUN:
        log.info("DRY RUN — no descriptions will be changed")

    out_dir = Path(OUTPUT_DIR)
    if out_dir.exists():
        for old in out_dir.glob("*.csv"):
            old.unlink()

    appid_map = load_appid_map() if APPID_SOURCE == "mapping" else {}

    rules = fetch_rules(RULE_FILTER)
    log.info(f"Fetched {len(rules)} rule(s)")

    for r in rules:
        r.app_ids = resolve_app_ids(r, appid_map)

    planned = [build_new_description(r) for r in rules]

    writes = sum(1 for p in planned if not p.skip)
    skips = sum(1 for p in planned if p.skip)
    log.info(f"Planned: {writes} write(s), {skips} skip(s)")

    execute_writes(planned)
    write_plan_csv(planned, "tag_plan.csv")
    log.info("Done (scaffold — external calls stubbed)")


if __name__ == "__main__":
    main()

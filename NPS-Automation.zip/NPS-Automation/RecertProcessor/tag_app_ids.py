"""
tag_app_ids.py
==============
Workstream 2, Task 1 — Tag App-IDs into the Tufin rule Description field
PG&E | NPS Automation

STATUS: real logic, confirmed against live Tufin. The read query, the write mutation,
and the join key are all verified:
  - Read query returns id (UID), idOnDevice, ruleUserData.ruleDescription   [confirmed]
  - Write mutation ruleUserData.updateRuleDescription(input:{description,ids}) returns
    resultStatus{successful errors}                             [confirmed: successful=true]
  - JOIN KEY: the spreadsheet "Rule Name" column == Tufin "idOnDevice"       [confirmed match]
    e.g. sheet Rule Name "ADMS_Endpoints to ODN_Tenabl_3-1-1"
         == Tufin idOnDevice "ADMS_Endpoints to ODN_Tenabl_3-1-1"
         -> UID "1E6L9H09iJ4l0s3XmAm-hw=="

The ONE thing still to wire: programmatic auth to the GraphQL endpoint. The browser
GraphiQL works because the browser is logged in; a script needs a token. Fill in
get_access_token() with the Keycloak flow (see the RE's script) — everything else runs.

WHAT THIS DOES
  1. Read the rule spreadsheet: pull each rule's App-ID (App-ID column) keyed by its
     Rule Name (Rule Name column). Rows without an app id are skipped.
  2. Query SecureTrack (paginated) for every rule's idOnDevice -> UID + current description.
  3. Join sheet rows to Tufin rules on Rule Name == idOnDevice.
  4. Build the new Description (add "app_id: APP-XXXX", preserve existing text, skip rules
     already tagged) and write it back per rule by UID via updateRuleDescription.
  5. Batch, dry-run, and write a plan CSV so every change is reviewable before it happens.

Rules are addressed by UID; app-IDs come from the sheet; the two are joined by Rule Name.
"""

import csv
import getpass
import logging
import requests
from dataclasses import dataclass, field
from pathlib import Path

# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────

DRY_RUN              = True          # True = log intended writes + plan CSV, change nothing

# The rule spreadsheet to read App-IDs from (the full sheet, not the report_ view).
EXCEL_PATH           = "rules.xlsx"

# Column headers in the spreadsheet (confirmed from the ODN/GDN sheets).
RULE_NAME_COLUMN     = "Rule Name"   # joins to Tufin idOnDevice
APPID_COLUMN         = "App-ID"      # the app id to write

# SecureTrack GraphQL endpoint (lab first; prod only once proven).
SECURETRACK_GRAPHQL  = "https://keeppgelabsecure.utility.pge.com/v2/api/sync/graphql"
GRAPHQL_PAGE_SIZE    = 100
GRAPHQL_MAX_PAGES    = 2000          # safety cap; count tells the real total
VERIFY_TLS           = False        # lab cert; set True in prod if the CA is trusted

# Only pull the rules you're tagging. The filter syntax matches the Rule Viewer.
RULE_FILTER          = "idOnDevice contains 'ADMS'"

# Keycloak auth. Credentials are prompted at runtime (getpass) — leave these BLANK so
# nothing sensitive is ever committed. If you must pre-set them for an automated run, do
# it via environment variables, NOT by typing them here (this file goes to the repo).
KEYCLOAK_TOKEN_URL   = "https://keeppgelabsecure.utility.pge.com/auth/realms/tufin-realm/protocol/openid-connect/token"
KEYCLOAK_CLIENT_ID   = "admin-cli"
KEYCLOAK_USERNAME    = ""            # blank -> prompted at runtime (or set env SECURETRACK_USER)
KEYCLOAK_PASSWORD    = ""            # blank -> prompted at runtime (never hardcode / commit)

# The line written into the Description, kept labelled so it's easy to find and parse back.
DESC_APPID_PREFIX    = "app_id:"
# Combine with any existing Description text: "append" keeps it, "replace" overwrites.
DESC_WRITE_MODE      = "append"

WRITE_BATCH_SIZE     = 100           # rules per updateRuleDescription call (ids is an array)
OUTPUT_DIR           = "tag_output"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("tag_app_ids")


# ─────────────────────────────────────────────
# Data model
# ─────────────────────────────────────────────

@dataclass
class Rule:
    uid: str
    id_on_device: str = ""
    description: str = ""
    app_ids: list = field(default_factory=list)


@dataclass
class PlannedWrite:
    uid: str
    rule_name: str
    old_description: str
    new_description: str
    app_ids: list
    reason: str = ""
    skip: bool = False


# ─────────────────────────────────────────────
# Auth  (the one remaining fill-in)
# ─────────────────────────────────────────────

_TOKEN_CACHE = {"token": None}

def get_access_token() -> str:
    """
    Get a bearer token for the GraphQL endpoint via Keycloak.

    Credentials are resolved in this order, so nothing sensitive lives in the file:
      1. the KEYCLOAK_USERNAME / KEYCLOAK_PASSWORD config values (leave blank),
      2. environment variables SECURETRACK_USER / SECURETRACK_PASSWORD,
      3. an interactive prompt (getpass — the password is hidden and never stored).

    Confirm KEYCLOAK_TOKEN_URL / KEYCLOAK_CLIENT_ID against the RE's script / Victor.
    """
    import os
    if _TOKEN_CACHE["token"]:
        return _TOKEN_CACHE["token"]

    username = KEYCLOAK_USERNAME or os.environ.get("SECURETRACK_USER", "")
    password = KEYCLOAK_PASSWORD or os.environ.get("SECURETRACK_PASSWORD", "")

    if not username:
        username = input("SecureTrack username (CorpID): ").strip()
    if not password:
        password = getpass.getpass("SecureTrack password: ")   # hidden, not stored

    resp = requests.post(
        KEYCLOAK_TOKEN_URL,
        data={"grant_type": "password", "client_id": KEYCLOAK_CLIENT_ID,
              "username": username, "password": password},
        verify=VERIFY_TLS, timeout=30,
    )
    resp.raise_for_status()
    token = resp.json()["access_token"]
    _TOKEN_CACHE["token"] = token
    return token


# ─────────────────────────────────────────────
# GraphQL calls  (read + write — confirmed shapes)
# ─────────────────────────────────────────────

def _graphql(query: str, variables: dict) -> dict:
    token = get_access_token()
    resp = requests.post(
        SECURETRACK_GRAPHQL,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        json={"query": query, "variables": variables},
        verify=VERIFY_TLS, timeout=60,
    )
    resp.raise_for_status()
    data = resp.json()
    if data.get("errors"):
        raise RuntimeError(f"GraphQL errors: {data['errors']}")
    return data


# Confirmed read query — `id` is the UID used for writes; idOnDevice is the join key.
_RULE_QUERY = """
query Rules($filter: String!, $first: Int!, $offset: Int!) {
  rules(filter: $filter) {
    count
    values(first: $first, offset: $offset) {
      id
      idOnDevice
      ruleUserData { ruleDescription }
    }
  }
}
"""

# Confirmed write mutation — ids is an ARRAY, so multiple rules per call works.
_UPDATE_DESC_MUTATION = """
mutation UpdateDescription($description: FreeText!, $ids: [IdString!]!) {
  ruleUserData {
    updateRuleDescription(input: {description: $description, ids: $ids}) {
      ids
      resultStatus { successful errors { errorCode errorMessage } }
    }
  }
}
"""


def fetch_rules(rule_filter: str) -> list:
    """Pull rules (paginated) with their UID, idOnDevice, and current description."""
    rules, offset, total = [], 0, None
    for _ in range(GRAPHQL_MAX_PAGES):
        data = _graphql(_RULE_QUERY,
                        {"filter": rule_filter, "first": GRAPHQL_PAGE_SIZE, "offset": offset})
        block = data["data"]["rules"]
        total = block.get("count", total)
        batch = block.get("values", [])
        if not batch:
            break
        for item in batch:
            rud = item.get("ruleUserData") or {}
            rules.append(Rule(
                uid=str(item.get("id", "")),
                id_on_device=item.get("idOnDevice") or "",
                description=(rud.get("ruleDescription") or ""),
            ))
        offset += GRAPHQL_PAGE_SIZE
        log.info(f"Fetched {len(rules)}" + (f" of {total}" if total is not None else "") + " rules")
        if total is not None and offset >= total:
            break
    return rules


def write_descriptions(uids: list, description: str) -> dict:
    """Write one description to a batch of rule UIDs. Returns the resultStatus dict."""
    data = _graphql(_UPDATE_DESC_MUTATION, {"description": description, "ids": uids})
    return data["data"]["ruleUserData"]["updateRuleDescription"]["resultStatus"]


# ─────────────────────────────────────────────
# Spreadsheet: Rule Name -> App-ID   (real)
# ─────────────────────────────────────────────

def _clean_appid(value) -> str:
    if value is None:
        return ""
    s = str(value).strip().upper()
    if not s or s in ("NONE", "NO APPID", "NAN"):
        return ""
    if s.startswith("APP-"):
        return s
    if s.replace("-", "").isdigit():
        return f"APP-{s}"
    return s


def load_rule_name_to_appids(excel_path) -> dict:
    """
    Read the spreadsheet and return { rule_name_upper: [app_id, ...] }, keyed by the
    Rule Name column (which joins to Tufin idOnDevice). Multiple app ids per rule are kept.
    """
    from openpyxl import load_workbook
    path = Path(excel_path)
    if not path.exists():
        log.error(f"Spreadsheet not found: {excel_path}")
        return {}

    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb[wb.sheetnames[0]]
    rows = ws.iter_rows(values_only=True)
    try:
        header = [str(h).strip() if h is not None else "" for h in next(rows)]
    except StopIteration:
        wb.close()
        return {}

    col = {h: i for i, h in enumerate(header)}
    name_idx = next((col[h] for h in col if h.lower() == RULE_NAME_COLUMN.lower()), None)
    app_idx  = next((col[h] for h in col if h.lower() == APPID_COLUMN.lower()), None)
    if name_idx is None or app_idx is None:
        log.error(f"Spreadsheet needs '{RULE_NAME_COLUMN}' and '{APPID_COLUMN}' columns; "
                  f"found: {header}")
        wb.close()
        return {}

    mapping = {}
    for row in rows:
        if not any(row):
            continue
        name = row[name_idx] if name_idx < len(row) else None
        app  = _clean_appid(row[app_idx] if app_idx < len(row) else None)
        if not name or not app:
            continue
        key = str(name).strip().upper()
        mapping.setdefault(key, [])
        if app not in mapping[key]:
            mapping[key].append(app)

    wb.close()
    log.info(f"Loaded App-IDs for {len(mapping)} rule name(s) from {path.name}")
    return mapping


# ─────────────────────────────────────────────
# Build the new Description  (real, pure logic)
# ─────────────────────────────────────────────

def _existing_app_ids(description: str) -> list:
    out = []
    for line in description.splitlines():
        line = line.strip()
        if line.lower().startswith(DESC_APPID_PREFIX):
            val = line[len(DESC_APPID_PREFIX):].strip()
            out.extend(_clean_appid(v) for v in val.split(",") if _clean_appid(v))
    return out


def build_new_description(rule: Rule) -> PlannedWrite:
    app_ids = rule.app_ids
    if not app_ids:
        return PlannedWrite(rule.uid, rule.id_on_device, rule.description, rule.description,
                            [], reason="no app id for this rule", skip=True)

    already = _existing_app_ids(rule.description)
    to_add = [a for a in app_ids if a not in already]

    if DESC_WRITE_MODE == "replace":
        new_desc = f"{DESC_APPID_PREFIX} {', '.join(app_ids)}"
        if new_desc.strip() == rule.description.strip():
            return PlannedWrite(rule.uid, rule.id_on_device, rule.description, rule.description,
                                app_ids, reason="already correct", skip=True)
        return PlannedWrite(rule.uid, rule.id_on_device, rule.description, new_desc,
                            app_ids, reason="replace description with app id line")

    if not to_add:
        return PlannedWrite(rule.uid, rule.id_on_device, rule.description, rule.description,
                            app_ids, reason="app id already present", skip=True)

    app_line = f"{DESC_APPID_PREFIX} {', '.join(already + to_add)}"
    if already:
        kept = [ln for ln in rule.description.splitlines()
                if not ln.strip().lower().startswith(DESC_APPID_PREFIX)]
        new_desc = "\n".join(kept + [app_line]).strip()
    elif rule.description.strip():
        new_desc = f"{rule.description.rstrip()}\n{app_line}"
    else:
        new_desc = app_line

    return PlannedWrite(rule.uid, rule.id_on_device, rule.description, new_desc,
                        app_ids, reason=f"add {', '.join(to_add)}")


# ─────────────────────────────────────────────
# Execute  (batching real; write is confirmed)
# ─────────────────────────────────────────────

def chunked(items, size):
    for i in range(0, len(items), size):
        yield items[i:i + size]


def execute_writes(planned: list) -> None:
    writes = [p for p in planned if not p.skip]
    skips = [p for p in planned if p.skip]
    log.info(f"{len(writes)} rule(s) to write, {len(skips)} skipped")
    if not writes:
        return

    # Group rules that get the SAME description text into one call (ids is an array),
    # capped at WRITE_BATCH_SIZE. Correct whether descriptions are shared or all unique.
    by_desc = {}
    for p in writes:
        by_desc.setdefault(p.new_description, []).append(p)

    done = 0
    for desc, group in by_desc.items():
        for batch in chunked(group, WRITE_BATCH_SIZE):
            uids = [p.uid for p in batch]
            if DRY_RUN:
                log.info(f"  [DRY RUN] would set {len(uids)} rule(s) -> "
                         f"'{desc[:60]}' (e.g. {batch[0].rule_name})")
                done += len(uids)
                continue
            status = write_descriptions(uids, desc)
            if status.get("successful"):
                done += len(uids)
                log.info(f"  wrote {len(uids)} rule(s) | {done}/{len(writes)}")
            else:
                log.error(f"  write failed for {len(uids)} rule(s): {status.get('errors')}")


def write_plan_csv(planned: list, path: str) -> None:
    Path(OUTPUT_DIR).mkdir(exist_ok=True)
    out = Path(OUTPUT_DIR) / path
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["rule_uid", "rule_name (idOnDevice)", "app_ids", "action", "skip",
                    "old_description", "new_description"])
        for p in planned:
            w.writerow([p.uid, p.rule_name, "; ".join(p.app_ids), p.reason, p.skip,
                        p.old_description, p.new_description])
    log.info(f"Wrote plan: {out}")


# ─────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────

def main():
    log.info("tag_app_ids — App-IDs into Tufin rule descriptions")
    log.info(f"DESC_WRITE_MODE={DESC_WRITE_MODE} | DRY_RUN={DRY_RUN}")
    if DRY_RUN:
        log.info("DRY RUN — no descriptions will be changed (plan CSV only)")

    out_dir = Path(OUTPUT_DIR)
    if out_dir.exists():
        for old in out_dir.glob("*.csv"):
            old.unlink()

    # 1. spreadsheet: Rule Name -> App-IDs
    name_to_appids = load_rule_name_to_appids(EXCEL_PATH)
    if not name_to_appids:
        log.error("No App-IDs loaded from the spreadsheet — nothing to tag.")
        return

    # 2. Tufin: rules with idOnDevice -> UID + current description
    rules = fetch_rules(RULE_FILTER)
    log.info(f"Fetched {len(rules)} rule(s) from Tufin")

    # 3. join on Rule Name == idOnDevice
    matched = 0
    for r in rules:
        r.app_ids = name_to_appids.get(r.id_on_device.strip().upper(), [])
        if r.app_ids:
            matched += 1
    log.info(f"Matched {matched} Tufin rule(s) to spreadsheet App-IDs on Rule Name")

    unmatched_sheet = set(name_to_appids) - {r.id_on_device.strip().upper() for r in rules}
    if unmatched_sheet:
        log.info(f"{len(unmatched_sheet)} spreadsheet rule name(s) had no matching Tufin "
                 f"rule in this filter (e.g. {list(unmatched_sheet)[:3]})")

    # 4. plan + write
    planned = [build_new_description(r) for r in rules]
    writes = sum(1 for p in planned if not p.skip)
    skips = sum(1 for p in planned if p.skip)
    log.info(f"Planned: {writes} write(s), {skips} skip(s)")

    execute_writes(planned)
    write_plan_csv(planned, "tag_plan.csv")
    log.info("Done" + (" (dry run)" if DRY_RUN else ""))


if __name__ == "__main__":
    main()

"""
recert_processor.py
===================
Workstream 2 — Rule Recertification Response Processing  (SCAFFOLD)
PG&E | NPS Automation

STATUS: structural scaffold. The decision logic, pagination, and batching are real
and tested. Every external call (SecureTrack GraphQL, AMPS, ticket creation) is a
STUB marked with TODO — wire these up when the following land:
  - The AMPS app-ID -> participants resolver (needs one->all-participants change)
  - The SecureTrack GraphQL endpoint + auth (Postman-verified in lab first)
  - Confirmation of which FUR step-1 field holds the app ID (varies by workflow version)
  - Tufin access (gated on PRA + NERC training)

WHAT THIS DOES (the pipeline the Tufin RE described, end to end):
  1. Pull rules from SecureTrack via GraphQL (paginated, 100/page, offset-based).
  2. For each rule, find its app ID(s) — from the description, or from related
     ticket step-1 fields.
  3. Resolve each app ID to the CURRENT full AMPS participant group (not one owner).
  4. Read the owner's recertification decision (from the returned spreadsheets).
  5. Branch on the decision and generate the right action:
        A) Recertify        -> recertify ticket
        B) Clean up/Remove  -> decommission-RULE ticket
        C) Review w/ team    -> hold, no ticket
        (owner disagreement) -> decommission-IP ticket for the dissenter only
        (DR-flagged)         -> keep, tag DR, no removal
  6. Batch ticket creation in chunks of <= 300 (Tufin's stated batch limit).
  7. Write certification status back into rule metadata via GraphQL mutation
     (the RLM-license workaround the RE suggested).

Nothing here submits anything while STUBS are in place — every action is logged.
"""

import csv
import json
import logging
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional

# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────

DRY_RUN              = True          # True = log intended actions, create/submit nothing

# SecureTrack GraphQL — verify these in Postman (lab environment) before trusting them
SECURETRACK_GRAPHQL  = "<SECURETRACK_GRAPHQL_URL>"   # TODO: lab VIP first, e.g. https://<tufin-lab-vip>/...
GRAPHQL_PAGE_SIZE    = 100                            # RE showed results paginate 100 at a time
GRAPHQL_MAX_PAGES    = 500                            # safety cap; count field tells real total

# AMPS resolution — provided by the AMPS/identity resolver (see team AMPS contact)
AMPS_MODE            = "script"      # "script" (call their code) or "csv" (daily dump)
AMPS_CSV_PATH        = "amps_appid_participants.csv"  # used if AMPS_MODE == "csv"

# Ticket batching — Tufin caps at 300 tickets per batch
TICKET_BATCH_SIZE    = 300

# Anchor paths to THIS script's location, not the working directory, so they resolve
# the same no matter where the script is launched or where OneDrive mounts.
SCRIPT_DIR           = Path(__file__).resolve().parent          # .../NPS-Automation/RecertProcessor
SHARED_ROOT          = SCRIPT_DIR.parent                        # .../NPS-Automation

# Where owner responses come from — the SHARED folder the notify tool writes to.
# Same physical folder both tools use: .../NPS-Automation/responses.
# Files are named Firewall_Rules_Recertification_<CORPID>.xlsx.
RESPONSES_DIR        = str(SHARED_ROOT / "responses")

# Rule description convention (per the RE): app ID and owner live in the description,
# one field per line, e.g.  "app_id: APP-XXXX"  and  "owner: <group>"
DESC_APPID_PREFIX    = "app_id:"
DESC_OWNER_PREFIX    = "owner:"

# Output (plan CSVs) stays under this tool's own folder.
OUTPUT_DIR           = str(SCRIPT_DIR / "recert_output")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("recert_processor")


# ─────────────────────────────────────────────
# Data model
# ─────────────────────────────────────────────

class Decision(Enum):
    """The owner's choice from the recertification email."""
    RECERTIFY = "A"       # still needed
    REMOVE    = "B"       # clean up / remove
    REVIEW    = "C"       # review with team
    NONE      = ""        # no response yet


class Action(Enum):
    """What this tool decides to do with a rule."""
    RECERTIFY_TICKET       = "recertify_ticket"
    DECOMMISSION_RULE      = "decommission_rule_ticket"
    DECOMMISSION_IP        = "decommission_ip_ticket"   # owner disagreement, dissenter only
    KEEP_DR                = "keep_dr"                   # DR-flagged, keep + tag
    HOLD_REVIEW            = "hold_review"               # C, or unresolved
    MANUAL                 = "manual"                    # can't be automated (see reason)


@dataclass
class Rule:
    rule_id: str
    name: str = ""
    device: str = ""
    description: str = ""
    app_ids: list = field(default_factory=list)         # may be more than one
    related_tickets: list = field(default_factory=list)
    is_dr: bool = False
    cert_status: str = "uncertified"
    # resolved later:
    owner_group: list = field(default_factory=list)     # full AMPS participant set
    responses: dict = field(default_factory=dict)       # corpid -> Decision


@dataclass
class PlannedAction:
    rule_id: str
    action: Action
    reason: str
    target_corpid: Optional[str] = None                 # set for decommission-IP


# ─────────────────────────────────────────────
# STUBS — external integrations (wire up when the real pieces land)
# ─────────────────────────────────────────────

def graphql_query(query: str, variables: dict) -> dict:
    """
    STUB. Run a GraphQL query against SecureTrack and return the parsed JSON.

    TODO when SECURETRACK_GRAPHQL and auth are known:
      - POST {query, variables} to SECURETRACK_GRAPHQL with the token/session header
      - the RE showed: any Rule Viewer filter works here; results carry a `count`
        field for the total and paginate with offset (see fetch_rules)
      - verify the exact query in Postman against the LAB VIP first
    """
    raise NotImplementedError("graphql_query: connect to SecureTrack GraphQL (see TODO)")


def graphql_mutation(mutation: str, variables: dict) -> dict:
    """
    STUB. Write back to a rule's metadata (e.g. certification status) via GraphQL.

    TODO: this is the RLM-license workaround the RE described — instead of RLM
    setting cert status, we mutate the rule description/metadata directly. Confirm
    the mutation shape against a known-good working example before enabling.
    """
    raise NotImplementedError("graphql_mutation: write cert status to rule metadata (see TODO)")


def amps_participants_for_app(app_id: str) -> list:
    """
    STUB. Resolve an app ID to the CURRENT full list of AMPS participants.

    This is the AMPS/identity resolver. Two changes from the base version:
      - it returns ONE participant today; we need ALL of them (the whole group)
      - resolve by app ID directly (already on-token), not by host/IP

    TODO:
      - if AMPS_MODE == "script": import/call their module, return every participant
        (name + corpid + role) plus the director for escalation
      - if AMPS_MODE == "csv": look app_id up in the daily CSV dump instead
    Returning [] means "no owner found" -> falls through to the default group.
    """
    raise NotImplementedError("amps_participants_for_app: call AMPS resolver (see TODO)")


def fetch_ticket_fields(ticket_id: str) -> dict:
    """
    STUB. Pull a related ticket and return its step-1 fields.

    TODO: the app ID lives in a step-1 field whose NAME varies by FUR workflow
    version (sometimes 'ID', sometimes 'SCADA', sometimes another name).
    Return the field dict; caller scans it for anything app-ID-shaped.
    """
    raise NotImplementedError("fetch_ticket_fields: read ticket step-1 fields (see TODO)")


def create_tickets(action: Action, rules_batch: list) -> list:
    """
    STUB. Create tickets for one batch (<= TICKET_BATCH_SIZE).

    TODO: SecureChange ticket creation. NOTE recert-ticket submission is currently
    limited to the RLM-licensed admins, so this may generate a batch for an approver
    to submit rather than submitting directly. Confirm the hand-off before enabling.
    Returns a list of created ticket IDs (or planned-ticket records in dry run).
    """
    raise NotImplementedError("create_tickets: SecureChange ticket creation (see TODO)")


# ─────────────────────────────────────────────
# Pipeline — this logic is real
# ─────────────────────────────────────────────

def fetch_rules(rule_filter: str) -> list:
    """
    Page through a GraphQL rule query and return Rule objects.
    Real pagination logic; depends only on the graphql_query stub.
    """
    rules, offset, total = [], 0, None
    for page in range(GRAPHQL_MAX_PAGES):
        variables = {"filter": rule_filter, "first": GRAPHQL_PAGE_SIZE, "offset": offset}
        data = graphql_query(_RULE_QUERY, variables)

        block   = data["data"]["rules"]
        total   = block.get("count", total)
        batch   = block.get("items", [])
        if not batch:
            break

        for item in batch:
            rules.append(_rule_from_graphql(item))

        offset += GRAPHQL_PAGE_SIZE
        log.info(f"Fetched {len(rules)}"
                 + (f" of {total}" if total is not None else "") + " rules")
        if total is not None and offset >= total:
            break

    return rules


_RULE_QUERY = """
query Rules($filter: String!, $first: Int!, $offset: Int!) {
  rules(filter: $filter, first: $first, offset: $offset) {
    count
    items { id name device description relatedTickets certificationStatus }
  }
}
"""  # TODO: reconcile field names with the real SecureTrack schema


def _rule_from_graphql(item: dict) -> Rule:
    r = Rule(
        rule_id=str(item.get("id", "")),
        name=item.get("name", ""),
        device=item.get("device", ""),
        description=item.get("description", "") or "",
        related_tickets=item.get("relatedTickets", []) or [],
        cert_status=item.get("certificationStatus", "uncertified"),
    )
    r.app_ids = extract_app_ids(r)
    r.is_dr   = "dr" in r.description.lower().split()   # placeholder; a real DR attribute is planned
    return r


def extract_app_ids(rule: Rule) -> list:
    """
    Find app IDs for a rule. First the description, then related tickets.
    Description parsing is real; the ticket path leans on a stub.
    """
    found = []

    for line in rule.description.splitlines():
        line = line.strip()
        if line.lower().startswith(DESC_APPID_PREFIX):
            val = line[len(DESC_APPID_PREFIX):].strip()
            if val:
                found.extend(v.strip() for v in val.split(",") if v.strip())

    if not found:
        for ticket_id in rule.related_tickets:
            try:
                fields = fetch_ticket_fields(ticket_id)
            except NotImplementedError:
                raise
            except Exception as e:
                log.warning(f"Rule {rule.rule_id}: ticket {ticket_id} lookup failed: {e}")
                continue
            found.extend(_scan_fields_for_app_id(fields))

    # legacy IDs (pre-2019) are 1-3 chars and unreliable — flag, don't guess (RE's point)
    return [a for a in dict.fromkeys(found) if _looks_like_modern_app_id(a)]


def _scan_fields_for_app_id(fields: dict) -> list:
    """The app-ID field name varies by workflow version; scan values heuristically."""
    hits = []
    for value in fields.values():
        text = str(value).strip()
        if _looks_like_modern_app_id(text):
            hits.append(text)
    return hits


def _looks_like_modern_app_id(value: str) -> bool:
    """
    Post-2019 app IDs are ~6 chars (often APP-####). Pre-2019 pulled-in IDs are
    1-3 chars and unreliable — those need manual handling, so we
    deliberately reject them here rather than resolve a wrong owner.
    """
    v = value.strip().upper().removeprefix("APP-")
    return len(v) >= 4 and any(c.isdigit() for c in v)


def resolve_owner_group(rule: Rule) -> list:
    """
    Turn a rule's app IDs into the merged, de-duplicated AMPS participant group.
    Merge logic is real; the per-app lookup is a stub.
    """
    group, seen = [], set()
    for app_id in rule.app_ids:
        for person in amps_participants_for_app(app_id):
            corpid = person.get("corpid", "").upper()
            if corpid and corpid not in seen:
                seen.add(corpid)
                group.append(person)
    return group


# ─────────────────────────────────────────────
# Decision logic — the core, fully real
# ─────────────────────────────────────────────

def decide_action(rule: Rule) -> PlannedAction:
    """
    Map a rule + its collected responses to a single planned action.
    Pure function, no I/O — this is the piece the meetings actually pinned down,
    and the piece that won't change when the stubs get wired up.
    """
    responses = {c: d for c, d in rule.responses.items() if d != Decision.NONE}

    # No response yet -> hold. (A real send is gated on owner acknowledgement.)
    if not responses:
        return PlannedAction(rule.rule_id, Action.HOLD_REVIEW, "no response yet")

    decisions = set(responses.values())

    # Anyone unsure -> the whole rule goes to review; don't act on a contested rule.
    if Decision.REVIEW in decisions:
        return PlannedAction(rule.rule_id, Action.HOLD_REVIEW,
                             "at least one owner chose 'review with team'")

    # Unanimous recertify -> recertify. DR just reinforces a keep.
    if decisions == {Decision.RECERTIFY}:
        return PlannedAction(rule.rule_id, Action.RECERTIFY_TICKET, "all owners recertified")

    # Unanimous remove -> but DR overrides removal (DR rules are kept + tagged).
    if decisions == {Decision.REMOVE}:
        if rule.is_dr:
            return PlannedAction(rule.rule_id, Action.KEEP_DR,
                                 "all chose remove, but rule is DR-flagged — keep + tag DR")
        return PlannedAction(rule.rule_id, Action.DECOMMISSION_RULE, "all owners chose remove")

    # Disagreement (some keep, some remove). Can't remove a rule someone still needs.
    # Owner-disagreement rule: dissenters who chose REMOVE get a decommission-IP ticket for
    # THEIR access only; the rule itself stays for the owners who recertified.
    removers = [c for c, d in responses.items() if d == Decision.REMOVE]
    if len(removers) == 1:
        return PlannedAction(rule.rule_id, Action.DECOMMISSION_IP,
                             "owners disagree — decommission IP for the sole remover",
                             target_corpid=removers[0])

    # More than one remover but not unanimous -> genuinely ambiguous, send to a human.
    return PlannedAction(rule.rule_id, Action.MANUAL,
                         f"owners disagree — {len(removers)} want removal, others recertify")


# ─────────────────────────────────────────────
# Response loading (interim: returned spreadsheets)
# ─────────────────────────────────────────────

def load_responses(rules_by_id: dict) -> None:
    """
    Read returned recertification spreadsheets from RESPONSES_DIR and attach each
    owner's per-rule decision to the matching Rule. Filename carries the CorpID:
    Firewall_Rules_Recertification_<CORPID>.xlsx. Real logic; needs openpyxl at runtime.
    """
    folder = Path(RESPONSES_DIR)
    if not folder.exists():
        log.info(f"No {RESPONSES_DIR}/ yet — no responses to load")
        return

    try:
        from openpyxl import load_workbook
    except ImportError:
        log.error("openpyxl not installed — run: py -m pip install openpyxl")
        return

    for path in folder.glob("Firewall_Rules_Recertification_*.xlsx"):
        corpid = path.stem.rsplit("_", 1)[-1].upper()
        wb = load_workbook(path, read_only=True, data_only=True)
        ws = wb.active
        headers = [str(c.value).strip().lower() if c.value else "" for c in next(ws.iter_rows())]
        try:
            id_col  = headers.index("rule id")
            dec_col = headers.index("decision")
        except ValueError:
            log.warning(f"{path.name}: missing 'Rule ID' or 'Decision' column, skipping")
            wb.close()
            continue

        applied = 0
        for row in ws.iter_rows(min_row=2, values_only=True):
            rid = str(row[id_col]).strip() if row[id_col] is not None else ""
            raw = str(row[dec_col]).strip().upper()[:1] if row[dec_col] else ""
            rule = rules_by_id.get(rid)
            if rule and raw in ("A", "B", "C"):
                rule.responses[corpid] = Decision(raw)
                applied += 1
        wb.close()
        log.info(f"{path.name}: applied {applied} decision(s) from {corpid}")


# ─────────────────────────────────────────────
# Batching + execution
# ─────────────────────────────────────────────

def chunked(items: list, size: int):
    for i in range(0, len(items), size):
        yield items[i:i + size]


def execute_plan(planned: list) -> None:
    """
    Group planned actions by type and create tickets in <= TICKET_BATCH_SIZE batches.
    Batching is real; ticket creation is stubbed. In DRY_RUN nothing is submitted.
    """
    ticketable = {
        Action.RECERTIFY_TICKET,
        Action.DECOMMISSION_RULE,
        Action.DECOMMISSION_IP,
    }

    by_action = {}
    for p in planned:
        by_action.setdefault(p.action, []).append(p)

    for action, group in by_action.items():
        if action not in ticketable:
            log.info(f"{action.value}: {len(group)} rule(s) — no ticket (informational)")
            continue

        log.info(f"{action.value}: {len(group)} rule(s) "
                 f"-> {(-(-len(group) // TICKET_BATCH_SIZE))} batch(es) of <= {TICKET_BATCH_SIZE}")
        for n, batch in enumerate(chunked(group, TICKET_BATCH_SIZE), 1):
            if DRY_RUN:
                log.info(f"  [DRY RUN] batch {n}: would create {len(batch)} {action.value}")
                continue
            ids = create_tickets(action, batch)
            log.info(f"  batch {n}: created {len(ids)} ticket(s)")


def write_plan_csv(planned: list, path: str) -> None:
    Path(OUTPUT_DIR).mkdir(exist_ok=True)
    out = Path(OUTPUT_DIR) / path
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["rule_id", "action", "reason", "target_corpid"])
        for p in planned:
            w.writerow([p.rule_id, p.action.value, p.reason, p.target_corpid or ""])
    log.info(f"Wrote plan: {out}")


# ─────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────

def main(rule_filter: str = "certification_status:uncertified"):
    log.info("recert_processor — SCAFFOLD run")
    if DRY_RUN:
        log.info("DRY RUN — no tickets created, no metadata written")

    # 1. pull rules
    rules = fetch_rules(rule_filter)
    rules_by_id = {r.rule_id: r for r in rules}
    log.info(f"Fetched {len(rules)} rule(s)")

    # 2-3. resolve owner groups
    for r in rules:
        r.owner_group = resolve_owner_group(r)

    # 4. load owner responses
    load_responses(rules_by_id)

    # 5. decide
    planned = [decide_action(r) for r in rules]
    summary = {}
    for p in planned:
        summary[p.action.value] = summary.get(p.action.value, 0) + 1
    log.info("Planned actions: " + ", ".join(f"{k}={v}" for k, v in sorted(summary.items())))

    # 6. batch + execute
    execute_plan(planned)

    # 7. write cert status back for recertified rules
    for p in planned:
        if p.action == Action.RECERTIFY_TICKET and not DRY_RUN:
            graphql_mutation(_CERT_MUTATION, {"ruleId": p.rule_id, "status": "certified"})

    write_plan_csv(planned, "recert_plan.csv")
    log.info("Done (scaffold — external calls stubbed)")


_CERT_MUTATION = """
mutation SetCert($ruleId: ID!, $status: String!) {
  updateRule(id: $ruleId, certificationStatus: $status) { id certificationStatus }
}
"""  # TODO: match the real mutation against a known-good working example


if __name__ == "__main__":
    main()

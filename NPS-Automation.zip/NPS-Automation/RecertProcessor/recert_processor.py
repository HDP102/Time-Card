"""
recert_processor.py
===================
Workstream 2, Task 2 — Create recertification tickets from owner decisions
PG&E | NPS Automation

STATUS: RECERTIFY path is real and confirmed. Reads the reporting view for each rule's
decision, joins to Tufin on Rule Name == idOnDevice, and creates a recertification ticket
via createTicketDraft (confirmed live: successful=true).

Confirmed against live Tufin:
  - Read:   rules { values(first,offset){ id idOnDevice } }                     [confirmed]
  - Ticket: ruleOperations { createTicketDraft(input:{ruleUids, workflowType,
            workflowName, subject, dryRun}) { invalidRules resultStatus{...} } }  [confirmed]
  - Recertify workflow: RECERTIFY_RULES / "RLM Rule Recertification Workflow"     [confirmed]
  - Join key: reporting-view "Rule Name" == Tufin idOnDevice                      [confirmed]
  - No double-recertify: the Tufin filter excludes rules already in a ticket
    (securechangeTicketInProgressId not exists)                                  [RE-provided]

Auth: reuses the same Keycloak getpass flow as tag_app_ids.py (prompted at runtime).

DECOMMISSION path (Cleanup/Remove) is NOT wired — it's a two-ticket process (disable,
wait ~2 weeks, then remove, per Sai) and there is no Tufin decom workflow yet (being
created). The decision is read and those rules are FLAGGED, not ticketed. See the
decom section for the confirmed spec, ready to wire once the workflow exists.

WHAT THIS DOES (recertify path)
  1. Read the reporting view: Rule Name -> decision (Recertify / Recertify-DR /
     Cleanup-Remove / Need Assistance).
  2. Query Tufin for rules to recertify (Palo Alto, high/critical, not already ticketed),
     giving idOnDevice -> UID.
  3. Join on Rule Name == idOnDevice; keep rules whose decision is Recertify (or DR).
  4. Create recertification tickets via createTicketDraft, batched.
  5. Flag Cleanup/Remove and Need-Assistance rules to a CSV for follow-up (no ticket).
  6. dryRun support: validate every ticket without creating it, and a plan CSV of all
     intended tickets.
"""

import csv
import getpass
import logging
import requests
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────

DRY_RUN              = True          # True = validate tickets (createTicketDraft dryRun) + plan CSV, create nothing

# The reporting view export carrying decisions + Rule Name (the reporting view that
# Same report_ convention as the notify script.
REPORT_PATH          = "report_rules.xlsx"
RULE_NAME_COLUMN     = "Rule Name"       # joins to Tufin idOnDevice
DECISION_COLUMN      = "Recertification" # Recertify / Recertify - DR / Cleanup - Remove / Need Assistance

# SecureTrack GraphQL endpoint (lab first; prod only once proven).
SECURETRACK_GRAPHQL  = "https://keeppgelabsecure.utility.pge.com/v2/api/sync/graphql"
GRAPHQL_PAGE_SIZE    = 100
GRAPHQL_MAX_PAGES    = 2000
VERIFY_TLS           = False

# Which rules to consider for recert. From the RE: Palo Alto, high/critical severity,
# NOT already in a ticket (this is what prevents double-recertifying), overdue/uncertified,
# ADMS scope. Adjust as needed.
RULE_FILTER          = ("vendor='PALO_ALTO' and securechangeTicketInProgressId not exists "
                        "and (violationHighestSeverity='CRITICAL' or violationHighestSeverity='HIGH') "
                        "and (idOnDevice contains 'ADMS')")

# Recertify workflow — CONFIRMED via createTicketDraft dry run.
RECERTIFY_WORKFLOW_TYPE = "RECERTIFY_RULES"
RECERTIFY_WORKFLOW_NAME = "RLM Rule Recertification Workflow"
RECERTIFY_SUBJECT       = "Recertify Firewall Rules - NPS"

TICKET_BATCH_SIZE    = 300           # <= 300 rules per ticket draft (cap)

# Keycloak auth — prompted at runtime (getpass); blank so nothing sensitive is committed.
KEYCLOAK_TOKEN_URL   = "https://keeppgelabsecure.utility.pge.com/auth/realms/tufin-realm/protocol/openid-connect/token"
KEYCLOAK_CLIENT_ID   = "admin-cli"
KEYCLOAK_USERNAME    = ""            # blank -> prompted (or env SECURETRACK_USER)
KEYCLOAK_PASSWORD    = ""            # blank -> prompted (never hardcode / commit)

OUTPUT_DIR           = "recert_output"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("recert_processor")


# ─────────────────────────────────────────────
# Decisions
# ─────────────────────────────────────────────

class Decision(Enum):
    RECERTIFY = "recertify"      # Recertify (and Recertify - DR)
    REMOVE    = "remove"         # Cleanup / Remove  -> decom (flagged, not wired)
    ASSIST    = "assist"         # Need Assistance   -> flagged, no ticket
    NONE      = "none"           # blank / not yet answered


def parse_decision(value) -> Decision:
    if value is None:
        return Decision.NONE
    v = str(value).strip().lower()
    if not v:
        return Decision.NONE
    if v.startswith("recert"):          # "Recertify" or "Recertify - DR"
        return Decision.RECERTIFY
    if "cleanup" in v or "remove" in v:
        return Decision.REMOVE
    if "assist" in v:
        return Decision.ASSIST
    return Decision.NONE


# ─────────────────────────────────────────────
# Data model
# ─────────────────────────────────────────────

@dataclass
class Rule:
    uid: str
    id_on_device: str = ""
    decision: Decision = Decision.NONE


# ─────────────────────────────────────────────
# Auth  (same getpass Keycloak flow as tag_app_ids.py)
# ─────────────────────────────────────────────

_TOKEN_CACHE = {"token": None}

def get_access_token() -> str:
    import os
    if _TOKEN_CACHE["token"]:
        return _TOKEN_CACHE["token"]
    username = KEYCLOAK_USERNAME or os.environ.get("SECURETRACK_USER", "")
    password = KEYCLOAK_PASSWORD or os.environ.get("SECURETRACK_PASSWORD", "")
    if not username:
        username = input("SecureTrack username (CorpID): ").strip()
    if not password:
        password = getpass.getpass("SecureTrack password: ")
    resp = requests.post(
        KEYCLOAK_TOKEN_URL,
        data={"grant_type": "password", "client_id": KEYCLOAK_CLIENT_ID,
              "username": username, "password": password},
        verify=VERIFY_TLS, timeout=30,
    )
    resp.raise_for_status()
    token = resp.json()["access_token"]
    _TOKEN_CACHE["token"] = token
    return token


# ─────────────────────────────────────────────
# GraphQL  (read + createTicketDraft — confirmed shapes)
# ─────────────────────────────────────────────

def _graphql(query: str, variables: dict) -> dict:
    token = get_access_token()
    resp = requests.post(
        SECURETRACK_GRAPHQL,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        json={"query": query, "variables": variables},
        verify=VERIFY_TLS, timeout=60,
    )
    resp.raise_for_status()
    data = resp.json()
    if data.get("errors"):
        raise RuntimeError(f"GraphQL errors: {data['errors']}")
    return data


_RULE_QUERY = """
query Rules($filter: String!, $first: Int!, $offset: Int!) {
  rules(filter: $filter) {
    count
    values(first: $first, offset: $offset) {
      id
      idOnDevice
    }
  }
}
"""

# Confirmed: createTicketDraft with dryRun support.
_CREATE_TICKET_MUTATION = """
mutation CreateTicket($ruleUids: [String!]!, $workflowType: WorkflowType!,
                      $workflowName: String!, $subject: String!, $dryRun: Boolean!) {
  ruleOperations {
    createTicketDraft(input: {
      ruleUids: $ruleUids,
      workflowType: $workflowType,
      workflowName: $workflowName,
      subject: $subject,
      dryRun: $dryRun
    }) {
      invalidRules { reason ruleUid }
      resultStatus { successful errors { errorCode errorMessage } }
    }
  }
}
"""


def fetch_recert_candidates(rule_filter: str) -> list:
    """Rules eligible for recert (paginated): UID + idOnDevice. The filter already
    excludes rules already in a ticket, so this won't double-recertify."""
    rules, offset, total = [], 0, None
    for _ in range(GRAPHQL_MAX_PAGES):
        data = _graphql(_RULE_QUERY,
                        {"filter": rule_filter, "first": GRAPHQL_PAGE_SIZE, "offset": offset})
        block = data["data"]["rules"]
        total = block.get("count", total)
        batch = block.get("values", [])
        if not batch:
            break
        for item in batch:
            rules.append(Rule(uid=str(item.get("id", "")),
                              id_on_device=item.get("idOnDevice") or ""))
        offset += GRAPHQL_PAGE_SIZE
        log.info(f"Fetched {len(rules)}" + (f" of {total}" if total is not None else "") + " candidate rules")
        if total is not None and offset >= total:
            break
    return rules


def create_recert_ticket(uids: list, dry_run: bool) -> dict:
    """Create (or dry-run validate) one recertification ticket for a batch of UIDs."""
    data = _graphql(_CREATE_TICKET_MUTATION, {
        "ruleUids": uids,
        "workflowType": RECERTIFY_WORKFLOW_TYPE,
        "workflowName": RECERTIFY_WORKFLOW_NAME,
        "subject": RECERTIFY_SUBJECT,
        "dryRun": dry_run,
    })
    return data["data"]["ruleOperations"]["createTicketDraft"]


# ─────────────────────────────────────────────
# Reporting view: Rule Name -> decision  (real)
# ─────────────────────────────────────────────

def load_decisions(report_path) -> dict:
    """Read the reporting view -> { rule_name_upper: Decision }. Last non-blank wins
    if a rule name appears more than once."""
    from openpyxl import load_workbook
    path = Path(report_path)
    if not path.exists():
        log.error(f"Reporting view not found: {report_path}")
        return {}

    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb[wb.sheetnames[0]]
    rows = ws.iter_rows(values_only=True)
    try:
        header = [str(h).strip() if h is not None else "" for h in next(rows)]
    except StopIteration:
        wb.close()
        return {}

    col = {h: i for i, h in enumerate(header)}
    name_idx = next((col[h] for h in col if h.lower() == RULE_NAME_COLUMN.lower()), None)
    dec_idx  = next((col[h] for h in col if h.lower() == DECISION_COLUMN.lower()), None)
    if name_idx is None or dec_idx is None:
        log.error(f"Reporting view needs '{RULE_NAME_COLUMN}' and '{DECISION_COLUMN}' "
                  f"columns; found: {header}")
        wb.close()
        return {}

    decisions = {}
    for row in rows:
        if not any(row):
            continue
        name = row[name_idx] if name_idx < len(row) else None
        if not name:
            continue
        dec = parse_decision(row[dec_idx] if dec_idx < len(row) else None)
        key = str(name).strip().upper()
        # don't let a later blank overwrite a real decision
        if key in decisions and dec is Decision.NONE:
            continue
        decisions[key] = dec

    wb.close()
    counts = {}
    for d in decisions.values():
        counts[d.value] = counts.get(d.value, 0) + 1
    log.info(f"Loaded {len(decisions)} rule decision(s) from {path.name}: {counts}")
    return decisions


# ─────────────────────────────────────────────
# Execute
# ─────────────────────────────────────────────

def chunked(items, size):
    for i in range(0, len(items), size):
        yield items[i:i + size]


def write_outputs(recertify, flagged_remove, flagged_assist):
    Path(OUTPUT_DIR).mkdir(exist_ok=True)
    # recertify plan
    with open(Path(OUTPUT_DIR) / "recertify_plan.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["rule_uid", "rule_name (idOnDevice)", "decision"])
        for r in recertify:
            w.writerow([r.uid, r.id_on_device, "Recertify"])
    # flagged (need follow-up / decom pending workflow)
    with open(Path(OUTPUT_DIR) / "flagged_for_followup.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["rule_uid", "rule_name (idOnDevice)", "decision", "note"])
        for r in flagged_remove:
            w.writerow([r.uid, r.id_on_device, "Cleanup/Remove",
                        "decommission pending workflow creation (disable->wait->remove)"])
        for r in flagged_assist:
            w.writerow([r.uid, r.id_on_device, "Need Assistance", "NPS to follow up; no ticket"])
    log.info(f"Wrote plan + flagged CSVs to {OUTPUT_DIR}/")


def main():
    log.info("recert_processor — recertify path")
    log.info(f"DRY_RUN={DRY_RUN}")
    if DRY_RUN:
        log.info("DRY RUN — tickets are validated (createTicketDraft dryRun) but NOT created")

    out = Path(OUTPUT_DIR)
    if out.exists():
        for old in out.glob("*.csv"):
            old.unlink()

    # 1. decisions from the reporting view
    decisions = load_decisions(REPORT_PATH)
    if not decisions:
        log.error("No decisions loaded — nothing to do.")
        return

    # 2. candidate rules from Tufin (already excludes rules in a ticket)
    candidates = fetch_recert_candidates(RULE_FILTER)
    log.info(f"Fetched {len(candidates)} candidate rule(s) from Tufin")

    # 3. join on Rule Name == idOnDevice; attach decisions
    for r in candidates:
        r.decision = decisions.get(r.id_on_device.strip().upper(), Decision.NONE)

    recertify      = [r for r in candidates if r.decision is Decision.RECERTIFY]
    flagged_remove = [r for r in candidates if r.decision is Decision.REMOVE]
    flagged_assist = [r for r in candidates if r.decision is Decision.ASSIST]
    no_decision    = [r for r in candidates if r.decision is Decision.NONE]

    log.info(f"Recertify: {len(recertify)} | Cleanup/Remove (flagged): {len(flagged_remove)} "
             f"| Need Assistance (flagged): {len(flagged_assist)} | no decision yet: {len(no_decision)}")

    # 4. create recertify tickets (batched), dry-run validated first
    if recertify:
        n_batches = -(-len(recertify) // TICKET_BATCH_SIZE)
        log.info(f"Recertify tickets: {n_batches} batch(es) of <= {TICKET_BATCH_SIZE}")
        for i, batch in enumerate(chunked(recertify, TICKET_BATCH_SIZE), 1):
            uids = [r.uid for r in batch]
            result = create_recert_ticket(uids, dry_run=DRY_RUN)
            status = result.get("resultStatus", {})
            invalid = result.get("invalidRules", [])
            ok = status.get("successful")
            tag = "validated" if DRY_RUN else "created"
            if ok:
                log.info(f"  batch {i}: {tag} ticket for {len(uids)} rule(s)"
                         + (f", {len(invalid)} invalid" if invalid else ""))
            else:
                log.error(f"  batch {i}: FAILED — {status.get('errors')}; invalid={invalid}")
    else:
        log.info("No rules marked Recertify — no recert tickets.")

    # 5. flagged rows for follow-up (decom pending workflow; assist = manual)
    write_outputs(recertify, flagged_remove, flagged_assist)

    # ── DECOMMISSION (Cleanup/Remove) — NOT WIRED, pending workflow ──────────
    # Confirmed spec from Sai (2026-08-26):
    #   Two tickets, same workflow:
    #     Ticket 1 (DISABLE): identify the rule, CHECK recent traffic hits first (don't
    #       blindly trust the spreadsheet), then disable.
    #     Ticket 2 (REMOVE, ~2 weeks later): reuse the ticket info; validate the rule is
    #       STILL disabled (someone may have re-enabled it) — "remove only if disabled" —
    #       then remove from the firewall.
    #   There is no Tufin decom workflow yet (done manually today via PAN API). One is
    #   getting one created (or confirming whether "Remove Access - FER Life Cycle" fits).
    #   Once the workflow exists: confirm its workflowType/name with a createTicketDraft
    #   dry run (like recertify), then wire the two-stage disable/remove here. The
    #   traffic-hit check can use Tufin's lastHit data; the "still disabled" check reads
    #   the rule's current state before the remove ticket.
    # ────────────────────────────────────────────────────────────────────────

    log.info("Done" + (" (dry run)" if DRY_RUN else ""))


if __name__ == "__main__":
    main()

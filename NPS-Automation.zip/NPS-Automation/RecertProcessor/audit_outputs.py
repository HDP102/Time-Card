"""
audit_outputs.py
================
Deep audit of the workbooks produced by tag_app_ids.py and recert_processor.py.

verify_run.py tells you THAT something failed. This tells you WHAT — which rows, which
values, which columns — without opening a 76,000-row workbook by hand.

It reads only, and never modifies a plan file.

USAGE
  Put this beside recert_output/ and tag_output/, then:

      py audit_outputs.py

  Writes audit_report.xlsx beside itself, with five filterable tabs:

      Summary      one row per workbook: rows, columns, file
      Columns      per column: fill rate, distinct count, most common values
      Integrity    cross-file checks that must hold, with pass/fail
      Anomalies    every problem found, with counts and example UIDs
      Samples      real rows from each workbook, to confirm formatting

  Rule names and UIDs appear in Samples and in the Anomalies examples, so treat the
  report as production data. Set SAMPLE_ROWS = 0 for statistics only.
"""

import re
import sys
from collections import Counter
from pathlib import Path

# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────

OUTPUT_DIRS  = ["recert_output", "tag_output"]
OUT_FILE     = "audit_report.xlsx"

SAMPLE_ROWS  = 20        # rows kept per workbook (0 = statistics only)
MAX_DISTINCT = 25        # a column with more distinct values than this is summarised
MAX_EXAMPLES = 8

RLM_MARKER  = "##RLM##"
UID_RE      = re.compile(r"^[A-Za-z0-9_\-]{20,24}==$")
HEADER_FILL = "1F3864"


def load(path):
    from openpyxl import load_workbook
    try:
        wb = load_workbook(path, read_only=True, data_only=True)
    except PermissionError:
        return None, None, "open in Excel"
    except Exception as e:
        return None, None, str(e)[:60]
    ws = wb[wb.sheetnames[0]]
    it = ws.iter_rows(values_only=True)
    try:
        headers = [str(h).strip() if h is not None else "" for h in next(it)]
    except StopIteration:
        wb.close()
        return [], [], None
    rows = [list(r) for r in it if any(v is not None and str(v).strip() for v in r)]
    wb.close()
    return headers, rows, None


def cell(row, i):
    if i is None or i >= len(row) or row[i] is None:
        return ""
    return str(row[i]).strip()


def col_index(headers, name):
    low = [h.lower() for h in headers]
    return low.index(name.lower()) if name.lower() in low else None


def uid_set(book):
    i = col_index(book["headers"], "rule_uid")
    if i is None:
        return set()
    return {cell(r, i) for r in book["rows"] if cell(r, i)}


# ─────────────────────────────────────────────
# Checks
# ─────────────────────────────────────────────

def check_uids(name, book, anomalies):
    i = col_index(book["headers"], "rule_uid")
    if i is None:
        return
    uids = [cell(r, i) for r in book["rows"]]

    blank = sum(1 for u in uids if not u)
    if blank:
        anomalies.append([name, "blank rule_uid", blank, ""])

    malformed = [u for u in uids if u and not UID_RE.match(u)]
    if malformed:
        anomalies.append([name, "rule_uid not in expected format", len(malformed),
                          "; ".join(malformed[:MAX_EXAMPLES])])

    dupes = [u for u, c in Counter(u for u in uids if u).items() if c > 1]
    if dupes:
        anomalies.append([name, "duplicate rule_uid", len(dupes),
                          "; ".join(dupes[:MAX_EXAMPLES])])


def check_tag_plan(book, anomalies):
    h, rows = book["headers"], book["rows"]
    i_skip = col_index(h, "skip")
    i_old  = col_index(h, "old_description")
    i_new  = col_index(h, "new_description")
    i_app  = col_index(h, "app_ids")
    i_uid  = col_index(h, "rule_uid")
    if None in (i_skip, i_old, i_new):
        return

    changed = empty = no_app = rlm_written = 0
    ex_changed, ex_rlm = [], []

    for r in rows:
        skipped = cell(r, i_skip).upper() == "TRUE"
        old, new = cell(r, i_old), cell(r, i_new)
        if skipped and old != new:
            changed += 1
            if len(ex_changed) < MAX_EXAMPLES:
                ex_changed.append(cell(r, i_uid))
        if not skipped:
            if not new:
                empty += 1
            if i_app is not None and not cell(r, i_app):
                no_app += 1
            if RLM_MARKER in old:
                rlm_written += 1
                if len(ex_rlm) < MAX_EXAMPLES:
                    ex_rlm.append(cell(r, i_uid))

    if changed:
        anomalies.append(["tag_plan",
                          "marked skip but description differs — a skipped rule must be "
                          "left untouched", changed, "; ".join(ex_changed)])
    if empty:
        anomalies.append(["tag_plan", "not skipped but new_description is empty", empty, ""])
    if no_app:
        anomalies.append(["tag_plan", "would be written but has no app_ids", no_app, ""])
    if rlm_written:
        anomalies.append(["tag_plan",
                          "has a ##RLM## description but is NOT skipped — check "
                          "SKIP_RLM_DESCRIPTIONS is set as intended",
                          rlm_written, "; ".join(ex_rlm)])


def check_hit_states(name, book, expect, anomalies):
    i = col_index(book["headers"], "hit_state")
    if i is None:
        return
    bad = Counter(cell(r, i) for r in book["rows"]
                  if cell(r, i) and cell(r, i) not in expect)
    if bad:
        anomalies.append([name, f"hit_state outside {sorted(expect)}",
                          sum(bad.values()),
                          "; ".join(f"{k}={v}" for k, v in bad.items())])


def cross_checks(books, anomalies):
    checks = []
    pairs = [
        ("disable_plan", "held_back_from_disable",
         "a rule cannot be both scheduled for disable and held back"),
        ("recertify_plan", "disable_plan",
         "a rule cannot be both recertified and disabled"),
        ("recertify_plan", "held_back_from_disable",
         "a recertify rule should not be in the cleanup hold-back set"),
        ("need_assistance", "disable_plan",
         "a need-assistance rule should not be scheduled for disable"),
    ]
    for a, b, why in pairs:
        if a in books and b in books:
            overlap = uid_set(books[a]) & uid_set(books[b])
            checks.append([f"no overlap: {a} / {b}",
                           "PASS" if not overlap else "FAIL",
                           len(overlap), 0, why,
                           "; ".join(sorted(overlap)[:MAX_EXAMPLES])])
            if overlap:
                anomalies.append([f"{a} / {b}", f"UIDs in both files — {why}",
                                  len(overlap),
                                  "; ".join(sorted(overlap)[:MAX_EXAMPLES])])

    if "tag_plan" in books:
        tp = uid_set(books["tag_plan"])
        for n in ("recertify_plan", "disable_plan", "held_back_from_disable"):
            if n in books:
                missing = uid_set(books[n]) - tp
                checks.append([f"{n} UIDs present in tag_plan",
                               "PASS" if not missing else "FAIL", len(missing), 0,
                               "every planned rule comes from the same fetch as tag_plan",
                               "; ".join(sorted(missing)[:MAX_EXAMPLES])])

    if "disable_plan" in books and "held_back_from_disable" in books:
        d = len(books["disable_plan"]["rows"])
        hb = len(books["held_back_from_disable"]["rows"])
        checks.append(["cleanup decisions accounted for", "INFO", d + hb, "",
                       f"disable_plan {d:,} + held_back {hb:,}", ""])
    return checks


# ─────────────────────────────────────────────
# Workbook
# ─────────────────────────────────────────────

def add_sheet(wb, title, header, rows, widths=None):
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter

    ws = wb.create_sheet(title[:31])
    ws.append(list(header))
    for c in range(1, len(header) + 1):
        k = ws.cell(row=1, column=c)
        k.fill = PatternFill("solid", fgColor=HEADER_FILL)
        k.font = Font(color="FFFFFF", bold=True)
        k.alignment = Alignment(vertical="center")

    for r in rows:
        ws.append(["" if v is None else v for v in r])

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(header))}{max(len(rows) + 1, 1)}"

    for i, name in enumerate(header, start=1):
        if widths and i - 1 < len(widths):
            ws.column_dimensions[get_column_letter(i)].width = widths[i - 1]
            continue
        widest = len(str(name))
        for r in rows[:300]:
            if i - 1 < len(r) and r[i - 1] is not None:
                widest = max(widest, len(str(r[i - 1]).split("\n")[0]))
        ws.column_dimensions[get_column_letter(i)].width = min(max(widest + 3, 10), 60)
    return ws


def main():
    try:
        from openpyxl import Workbook
    except ImportError:
        sys.exit("openpyxl is required:  py -m pip install openpyxl")

    here = Path(__file__).resolve().parent
    books, skipped, anomalies = {}, [], []

    for d in OUTPUT_DIRS:
        folder = here / d
        if not folder.is_dir():
            print(f"  - {d}/ not found, skipping")
            continue
        for path in sorted(folder.glob("*.xlsx")):
            if path.name.startswith("~$") or path.name == OUT_FILE:
                continue
            headers, rows, err = load(path)
            if err:
                print(f"  ! {path.name}: {err}")
                skipped.append([path.name, err])
                continue
            books[path.stem] = {"folder": d, "file": path.name,
                                "headers": headers, "rows": rows}
            print(f"  {d}/{path.name}: {len(rows):,} rows")

    if not books:
        sys.exit("No .xlsx found in " + " or ".join(OUTPUT_DIRS))

    for name, book in books.items():
        check_uids(name, book, anomalies)
    if "tag_plan" in books:
        check_tag_plan(books["tag_plan"], anomalies)
    if "disable_plan" in books:
        check_hit_states("disable_plan", books["disable_plan"], {"stale"}, anomalies)
    if "held_back_from_disable" in books:
        check_hit_states("held_back_from_disable", books["held_back_from_disable"],
                         {"never", "recent"}, anomalies)

    checks = cross_checks(books, anomalies)

    wb = Workbook()
    wb.remove(wb.active)

    summary = [[n, b["folder"], b["file"], len(b["rows"]), len(b["headers"]),
                ", ".join(b["headers"])] for n, b in sorted(books.items())]
    for name, err in skipped:
        summary.append([name.replace(".xlsx", ""), "", name, "NOT READ", "", err])
    add_sheet(wb, "Summary",
              ["workbook", "folder", "file", "rows", "columns", "headers"],
              summary, widths=[28, 16, 32, 10, 10, 70])

    colrows = []
    for name, b in sorted(books.items()):
        total = len(b["rows"])
        for i, h in enumerate(b["headers"]):
            vals = [cell(r, i) for r in b["rows"]]
            filled = sum(1 for v in vals if v)
            dist = Counter(v for v in vals if v)
            top = dist.most_common() if 0 < len(dist) <= MAX_DISTINCT else dist.most_common(5)
            colrows.append([name, h, filled,
                            round(100.0 * filled / total, 1) if total else 0.0,
                            len(dist),
                            "; ".join(f"{k} ({v:,})" for k, v in top)[:400]])
    add_sheet(wb, "Columns",
              ["workbook", "column", "filled", "fill %", "distinct", "values"],
              colrows, widths=[28, 26, 10, 9, 10, 80])

    add_sheet(wb, "Integrity",
              ["check", "result", "found", "expected", "why it matters", "examples"],
              checks, widths=[44, 9, 10, 10, 58, 50])

    add_sheet(wb, "Anomalies",
              ["workbook", "issue", "count", "examples"],
              anomalies or [["", "none found", 0, ""]],
              widths=[28, 68, 10, 50])

    if SAMPLE_ROWS > 0:
        srows = []
        for name, b in sorted(books.items()):
            rows = b["rows"]
            if not rows:
                continue
            n = max(1, SAMPLE_ROWS // 3)
            mid = len(rows) // 2
            picks = rows if len(rows) <= SAMPLE_ROWS else \
                rows[:n] + rows[mid:mid + n] + rows[-n:]
            for r in picks[:SAMPLE_ROWS]:
                pairs = "  |  ".join(f"{h}={cell(r, i)}"
                                     for i, h in enumerate(b["headers"]) if cell(r, i))
                srows.append([name, pairs[:500]])
        add_sheet(wb, "Samples", ["workbook", "row"], srows, widths=[28, 120])

    out = here / OUT_FILE
    wb.save(out)

    failed = [c for c in checks if c[1] == "FAIL"]
    print(f"\n  {len(books)} workbook(s), "
          f"{sum(len(b['rows']) for b in books.values()):,} rows")
    print(f"  {len(anomalies)} anomaly finding(s)")
    for a in anomalies[:10]:
        print(f"    ! {a[0]}: {a[1]} ({a[2]})")
    print(f"  {len(checks) - len(failed)}/{len(checks)} integrity check(s) passed")
    for c in failed:
        print(f"    ! {c[0]}")
    print(f"\n  Written: {out}")


if __name__ == "__main__":
    main()

# App-ID Tagging (`tag_app_ids.py`)

Writes the App-ID for each firewall rule into that rule's **Description** field in Tufin
SecureTrack, so the app id becomes a queryable attribute on the rule. This is the
documentation half of the recertification effort — every rule traceable to a valid app.

It targets the Tufin **Description** metadata field (DOCUMENTATION → ADDITIONAL
INFORMATION → Description), **not** Panorama tags — tags overload the firewalls.

---

## How it works

| Source | Gives |
|---|---|
| Reporting views | App-ID and rule name for each rule |
| `Rule-ID-Mapping.xlsx` | Device Name + rule name → SecureTrack Rule ID |
| Tufin (GraphQL read) | The rule's UID and current description |

1. Read every reporting view matching `EXCEL_PATH` from the shared data folder. A glob
   processes all eleven lists in one run rather than refetching the estate per sheet.
   Rows with no App-ID are skipped.
2. Resolve each row to a rule UID through the mapping workbook.
3. Fetch rules from Tufin: UID, `idOnDevice`, current description.
4. Match on UID, build the new description, write it back per rule.
5. Write `tag_output/tag_plan.xlsx` listing every intended change.

### Rules are addressed by UID, never by name

An earlier version joined on rule name alone. Rule names repeat across devices, and one
spreadsheet row was found matching **100 rules on different devices** — which would have
written app ids onto rules nobody asked about.

There is no name-only fallback. A row that cannot be resolved to exactly one rule is
reported and skipped, with the device names that failed and a per-sheet resolve rate, so a
list that finds its columns but cannot match the mapping is visible rather than silently
contributing nothing.

### Reporting-view headers are not consistent

Across the eleven lists the device column appears as `Device Name`, `Device Group`,
`Device group`, or `Title`, and the app column as `App-ID` or `Application ID`. Both are
alias lists in the config, and the script logs which name each sheet matched.

---

## Setup

```
py -m pip install openpyxl requests
py tag_app_ids.py
```

Credentials are prompted at runtime and never written to disk. `SECURETRACK_USER` and
`SECURETRACK_PASSWORD` work for an unattended run.

The SecureTrack **API role is granted separately from UI access** — an account can sign in
to the Tufin web interface and still get 403 from the GraphQL API.

Spreadsheets live in `../SharedData/`. See the repository README for the layout.

---

## Key settings

| Setting | Purpose |
|---|---|
| `DRY_RUN` | `True` writes the plan file only and changes nothing. **Default.** |
| `EXCEL_PATH` | Input reporting views; accepts a glob such as `report_*.xlsx` |
| `MAPPING_PATH` | The Rule-ID-Mapping workbook |
| `DATA_DIR` | Shared folder the two above resolve against |
| `RULE_FILTER` | Which Tufin rules to fetch (TQL, matching the Rule Viewer) |
| `DESC_WRITE_MODE` | `append` preserves existing description lines. Keep it. |
| `SKIP_RLM_DESCRIPTIONS` | See below |
| `SECURETRACK_GRAPHQL` | Lab or production endpoint |

**Environments**

| | Host |
|---|---|
| Lab | `keeppgelabsecure.utility.pge.com` |
| Production | `keeppgesecure.utility.pge.com` |

Change `SECURETRACK_GRAPHQL` and `KEYCLOAK_TOKEN_URL` together — pointing one at
production and leaving the other on lab fails in a confusing way.

---

## Rules that already carry an `##RLM##` description

A parallel Rule Lifecycle Management process writes to the same field:

```
##RLM##
FER<number>: APP-<id>
Owner:AMPS APP-<id>
<any pre-existing description follows>
```

`SKIP_RLM_DESCRIPTIONS = True` leaves those rules untouched and lists them in the plan with
the reason. Setting it `False` appends the `app_id:` line below the existing content, which
is what the RLM process expects — it treats two sources writing the field as
cross-validation rather than conflict.

**Confirm the intended behaviour before the first production write.**

---

## Output

`tag_output/tag_plan.xlsx`, one row per rule, with a filterable header:

| Column | Meaning |
|---|---|
| `rule_uid` | The Tufin rule the change targets |
| `rule_name (idOnDevice)` | The rule's name |
| `app_ids` | App-ID(s) from the sheet |
| `action` | What the script decided, and why if it skipped |
| `skip` | `FALSE` means this row would be written |
| `old_description` / `new_description` | Before and after |

Filter `skip = FALSE` to see exactly what a live run would change.

---

## Things worth knowing

**Long fetches survive token expiry.** The estate is ~70,000 rules and a fetch can outlive
a Keycloak token. A 401 clears the cached token, gets a fresh one, and retries that request
once. Credentials are cached in memory so the refresh is silent rather than re-prompting
mid-run. A 403 is not retried — that is a permissions problem, and retrying would bury the
cause.

**GraphQL types that are not the obvious ones.** `values(offset:)` is `Long`, not `Int`.
Writing a value inline in GraphiQL skips variable type checking, which is why this only
surfaces once a script runs.

**Introspection is capped** at one `__type` per request by the server's good-faith
introspection guard.

---

## Verifying a run

```
py verify_run.py
```

Reads the plan files and prints a pass/fail verdict. See `verify_run.py` for what it
checks.

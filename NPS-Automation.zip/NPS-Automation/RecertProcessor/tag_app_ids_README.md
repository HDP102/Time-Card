# App-ID Tagging (`tag_app_ids.py`)

Writes the App-ID for each firewall rule into that rule's **Description** field in Tufin
SecureTrack, so the app id becomes a queryable attribute on the rule. This is the
"documentation" half of the recertification effort — every rule traceable to a valid app.

It targets the Tufin **Description** metadata field (DOCUMENTATION → ADDITIONAL
INFORMATION → Description), **not** Panorama tags (tags overload the firewalls).

---

## How it works

Three data points, joined together:

| Source | Gives | Field |
|---|---|---|
| The rule spreadsheet | App-ID for each rule | `App-ID` column |
| The rule spreadsheet | The rule's name | `Rule Name` column |
| Tufin (GraphQL read) | The rule's UID + current description | `id`, `idOnDevice`, `ruleUserData.ruleDescription` |

The **join key** is `Rule Name == idOnDevice` — the spreadsheet's Rule Name matches
Tufin's idOnDevice exactly (confirmed, e.g. `ADMS_Endpoints to ODN_Tenabl_3-1-1`). The
write needs the opaque UID (e.g. `1E6L9H09iJ4l0s3XmAm-hw==`), which the read query
provides. So the flow is:

```
Spreadsheet:  Rule Name  ->  App-ID
Tufin read:   idOnDevice ->  UID   (idOnDevice == Rule Name)
Join:         Rule Name  ==  idOnDevice
Write:        App-ID into that UID's Description   (updateRuleDescription mutation)
```

Run order in `main()`:
1. Read the spreadsheet → `Rule Name -> App-ID(s)`.
2. Query Tufin (paginated) → every rule's `idOnDevice -> UID` + current description.
3. Join on Rule Name == idOnDevice.
4. Build the new Description and write it back per rule, batched.
5. Write a **plan CSV** of every intended change.

The write is **idempotent**: rules already carrying the app id are skipped, existing
Description text is preserved (append mode), and re-running never double-tags.

---

## Confirmed against live Tufin

- **Read** — `rules { values(first,offset){ id idOnDevice ruleUserData{ruleDescription} } }`
  returns real data.
- **Write** — `ruleUserData { updateRuleDescription(input:{description,ids}) { ids
  resultStatus{successful errors} } }` returned `successful: true` and the description
  changed, then cleared cleanly. `ids` is an array, so multiple rules batch in one call.
- **Join key** — the spreadsheet Rule Name equals Tufin idOnDevice on a real rule.

The one piece still to wire is **programmatic auth** (below).

---

## Configuration

Top of `tag_app_ids.py`:

| Setting | What it is |
|---|---|
| `DRY_RUN` | `True` = build the plan CSV and change nothing. Start here. |
| `EXCEL_PATH` | The rule spreadsheet (the full sheet, not the `report_` view). |
| `RULE_NAME_COLUMN` / `APPID_COLUMN` | Column headers to read (`Rule Name`, `App-ID`). |
| `SECURETRACK_GRAPHQL` | The GraphQL endpoint. **Lab first**; prod only once proven. |
| `RULE_FILTER` | Which rules to pull, Rule-Viewer filter syntax (default targets `ADMS`). |
| `DESC_WRITE_MODE` | `append` (keep existing text, add the app-id line) or `replace`. |
| `DESC_APPID_PREFIX` | The label written into the Description (`app_id:`). |
| `WRITE_BATCH_SIZE` | Rules per write call (ids is an array). |
| `KEYCLOAK_*` | Auth — see below. |

---

## Auth (the one remaining wiring)

The browser GraphiQL works because the browser is logged in. A script needs a bearer
token. `get_access_token()` has the Keycloak password-grant flow structured (matching the
RE's script); you just need to supply the credentials:

- Set `KEYCLOAK_USERNAME` / `KEYCLOAK_PASSWORD` — **prompt at runtime, don't hardcode**
  (this script is meant for the shared repo).
- Confirm `KEYCLOAK_TOKEN_URL` / `KEYCLOAK_CLIENT_ID` against the RE's script or with the
  Tufin RE.

Until this is set, the script raises a clear error rather than running.

---

## How to run

1. **Wire the auth** (above) and confirm the endpoint is the **lab** first.
2. Point `EXCEL_PATH` at a rule sheet.
3. Leave `DRY_RUN = True` and run:
   ```
   py tag_app_ids.py
   ```
   It reads the sheet, queries Tufin, joins, and writes `tag_output/tag_plan.csv`.
4. **Review the plan CSV.** It lists every rule: the Rule Name (idOnDevice), the app id,
   the action (add / already present / no app id), and the old vs. new Description. This
   is the review step before anything touches production metadata.
5. When the plan looks right, do a **small live test** first — narrow `RULE_FILTER` to a
   handful of rules, set `DRY_RUN = False`, run, and read the rules back to confirm.
6. Then widen the filter and run the full set.

Never run writes against prod until the same run has been proven in the lab.

---

## Output

- `tag_output/tag_plan.csv` — every intended change, written on every run (dry or live):
  `rule_uid`, `rule_name (idOnDevice)`, `app_ids`, `action`, `skip`, `old_description`,
  `new_description`.

---

## Notes

- Rules whose Rule Name isn't in the spreadsheet (or that have no app id) are skipped and
  logged, never written.
- Spreadsheet rule names with no matching Tufin rule (given the filter) are reported so
  you can widen the filter if needed.
- The Description format is `app_id: APP-XXXX`. If the team standardizes on a different
  convention (e.g. `<ticket-id>: APP-XXXX`), change `DESC_APPID_PREFIX` / the build logic
  to match, and keep the recert processor's reader in sync.

"""
compile_recert_report.py - one flat workbook of every rule and what happened to it.

Reads the plan files in recert_output/, the resume ledger, and the Rule-ID mapping.
Writes recert_output/recert_all_rules.xlsx:
    Rules    one row per rule - flat table for Power BI
    Summary  counts per category

Categories
    Recertify          owner said keep; Draft Batch shows which draft it is in
    Disable (pending)  owner said remove, guard passed; disable pass has not run yet
    Held back          owner said remove, guard blocked it (reason column says why)
    Need assistance    owner asked for help
    Conflict           two lists gave different decisions; skipped (no UID - keyed by device + rule)
    No decision        in Tufin but not in any list (needs a Tufin fetch - see INCLUDE_NO_DECISION)

Run from RecertProcessor/:   py compile_recert_report.py
"""
import json
from pathlib import Path

from openpyxl import Workbook, load_workbook

import recert_processor as r

INCLUDE_NO_DECISION = True   # True = log in to Tufin and add every rule with no decision
                             # (needed for the full ~70k). False = decided rules only, no login.

OUT_DIR = Path(r.OUTPUT_DIR)
OUT_FILE = OUT_DIR / "recert_all_rules.xlsx"

COLUMNS = ["Rule UID", "Device", "Rule Name", "Category", "Last Hit", "Hit State",
           "Reason", "Source List", "Draft Batch", "Draft Created"]


def read_sheet(name):
    """Rows of a plan file as dicts. Missing file -> empty list."""
    p = OUT_DIR / name
    if not p.exists():
        print(f"  (not found, skipped: {name})")
        return []
    try:
        wb = load_workbook(p, read_only=True, data_only=True)
    except PermissionError:
        raise SystemExit(f"{name} is open in Excel - close it and run again.")
    rows = wb.active.iter_rows(values_only=True)
    header = [str(h).strip() if h is not None else "" for h in next(rows, [])]
    out = [dict(zip(header, row)) for row in rows if any(v is not None for v in row)]
    wb.close()
    return out


def device_by_uid():
    """UID -> device name, from the mapping workbook (original casing kept)."""
    p = r.data_path(r.MAPPING_PATH)
    wb = load_workbook(p, read_only=True, data_only=True)
    ws = next((wb[n] for n in wb.sheetnames
               if n.strip().lower() == r.MAPPING_SHEET.strip().lower()), wb.active)
    rows = ws.iter_rows(values_only=True)
    header = [str(h).strip() if h is not None else "" for h in next(rows)]
    d_i, u_i = header.index(r.MAP_DEVICE_COLUMN), header.index(r.MAP_UID_COLUMN)
    out = {}
    for row in rows:
        uid, dev = row[u_i], row[d_i]
        if uid:
            out.setdefault(str(uid).strip(), str(dev or "").strip())
    wb.close()
    return out


def draft_by_uid():
    """UID -> (batch number, timestamp) from the resume ledger, recertify only."""
    out = {}
    if not r.LEDGER_PATH.exists():
        return out
    with open(r.LEDGER_PATH, encoding="utf-8") as f:
        batch = 0
        for line in f:
            if not line.strip():
                continue
            rec = json.loads(line)
            if rec.get("workflow_type") != r.RECERTIFY_WORKFLOW_TYPE:
                continue
            batch += 1
            for u in rec.get("uids", []):
                out[u] = (batch, rec.get("ts", ""))
    return out


def main():
    print("Reading plan files...")
    devices = device_by_uid()
    drafts = draft_by_uid()
    rows, seen = [], set()

    def add(uid, rule_name, category, last_hit="", hit_state="", reason="", source=""):
        uid = str(uid or "").strip()
        batch, ts = drafts.get(uid, ("", ""))
        rows.append([uid, devices.get(uid, ""), rule_name or "", category,
                     last_hit or "", hit_state or "", reason or "", source or "", batch, ts])
        if uid:
            seen.add(uid)

    for x in read_sheet("recertify_plan.xlsx"):
        add(x.get("rule_uid"), x.get("rule_name"), "Recertify",
            x.get("last_hit"), source=x.get("source_file"))
    for x in read_sheet("disable_plan.xlsx"):
        add(x.get("rule_uid"), x.get("rule_name"), "Disable (pending)",
            x.get("last_hit"), x.get("hit_state"), source=x.get("source_file"))
    for x in read_sheet("held_back_from_disable.xlsx"):
        add(x.get("rule_uid"), x.get("rule_name"), "Held back",
            x.get("last_hit"), x.get("hit_state"), x.get("reason"), x.get("source_file"))
    for x in read_sheet("need_assistance.xlsx"):
        add(x.get("rule_uid"), x.get("rule_name"), "Need assistance",
            x.get("last_hit"), source=x.get("source_file"))

    # Conflicts carry no UID (they were never resolved) - keyed by device + rule name.
    for x in read_sheet("decision_conflicts.xlsx"):
        rows.append(["", x.get("device") or "", x.get("rule_name") or "", "Conflict", "", "",
                     f"{x.get('decision_a')} ({x.get('file_a')}) vs "
                     f"{x.get('decision_b')} ({x.get('file_b')})", "", "", ""])

    if INCLUDE_NO_DECISION:
        print("Fetching all rules from Tufin for the 'No decision' rows...")
        for rule in r.fetch_rules(r.RULE_FILTER):
            if rule.uid not in seen:
                add(rule.uid, rule.id_on_device, "No decision", rule.last_hit_str)

    counts = {}
    for row in rows:
        counts[row[3]] = counts.get(row[3], 0) + 1

    wb = Workbook(write_only=True)
    ws = wb.create_sheet("Rules")
    ws.append(COLUMNS)
    for row in rows:
        ws.append(row)
    s = wb.create_sheet("Summary")
    s.append(["Category", "Rules"])
    for cat, n in counts.items():
        s.append([cat, n])
    s.append(["Total", len(rows)])
    s.append([])
    s.append(["Recertify drafts", len({v[0] for v in drafts.values()})])

    try:
        wb.save(OUT_FILE)
    except PermissionError:
        raise SystemExit(f"{OUT_FILE.name} is open in Excel - close it and run again.")

    print(f"\nWrote {OUT_FILE}")
    for cat, n in counts.items():
        print(f"  {cat:<20}{n:>8,}")
    print(f"  {'Total':<20}{len(rows):>8,}")


if __name__ == "__main__":
    main()

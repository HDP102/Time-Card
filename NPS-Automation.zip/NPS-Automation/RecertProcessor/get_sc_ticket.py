"""
get_sc_ticket.py - read-only. Pulls one SecureChange ticket, or a workflow definition
by name, over REST and shows its structure (steps, tasks, fields), so we can build recert tickets the same way.

Saves the full JSON to recert_output/sample_<ticket-or-workflow>.json (production data -
recert_output/ is git-ignored; don't share the file outside the team).

Run from RecertProcessor/:   py get_sc_ticket.py
"""
import getpass
import json
import os
from pathlib import Path
from urllib.parse import quote, urlparse

import requests
import urllib3

import recert_processor as r

urllib3.disable_warnings()

HOST = urlparse(r.SECURETRACK_GRAPHQL).netloc          # same host the recert script uses
BASE = f"https://{HOST}/securechangeworkflow/api/securechange"
HDRS = {"Accept": "application/json"}
DEFAULT_WORKFLOW = "RLM Rule Recertification Workflow"


def as_list(x):
    """SecureChange returns one item as a dict and several as a list."""
    if x is None:
        return []
    return x if isinstance(x, list) else [x]


def get(path, auth):
    resp = requests.get(BASE + path, auth=auth, headers=HDRS, verify=False, timeout=60)
    if resp.status_code != 200:
        print(f"GET {path} -> {resp.status_code}\n{resp.text[:500]}")
        return None
    return resp.json()


def main():
    user = os.environ.get("SECURETRACK_USER") or input("SecureChange username: ")
    pwd = os.environ.get("SECURETRACK_PASSWORD") or getpass.getpass("SecureChange password: ")
    auth = (user, pwd)
    print(f"Host: {HOST}")

    what = input(f"Ticket ID or workflow name [Enter = {DEFAULT_WORKFLOW}]: ").strip() or DEFAULT_WORKFLOW

    if what.isdigit():
        data = get(f"/tickets/{what}", auth)
        tag = what
    else:
        data = get(f"/workflows?name={quote(what)}", auth)
        tag = "workflow_" + "".join(c if c.isalnum() else "_" for c in what)
    if not data:
        return

    out = Path(r.OUTPUT_DIR) / f"sample_{tag}.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(data, indent=2), encoding="utf-8")

    t = data.get("ticket") or data.get("workflow") or data
    if isinstance(t, list):
        t = t[0] if t else {}
    print(f"\nName/Subject: {t.get('name') or t.get('subject')}")
    print(f"Workflow:     {(t.get('workflow') or {}).get('name', '')}")
    print(f"Status:       {t.get('status', '')}")
    print("Top-level keys:", ", ".join(k for k in t if k != "steps"))

    for step in as_list((t.get("steps") or {}).get("step")):
        print(f"\n== Step: {step.get('name')}  (id {step.get('id')})")
        for task in as_list((step.get("tasks") or {}).get("task")):
            print(f"   Task: {task.get('name')}  status={task.get('status', '')}  id={task.get('id')}")
            for f in as_list((task.get("fields") or {}).get("field")):
                ftype = f.get("@xsi.type") or f.get("@type") or f.get("type") or ""
                print(f"      field: {f.get('name')!r:40} {ftype}")
        for f in as_list((step.get("fields") or {}).get("field")):   # workflow definitions list fields per step
            ftype = f.get("@xsi.type") or f.get("@type") or f.get("type") or ""
            print(f"      field: {f.get('name')!r:40} {ftype}")

    print(f"\nFull JSON saved to {out}")


if __name__ == "__main__":
    main()

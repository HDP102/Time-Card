# Recertification Ticket Processor (`recert_processor.py`)

Reads each firewall rule's recertification decision and creates the right ticket in
Tufin SecureChange. The **recertify** path is wired and confirmed. The **decommission**
(Cleanup/Remove) path is specified but not yet wired — it waits on a Tufin workflow.

---

## How it works (recertify path)

| Source | Gives |
|---|---|
| Reporting view (`report_` export) | Rule Name + the decision (Recertification column) |
| Tufin (GraphQL read) | idOnDevice -> UID, filtered to rules not already in a ticket |

Join key is `Rule Name == idOnDevice` (confirmed, same as the tagging script).

```
Reporting view:  Rule Name  ->  decision (Recertify / Cleanup-Remove / Need Assistance)
Tufin read:      idOnDevice ->  UID   (filter excludes rules already ticketed)
Join:            Rule Name  ==  idOnDevice
Recertify rules  ->  createTicketDraft (RECERTIFY_RULES workflow)
Cleanup/Remove   ->  flagged for the decom process (not ticketed yet)
Need Assistance  ->  flagged for NPS follow-up (no ticket)
```

Run order in `main()`:
1. Load decisions from the reporting view (Rule Name -> decision).
2. Query Tufin for candidate rules (Palo Alto, high/critical, **not already in a ticket**).
3. Join on Rule Name == idOnDevice; split into recertify / remove / assist / none.
4. Create recertify tickets (batched, `createTicketDraft`), dry-run validated first.
5. Write a recertify plan CSV and a flagged CSV (remove + assist) for follow-up.

**No double-recertifying:** the Tufin filter includes
`securechangeTicketInProgressId not exists`, so rules that already have a ticket in
progress are never pulled — safe to run repeatedly.

---

## Confirmed against live Tufin

- **Read** — `rules { values(first,offset){ id idOnDevice } }`.
- **Ticket** — `ruleOperations { createTicketDraft(input:{ruleUids, workflowType,
  workflowName, subject, dryRun}) { invalidRules resultStatus{successful errors} } }`
  returned `successful: true` on a dry run.
- **Recertify workflow** — `RECERTIFY_RULES` / "RLM Rule Recertification Workflow".
- **Join key** — reporting-view Rule Name == Tufin idOnDevice.

Auth reuses the tagging script's Keycloak getpass flow (prompted at runtime).

---

## Configuration

| Setting | What it is |
|---|---|
| `DRY_RUN` | `True` = validate every ticket via `createTicketDraft` dryRun + write plan CSVs, create nothing. Start here. |
| `REPORT_PATH` | The reporting-view export (with Rule Name + Recertification). |
| `RULE_NAME_COLUMN` / `DECISION_COLUMN` | Columns to read (`Rule Name`, `Recertification`). |
| `SECURETRACK_GRAPHQL` | GraphQL endpoint. **Lab first**; prod only once proven. |
| `RULE_FILTER` | Which rules to consider — Palo Alto, high/critical, not-already-ticketed, ADMS. |
| `RECERTIFY_WORKFLOW_TYPE` / `_NAME` / `_SUBJECT` | The confirmed recertify workflow + subject. |
| `TICKET_BATCH_SIZE` | Rules per ticket draft (<= 300). |
| `KEYCLOAK_*` | Auth — prompted at runtime, blank in the file. |

---

## How to run

1. Wire auth (blank credentials -> prompted) and confirm the endpoint is the **lab**.
2. Point `REPORT_PATH` at the reporting-view export.
3. Leave `DRY_RUN = True` and run:
   ```
   py recert_processor.py
   ```
   It loads decisions, queries Tufin, and for each recertify batch calls
   `createTicketDraft` with `dryRun: true` — validating the tickets without creating
   them — then writes the plan CSVs.
4. Review `recert_output/recertify_plan.csv` (rules that would get recertify tickets) and
   `flagged_for_followup.csv` (Cleanup/Remove + Need Assistance).
5. When it looks right, set `DRY_RUN = False` to create the recertify tickets. Start with
   a narrow `RULE_FILTER` for a small first batch, confirm in SecureChange, then widen.

---

## Output

- `recert_output/recertify_plan.csv` — rules that got (or would get) recertify tickets.
- `recert_output/flagged_for_followup.csv` — Cleanup/Remove rules (pending the decom
  workflow) and Need-Assistance rules (manual follow-up), with a note each.

---

## Decommission (Cleanup/Remove) — specified, not yet wired

Confirmed process (from Sai, 2026-08-26): **two tickets, same workflow.**

1. **Disable** — identify the rule, **check recent traffic hits first** (don't blindly
   trust the spreadsheet — the traffic check can use Tufin's `lastHit`), then disable.
2. **Remove** (~2 weeks later) — reuse the ticket info; **validate the rule is still
   disabled** (someone may have re-enabled it — "remove only if disabled"), then remove.

There is **no Tufin decom workflow yet** (done manually today via PAN API). One is being
created (or "Remove Access - FER Life Cycle" confirmed as a fit). Once it exists:
confirm its `workflowType` / `workflowName` with a `createTicketDraft` dry run (exactly
like recertify was confirmed), then wire the two-stage disable/remove using the same
`createTicketDraft` mutation. Until then, Cleanup/Remove rules are flagged, not ticketed.

# recert_processor.py
### NPS Automation — Rule Recertification Response Processing (Scaffold)

---

## What This Is

This is the **second half** of the recertification pipeline. The first half (the notification script) emails rule owners and collects their A/B/C decisions. This script takes those decisions and turns them into the right follow-up action — recertify, remove, hold, or a per-owner IP decommission — and batches the resulting tickets.

It is currently a **scaffold**: the decision logic, pagination, and batching are complete and tested. The pieces that talk to external systems (SecureTrack, AMPS/LDAP, ticket creation) are **stubbed** and clearly marked, because they depend on access and endpoints that aren't available yet. Nothing in this script contacts any system or creates any ticket while the stubs are in place, and `DRY_RUN` is on by default on top of that.

The point of shipping it now is that the **hard part — the decision rules everyone agreed on in the review meetings — is written down, verified, and won't change** when the external pieces get connected.

---

## The Pipeline

```
SecureTrack (GraphQL)          rule data, paginated 100 at a time
      │
      ▼
extract app IDs                from rule description, or related tickets
      │
      ▼
resolve owner group (AMPS)     app ID -> current full participant group
      │
      ▼
load owner responses           returned spreadsheets, A/B/C per rule
      │
      ▼
decide action                  the agreed decision rules (see below)
      │
      ▼
batch (<= 300) + create        tickets, in chunks
      │
      ▼
write cert status back         into rule metadata
```

---

## The Decision Rules

This is the core, and it is fully implemented and tested. For each rule, once responses are in:

| Situation | Action |
|-----------|--------|
| No response yet | **Hold** — nothing happens until the owner acknowledges |
| Everyone recertified (A) | **Recertify ticket** |
| Everyone chose remove (B) | **Decommission-rule ticket** |
| Everyone chose remove, but rule is DR-flagged | **Keep + tag DR** — DR overrides removal |
| Anyone chose "review with team" (C) | **Hold** — a contested rule is never actioned automatically |
| Owners disagree, exactly one wants removal | **Decommission-IP ticket** for that one person's access only — the rule stays for everyone who recertified |
| Owners disagree, more than one wants removal | **Flag manual** — genuinely ambiguous, a human decides |

The disagreement handling is the important nuance: you can't remove a rule someone still needs, so a lone dissenter gets their *own access* removed (an IP decommission), not the whole rule.

---

## Prerequisites

```powershell
py -m pip install openpyxl
```

`openpyxl` is used to read the returned response spreadsheets. The external integrations will add more dependencies (an LDAP client, an HTTP client) when they're wired up — those aren't needed to run the scaffold.

---

## How to Run

```powershell
py recert_processor.py
```

With the stubs in place and `DRY_RUN = True`, a run will:
- attempt to fetch rules (this stub raises a clear "not implemented" until the endpoint is wired),
- once fetching is connected, load any responses in `responses/`,
- decide an action for every rule,
- log how many of each action it *would* take, and write a plan CSV,
- create no tickets and write no metadata.

The intended everyday workflow, once connected, is: **dry run first**, read the plan CSV, confirm the numbers look right, then turn `DRY_RUN` off for a real run.

---

## Configuration

All settings are at the top of the file:

| Setting | Purpose |
|---------|---------|
| `DRY_RUN` | `True` = decide and log only, create nothing. Leave on until fully verified |
| `SECURETRACK_GRAPHQL` | SecureTrack GraphQL endpoint — point at the **lab** VIP first |
| `GRAPHQL_PAGE_SIZE` | Results per page (100, matching the platform) |
| `AMPS_MODE` | `"script"` to call the resolver directly, or `"csv"` to read a daily dump |
| `TICKET_BATCH_SIZE` | Max tickets per batch (300) |
| `RESPONSES_DIR` | Folder of returned response spreadsheets |
| `DESC_APPID_PREFIX` / `DESC_OWNER_PREFIX` | The lines the app ID and owner are read from in a rule's description |

---

## Answers to the Recurring Process Questions

These came up repeatedly in the review meetings. Capturing the answers here so they don't have to be re-litigated.

### "Can we send owners only specific columns, not the whole rule dump?"

Yes — but that's a change on the **notification** side (the email/attachment builder), not this script. This script consumes what comes *back*, and only needs two columns to exist in the returned file: a **Rule ID** column and a **Decision** column. Everything else in the sheet is ignored here, so trimming the owner-facing columns has no effect on response processing. Trim freely for the owners' sake; this script still works as long as those two columns survive.

### "How do we avoid sending owners rules that were already handled? (duplicates)"

Two layers:

1. **Scope the input.** Rules are pulled per device-group / per segment rather than as one giant dump, so an already-processed segment simply isn't in the next batch. This is the agreed approach and it's why the source data is being split into done / remaining / separate-network segments.
2. **Certification status is written back.** After a rule is recertified, this script updates its certification status in the rule's metadata. A subsequent pull can filter on `certification_status:uncertified` (the default filter in `main()`), so handled rules drop out of the next round automatically.

The combination means you don't rely on tagging every rule to avoid duplicates — segment scoping does most of the work, and the status write-back handles the rest. (Tagging was deliberately avoided as the primary mechanism because heavy tagging burdens the firewalls.)

### "What about rules with no usage / last-hit data?"

A large share of older rules never logged a hit (pre-migration rules that predate current logging). **No-data is not treated as "unused, delete."** Usage data is surfaced to owners so they can make an informed call, and undecided rules are held, not removed. Deletion of long-unused rules is a separate, gated step that only happens after the owner has acknowledged — this script never removes a rule on its own initiative.

### "What happens when a rule has several owners and they disagree?"

See the decision table above. Short version: the rule is only removed if **everyone** agrees to remove it. A single dissenter who wants it gone gets their own access decommissioned (an IP-level ticket), leaving the rule intact for the owners who still need it. Two or more dissenters with a split gets flagged for a human.

### "Can an Excel sheet of rules drive bulk ticket creation?"

Partly, and this is the one open design question worth knowing about. Writing recertification **status** back has a clean API. Creating a brand-new **request/ticket** does not — that path goes through a web form, not a REST call, so bulk new-ticket submission needs browser automation rather than a simple API loop. The batching in this script (≤300) is ready for either; the submission mechanism itself is the stubbed piece still being settled.

---

## Current Blockers

These are why the external pieces are stubbed rather than implemented:

- **Tufin access** — gated on completing the required PRA and NERC training. No SecureTrack or SecureChange calls can be made or tested until this clears.
- **AMPS/LDAP resolver** — the owner-resolution lookup and its service-account credentials need to be provided. The base version returns a single participant; this needs all participants in the group.
- **Ticket-creation mechanism** — needs the decision on API vs. browser-form submission (see the Excel question above) before the ticket stub can be built.
- **Field names** — the GraphQL query/mutation field names and the FUR step-1 app-ID field should be reconciled against a known-good working example before the stubs are enabled.

---

## What's Safe to Rely On Today

The decision logic, pagination, app-ID extraction (including rejecting the unreliable legacy short IDs), response loading, and ≤300 batching are all implemented and tested against representative data. When access lands, the work is filling in the stubbed calls — not redesigning the flow.

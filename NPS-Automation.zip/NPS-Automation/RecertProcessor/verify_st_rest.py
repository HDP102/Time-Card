"""
verify_st_rest.py - read-only. Checks whether SecureTrack REST gives the three IDs
SecureChange needs, using the rule from ticket 139744 as the known answer:
    device DC-Prod        -> expect id 7081
    ff-mdms-Rule 125      -> expect uid {8487FFF8-69B1-F0D7-D36B-F77CDC852B11}
    binding               -> expect {00-FACED0-00}
Run from RecertProcessor/:   py verify_st_rest.py
"""
import getpass
import os
from urllib.parse import urlparse

import requests
import urllib3

import recert_processor as r

urllib3.disable_warnings()

HOST = urlparse(r.SECURETRACK_GRAPHQL).netloc
BASE = f"https://{HOST}/securetrack/api"
HDRS = {"Accept": "application/json"}

DEVICE_NAME = "DC-Prod"
RULE_NAME = "ff-mdms-Rule 125"
EXPECT = {"device_id": "7081", "uid": "{8487FFF8-69B1-F0D7-D36B-F77CDC852B11}",
          "binding": "{00-FACED0-00}"}


def L(x):
    return [] if x is None else (x if isinstance(x, list) else [x])


def get(path, auth, **params):
    resp = requests.get(BASE + path, auth=auth, headers=HDRS, params=params,
                        verify=False, timeout=120)
    print(f"GET {path} {params or ''} -> {resp.status_code}")
    if resp.status_code != 200:
        print(resp.text[:400])
        return None
    return resp.json()


user = os.environ.get("SECURETRACK_USER") or input("SecureTrack username: ")
pwd = os.environ.get("SECURETRACK_PASSWORD") or getpass.getpass("SecureTrack password: ")
auth = (user, pwd)

# 1. Device by name
data = get("/devices", auth, name=DEVICE_NAME)
devices = L(((data or {}).get("devices") or {}).get("device"))
for d in devices:
    print(f"  device id={d.get('id')}  name={d.get('name')}  vendor={d.get('vendor')}  "
          f"model={d.get('model')}  parent={d.get('parent_id')}")
match = [d for d in devices if str(d.get("id")) == EXPECT["device_id"]] or devices
if not match:
    raise SystemExit("Device not found by name - send this output.")
dev_id = match[0]["id"]
print(f"  device id matches 7081: {str(dev_id) == EXPECT['device_id']}")

# 2. Rules on that device - find the sample rule
data = get(f"/devices/{dev_id}/rules", auth)
rules = L(((data or {}).get("rules") or {}).get("rule"))
print(f"  {len(rules)} rule(s) on device {dev_id}")
hit = [x for x in rules if x.get("name") == RULE_NAME]
if not hit:
    raise SystemExit(f"'{RULE_NAME}' not in the response - send this output.")
x = hit[0]
binding = x.get("binding") or {}
print(f"\n  name:        {x.get('name')}")
print(f"  id:          {x.get('id')}")
print(f"  uid:         {x.get('uid')}   matches ticket: {str(x.get('uid')).upper() == EXPECT['uid']}")
print(f"  binding uid: {binding.get('uid')}   matches ticket: {binding.get('uid') == EXPECT['binding']}")
print(f"  binding keys: {', '.join(binding)}")
print(f"  rule keys:    {', '.join(x)}")

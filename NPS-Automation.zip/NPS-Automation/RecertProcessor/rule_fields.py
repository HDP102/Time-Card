"""
rule_fields.py - read-only. Lists every field on the GraphQL Rule type (and inside its
device / binding / policy objects) so we can find the three IDs SecureChange REST needs:
    rule uid {GUID}, device management_id, binding_uid
Run from RecertProcessor/:   py rule_fields.py
"""
import recert_processor as r

LOOK_INSIDE = ("device", "binding", "policy", "management", "domain", "ruleUserData")


def q(s):
    return r._graphql(s, {})["data"]


def base(t):
    while t and not t.get("name"):
        t = t.get("ofType")
    return t.get("name") if t else None


def fields(type_name):
    t = q('{__type(name:"%s"){fields{name type{name kind ofType{name kind '
          'ofType{name kind ofType{name}}}}}}}' % type_name)["__type"]
    return (t or {}).get("fields") or []


def show(title, flds):
    print(f"\n== {title} ==")
    for f in flds:
        print(f"  {f['name']:32} {base(f['type'])}")


query_root = q("{__schema{queryType{name}}}")["__schema"]["queryType"]["name"]
rules_f = next(f for f in fields(query_root) if f["name"] == "rules")
result_type = base(rules_f["type"])                       # e.g. RulesResult
values_f = next(f for f in fields(result_type) if f["name"] == "values")
rule_type = base(values_f["type"])                        # the Rule type itself

rule_fields = fields(rule_type)
show(f"Rule type ({rule_type})", rule_fields)

seen = {rule_type}
for f in rule_fields:
    t = base(f["type"])
    if t and t not in seen and any(k.lower() in f["name"].lower() for k in LOOK_INSIDE):
        seen.add(t)
        sub = fields(t)
        if sub:
            show(f"{f['name']} -> {t}", sub)

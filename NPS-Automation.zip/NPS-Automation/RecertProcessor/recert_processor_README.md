# Recertification & Decommission Tickets (`recert_processor.py`)

Turns owner decisions into Tufin tickets. Recertify decisions become recertification
tickets; Cleanup/Remove decisions become disable tickets, subject to a traffic check.

---

## How it works

1. **Refuses to run** if the campaign has closed or a reporting view is stale.
2. Reads and **merges every reporting view** matching `REPORT_PATH` from the shared data
   folder. A rule appearing in two lists with **different** decisions is skipped and
   written to `decision_conflicts.xlsx` rather than resolved arbitrarily.
3. Resolves each decision to a rule UID through `Rule-ID-Mapping.xlsx`, reporting the
   resolve rate per sheet.
4. Fetches candidate rules from Tufin, carrying last-hit data.
5. Creates recertification tickets, and disable tickets for cleanup rules that pass the
   last-hit guard.
6. **Writes all plan files before creating tickets**, so a ticket failure cannot destroy
   the run's analysis.

---

## Setup

```
py -m pip install openpyxl requests
py recert_processor.py
```

Credentials are prompted at runtime and never written to disk. `SECURETRACK_USER` and
`SECURETRACK_PASSWORD` work for an unattended run.

The SecureTrack **API role is granted separately from UI access** — an account can sign in
to the Tufin web interface and still get 403 from the GraphQL API.

Spreadsheets live in `../SharedData/`. See the repository README for the layout.

---

## Key settings

| Setting | Purpose |
|---|---|
| `DRY_RUN` | `True` validates tickets through Tufin's own dry-run flag without creating anything. **Default.** |
| `REPORT_PATH` | Input reporting views; accepts a glob such as `report_*.xlsx` |
| `MAPPING_PATH` | The Rule-ID-Mapping workbook |
| `DATA_DIR` | Shared folder the two above resolve against |
| `RUN_TAG` | Written into the ticket subject, and the resume key for the ledger. **Keep it across re-runs of one campaign; change it only to start a new one.** |
| `CAMPAIGN_END_DATE` | Script refuses to run after this date |
| `REPORT_MAX_AGE_DAYS` | Script refuses if a reporting view is older |
| `LAST_HIT_THRESHOLD_DAYS` | A rule hit within this window is never disabled |
| `NEVER_HIT_POLICY` | Rules with no hit data: `skip` (default) or `disable` |
| `RULE_FILTER` | Which Tufin rules to fetch (TQL) |
| `TICKET_BATCH_SIZE` | Rules per ticket. Process owner asked for 300 or fewer. |
| `MAX_BATCHES_PER_RUN` | Tickets ONE run may create. `0` = all; `1` = one ticket then stop |
| `LEDGER_IN_DRY_RUN` | `True` makes a dry run skip rules already submitted |

**Environments**

| | Host |
|---|---|
| Lab | `keeppgelabsecure.utility.pge.com` |
| Production | `keeppgesecure.utility.pge.com` |

Change `SECURETRACK_GRAPHQL` and `KEYCLOAK_TOKEN_URL` together.

---

## The last-hit guard

A rule still passing traffic does not get disabled, whatever the spreadsheet says. Rules
marked Cleanup/Remove sort into three buckets:

| Bucket | Meaning | Action |
|---|---|---|
| `recent` | Hit inside the threshold | **Never disabled.** Held back with the hit date. |
| `stale` | Hit, but longer ago than the threshold | Disabled. Evidence it is unused. |
| `never` | No hit data at all | Governed by `NEVER_HIT_POLICY`. Skipped by default. |

Bucketing happens in Python, not in the TQL filter. A null last-hit matches neither
`after N days ago` nor `before N days ago`, so filtering server-side would let never-hit
rules fall into or out of the disable set silently.

### Known limit

The guard can only work where Tufin **has** hit data, and Tufin does not collect hit
counts on multi-VSYS firewalls. In the lab roughly 72% of rules have no hit data at all.

**The guard proves a rule is in use. It cannot prove a rule is not.**

Hit data is materially better in production than in lab, and collection is being extended
to further environments. Cisco devices are not currently collected. Re-evaluate
`NEVER_HIT_POLICY` against production data rather than assuming the lab picture holds.

---

## Output (`recert_output/`)

| File | Contents |
|---|---|
| `recertify_plan.xlsx` | Rules submitted for recertification |
| `disable_plan.xlsx` | Rules submitted for disable, with hit date and run tag |
| `held_back_from_disable.xlsx` | **Read this one.** Cleanup rules the guard refused, with the reason |
| `need_assistance.xlsx` | Owner asked for help; no ticket created |
| `decision_conflicts.xlsx` | Rules with different decisions in different lists |
| `rejected_by_tufin.xlsx` | Rules Tufin refused as ineligible |

All output is `.xlsx` with a filterable, frozen header. Every row carries a `source_file`
column so a decision traces back to the list it came from.

`held_back_from_disable.xlsx` is the one worth attention. A rule showing recent traffic
while its owner believes it is dead is a conversation to have before widening the guard.

---

## Things worth knowing

**Ticket creation is all-or-nothing.** One ineligible rule fails an entire
`createTicketDraft` batch with error code `RUD_7` — proven on a two-rule dry run where a
single bad rule failed both. At batch sizes of hundreds this fires on most runs, so the
script drops the flagged UIDs and retries with the remainder rather than losing the batch.
Dropped UIDs land in `rejected_by_tufin.xlsx`.

**Conflicting decisions are skipped, not resolved.** A rule in two lists with different
decisions is dropped and reported with both decisions and both filenames. It is not
resolved by taking the first file or by favouring the safer decision — either would hide a
real disagreement behind an arbitrary rule. A third list agreeing with one side does not
revive it.

**Rules are addressed by UID, never by name.** An earlier version joined on rule name
alone; one spreadsheet row matched 100 rules on different devices. There is no name-only
fallback.

**Long fetches survive token expiry.** A 401 clears the cached token, gets a fresh one and
retries once, with credentials cached in memory so the refresh is silent. A 403 is not
retried.

### GraphQL types that are not the obvious ones

The server rejects the whole query if any of these is wrong. Writing a value inline in
GraphiQL skips variable type checking, which is why they only surface once a script runs.

| Variable | Type |
|---|---|
| `ruleUids` | `[IdString!]!` not `[String!]!` |
| `workflowName` | `Name` not `String` |
| `subject` | `Name` not `String` |
| `workflowType` | `WorkFlowType` — capital F mid-word |
| `offset` | `Long` not `Int` |

### Confirmed workflows

| Path | Type | Name |
|---|---|---|
| Recertify | `RECERTIFY_RULES` | `RLM Rule Recertification Workflow` |
| Decommission | `DECOMMISSION_RULES` | `MP RLM Rule Decommission/Disable` |

`DecommissionRulesAction` is `DISABLE_RULES` or `REMOVE_RULES`.

---

## The remove pass — not wired

The remove ticket is the irreversible half, so it is a separate run some weeks after the
disable, not part of this one. The API side is confirmed: same mutation, same workflow,
with `decommissionRulesAction: REMOVE_RULES`.

Two things need settling before it is built:

1. **How to identify what a given run disabled.** `RUN_TAG` is in the subject of every
   disable ticket, but reading it back means querying SecureChange tickets. Panorama tags
   are the likelier answer — rule tags are filterable server-side in TQL.
2. **Whether elapsed time alone authorises removal**, or a human signs off first.

Either way: re-validate that the rule is **still disabled** immediately before removing
it. Someone may have re-enabled it during the wait, and that is exactly the signal the
soak period exists to surface.

---

## Resuming a partial run

A full recertification campaign is ~122 tickets. If a run dies partway through —
token expiry, network, anything — re-running without a record would create every
ticket again from batch 1, duplicating whatever already succeeded. Tufin has no idea
the second run is a repeat.

Every successful **live** batch is therefore appended to
`recert_output/submitted_rules.jsonl` the moment it lands, with an fsync so a crash
cannot lose the record. A later run under the **same `RUN_TAG`** skips those rules and
reports how many it skipped.

`RUN_TAG` is the resume key, not just a ticket subject. Keep it stable across re-runs
of the same campaign; change it deliberately to start a new one.

### Working through a campaign in steps

```python
MAX_BATCHES_PER_RUN = 1
```

Each run creates one ticket of up to `TICKET_BATCH_SIZE` rules, records it, and stops
with a line saying how many remain. Run it again for the next batch. That turns one
122-ticket execution into 122 controlled steps.

The cap applies **per workflow**, so with recertify and disable both in play, one run
creates one of each.

### Seeing what is left without touching Tufin

```python
DRY_RUN           = True
LEDGER_IN_DRY_RUN = True
```

The dry run consults the ledger and validates only the outstanding rules. A dry run
**never writes** the ledger either way — nothing was created, so there is nothing to
record.

| `DRY_RUN` | `LEDGER_IN_DRY_RUN` | Behaviour |
|---|---|---|
| `True` | `False` | Validates every rule, ledger ignored. Default. |
| `True` | `True` | Validates only what is outstanding. |
| `False` | — | Skips what is done, creates up to `MAX_BATCHES_PER_RUN`, records each. |

Plan files always cover **every** rule, not just the current batch — the ledger tracks
execution, the plan files track analysis.

---

## Verifying a run

```
py verify_run.py
```

Reads the plan files and prints a pass/fail verdict.

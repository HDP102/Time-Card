# Notification Batches — Scope Reference

The batches sent by `Notify/notify_special.py`. Set `BATCH` to the number, or the ALL
value to send every batch in sequence. Each batch's spreadsheet, SharePoint list link,
subject scope, and reporting-view file are defined in the `BATCHES` table at the top of
`notify_special.py`.

| BATCH | Scope (email subject suffix) | Spreadsheet |
|------:|------------------------------|-------------|
| 1  | GDN                  | `GDN Rule Recertification.xlsx` |
| 2  | Medium               | `MediumRule_report_with_APPID.xlsx` |
| 3  | ODN NERC Part 1      | `ODN_NERC_Low_Medium_Part1.xlsx` |
| 4  | ODN NERC Part 2      | `ODN_NERC_Low_Medium_Part2.xlsx` |
| 5  | ODN Remaining Part 1 | `Remaining_ODN_Firewalls_Part1.xlsx` |
| 6  | ODN Remaining Part 2 | `Remaining_ODN_Firewalls_Part2.xlsx` |
| 7  | ODN MPLS Part 1      | `ODN_MPLS_Rules_Part1.xlsx` |
| 8  | ODN MPLS Part 2      | `ODN_MPLS_Rules_Part2.xlsx` |
| 9  | UDN Part 1           | `UDN_FirewallRules_Part1.xlsx` |
| 10 | UDN Part 2           | `UDN_FirewallRules_Part2.xlsx` |
| 11 | UDN Part 3           | `UDN_FirewallRules_Part3.xlsx` |
| 12 | **ALL** of the above, one after another (hands-off) | — |

The email subject reads: `ACT: Execute Recertification of Firewall Rules - <scope>`.

## Files each batch needs (in the `Notify/` folder)

For every batch, two files:

- The full sheet, e.g. `UDN_FirewallRules_Part1.xlsx` — who to email (all owner roles).
- The reporting view, `report_` + the same name, e.g. `report_UDN_FirewallRules_Part1.xlsx`
  — who has responded (its Recertification column). Skip-responded reads this. Only the
  `report_` files need re-downloading before each send.

If a `report_` file is missing for a batch, that batch safely emails everyone (no skip)
rather than dropping anyone.

Shared responses folder
=======================

Drop returned recertification spreadsheets here — the files rule owners send
back after completing the Decision column.

Both tools use this one folder:
  - notify_rule_owners.py (in ../Notify) writes/expects them here
  - recert_processor.py   (in ../RecertProcessor) reads them here

Files are named:  Firewall_Rules_Recertification_<CORPID>.xlsx

This folder is shared on purpose so notifications and response-processing see
the same place. Keep it set to "Always keep on this device" in OneDrive so a
script never hits a cloud-only placeholder mid-run.

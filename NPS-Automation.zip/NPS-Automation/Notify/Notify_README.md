# Owner Notification (`notify_rule_owners.py`, `notify_special.py`)

Contacts firewall rule owners with the rules they own and collects a decision on each:
Recertify, Clean up / Remove, or Review with the team.

Two scripts share the same logic. `notify_rule_owners.py` works against a single
spreadsheet; `notify_special.py` is driven by a batch table covering the eleven
SharePoint lists the campaign runs across.

---

## Setup

```
py -m pip install openpyxl requests
py notify_rule_owners.py
```

Spreadsheets live in `../SharedData/`. See the repository README for the layout.

---

## Run modes (`RUN_MODE`)

| Mode | Behaviour |
|---|---|
| `notify` | Email each owner their rules, plus an optional Teams card |
| `remind` | Chase owners who have not responded, with a days-outstanding count |
| `announce` | One heads-up card to the team channel before a wave goes out |
| `digest` | One status card to the team channel; contacts no owners |

---

## Key settings

| Setting | Purpose |
|---|---|
| `DRY_RUN` | `True` prints instead of sending. **Default.** |
| `EXCEL_PATH` | The rule spreadsheet (resolved against `DATA_DIR`) |
| `DATA_DIR` | Shared folder holding the spreadsheets |
| `SKIP_RESPONDED` | Skip owners who have already answered, so reminders only reach people who still owe a decision |
| `NOTIFY_ROLES` | Which owner roles are contacted (IT SME, IT Lead, Client Owner, IT Director, …) |
| `NOTIFY_ONLY` | Restrict to specific owners — applies in every mode |
| `EXCLUDE_OWNERS` | Never contact these owners |
| `NOTIFY_DEVICES` | Restrict to specific devices |
| `SMTP_HOST` | PG&E internal mailhost, port 25 |

The filters apply in **every** mode, including dry run and test sends, so a test cannot
accidentally reach the whole estate.

---

## notify_special.py — batch mode

The campaign runs across eleven SharePoint lists, each with its own spreadsheet, list URL
and scope. `BATCHES` holds that mapping; setting `BATCH = n` selects one, so a wave can be
sent per list without editing paths and links by hand each time.

```python
BATCH = 1          # which of the eleven lists to send for

BATCHES = {
    1: {"excel": "GDN Rule Recertification.xlsx",
        "scope": "GDN",
        "link":  "https://..."},
    ...
}
```

The spreadsheet name is resolved against `DATA_DIR`, so only the filename belongs in the
table.

Also supports SharePoint mode, where the email points owners at their list rather than
attaching a spreadsheet, and owners record decisions directly in SharePoint.

---

## Response tracking

For each rule spreadsheet there is a reporting view with the same name and a `report_`
prefix — `ODN_MPLS_Rules_Part1.xlsx` → `report_ODN_MPLS_Rules_Part1.xlsx`. That export
carries the current Recertification decisions.

With `SKIP_RESPONDED = True` the script reads it and contacts only owners who still have
a blank decision on at least one of their rules. Re-download the reporting view before
each reminder wave or it will chase people who have already answered.

---

## Output

Each owner receives an Excel attachment with a **Decision dropdown**, so responses come
back in a uniform, auditable format rather than as free text in an email body.

---

## Scheduling

Neither script runs on a schedule. Both are run deliberately when a wave or reminder is
due, and both default to dry run.

"""
check_preview.py - read-only. Totals the dry-run preview files (sc_preview_batch*.json)
from sc_recert_submit.py: rules resolved, skipped (grouped by reason), and without owner.
Run from RecertProcessor/:   py check_preview.py
"""
import collections
import glob
import json
import re

files = sorted(glob.glob("recert_output/sc_preview_batch*.json"),
               key=lambda x: int(re.findall(r"\d+", x)[-1]))
resolved = skipped = no_owner = 0
reasons, bad = collections.Counter(), []

for f in files:
    d = json.load(open(f, encoding="utf-8"))
    rules, probs = d["rules"], d["problems"]
    resolved += len(rules)
    skipped += len(probs)
    no_owner += sum(1 for x in rules if not x["owner"])
    for _, why in probs:
        reasons[re.sub(r"'[^']*'|\{[^}]*\}|\d+", "#", why.split(": ", 1)[-1])[:70]] += 1
    if probs:
        bad.append((re.findall(r"\d+", f)[-1], len(probs)))

print(f"batches {len(files)}  resolved {resolved:,}  skipped {skipped:,}  no owner {no_owner:,}")
print("skip reasons:")
for why, n in reasons.most_common():
    print(f"  {n:>6,}  {why}")
print("batches with skips:", bad)
